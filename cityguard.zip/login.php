<?php
require_once __DIR__ . '/config/constants.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/session.php';

if (isLoggedIn()) { header('Location: ' . getDashboardUrl()); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    if (!$email || !$password) {
        $error = t('login_email') . ' / ' . t('login_password') . ' required.';
    } else {
        $db   = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            loginUser($user);
            header('Location: ' . getDashboardUrl()); exit;
        }
        $error = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= t('login_title') ?> — <?= APP_NAME ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <style>
    body { background: linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 1rem; }
    .login-card { background: #fff; border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,.15); width: 100%; max-width: 420px; overflow: hidden; }
    .login-header { background: linear-gradient(135deg, #1e293b, #334155); padding: 2rem; text-align: center; }
    .login-body { padding: 2rem; }
    .login-icon { width: 56px; height: 56px; background: #0ea5e9; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; color: #fff; margin: 0 auto 1rem; }
  </style>
</head>
<body>
<div style="position:fixed;top:1rem;right:1rem;z-index:100;display:flex;gap:4px">
  <a href="?setlang=en" class="btn btn-sm <?= langIs('en') ? 'btn-light' : 'btn-outline-light' ?>">EN</a>
  <a href="?setlang=bm" class="btn btn-sm <?= langIs('bm') ? 'btn-light' : 'btn-outline-light' ?>">BM</a>
</div>
<div class="login-card">
  <div class="login-header">
    <div class="login-icon"><i class="bi bi-geo-alt-fill"></i></div>
    <h5 class="text-white fw-bold mb-1"><?= APP_NAME ?></h5>
    <p class="text-white-50 small mb-0">Smart Community Management System</p>
  </div>
  <div class="login-body">
    <?php if ($error): ?>
      <div class="alert alert-danger small py-2"><i class="bi bi-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label class="form-label"><?= t('login_email') ?></label>
        <div class="input-group">
          <span class="input-group-text bg-light border-end-0"><i class="bi bi-envelope text-muted"></i></span>
          <input type="email" name="email" class="form-control border-start-0 ps-0"
                 placeholder="your@email.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
        </div>
      </div>
      <div class="mb-4">
        <label class="form-label"><?= t('login_password') ?></label>
        <div class="input-group">
          <span class="input-group-text bg-light border-end-0"><i class="bi bi-lock text-muted"></i></span>
          <input type="password" name="password" class="form-control border-start-0 ps-0" placeholder="••••••••" required>
        </div>
      </div>
      <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
        <i class="bi bi-box-arrow-in-right me-2"></i><?= t('login_btn') ?>
      </button>
    </form>
    <hr class="my-3">
    <p class="text-center small text-muted mb-0">
      <?= t('login_no_account') ?> <a href="<?= BASE_URL ?>/register.php" class="text-decoration-none fw-semibold"><?= t('login_create') ?></a>
    </p>
    <p class="text-center mt-3 mb-0" style="font-size:.7rem; color:#94a3b8">
      Demo accounts — password: <strong>password123</strong><br>
      Resident: ali@gmail.com &nbsp;·&nbsp; Officer: azri@mpsa.gov.my<br>
      Supervisor: supervisor@mpsa.gov.my &nbsp;·&nbsp; Admin: admin@cityguard.my<br>
      Vendor: buildright@vendor.my
    </p>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
