<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('officer');

$user   = getCurrentUser();
$db     = Database::getInstance()->getConnection();
$filter = $_GET['status'] ?? '';
$sql    = "SELECT c.*, v.name AS vendor_name FROM cases c LEFT JOIN users v ON v.id = c.vendor_id WHERE c.assigned_to = ?";
$params = [$user['id']];
if ($filter && in_array($filter, ['assigned','in_progress','resolved'])) { $sql .= " AND c.status = ?"; $params[] = $filter; }
$sql .= " ORDER BY FIELD(c.priority,'high','medium','low'), c.reported_at DESC";
$stmt = $db->prepare($sql); $stmt->execute($params); $cases = $stmt->fetchAll();

$counts = [];
foreach (['assigned','in_progress','resolved'] as $s) {
    $q = $db->prepare("SELECT COUNT(*) FROM cases WHERE assigned_to = ? AND status = ?"); $q->execute([$user['id'], $s]); $counts[$s] = (int)$q->fetchColumn();
}

$page_title = t('off_cases_title'); $active_nav = 'cases'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon yellow"><i class="bi bi-hourglass-split"></i></div><div><p class="stat-label"><?= t('off_action_req') ?></p><p class="stat-value"><?= $counts['assigned'] ?></p></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon blue"><i class="bi bi-tools"></i></div><div><p class="stat-label"><?= t('off_in_progress') ?></p><p class="stat-value"><?= $counts['in_progress'] ?></p></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon green"><i class="bi bi-check-circle"></i></div><div><p class="stat-label"><?= t('off_resolved') ?></p><p class="stat-value"><?= $counts['resolved'] ?></p></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon sky"><i class="bi bi-clipboard2"></i></div><div><p class="stat-label"><?= t('off_total') ?></p><p class="stat-value"><?= array_sum($counts) ?></p></div></div></div>
</div>

<div class="d-flex gap-2 mb-3 flex-wrap">
  <a href="?status=" class="btn btn-sm <?= $filter === '' ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('lbl_all') ?></a>
  <a href="?status=assigned" class="btn btn-sm <?= $filter === 'assigned' ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('off_action_req') ?></a>
  <a href="?status=in_progress" class="btn btn-sm <?= $filter === 'in_progress' ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('off_in_progress') ?></a>
  <a href="?status=resolved" class="btn btn-sm <?= $filter === 'resolved' ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('off_resolved') ?></a>
</div>

<div class="cg-card">
  <div class="cg-card-header"><i class="bi bi-clipboard2-check me-2 text-primary"></i><?= t('off_case_list') ?></div>
  <?php if (empty($cases)): ?>
    <div class="cg-card-body text-center py-5 text-muted"><i class="bi bi-inbox fs-1 d-block mb-2"></i><?= t('off_no_cases') ?></div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="cg-table">
      <thead><tr><th><?= t('th_code') ?></th><th><?= t('th_title') ?></th><th><?= t('th_category') ?></th><th class="hide-mobile"><?= t('th_address') ?></th><th><?= t('th_priority') ?></th><th><?= t('th_status') ?></th><th class="hide-mobile"><?= t('th_vendor') ?></th><th class="hide-mobile"><?= t('th_photo') ?></th><th><?= t('th_actions') ?></th></tr></thead>
      <tbody>
      <?php foreach ($cases as $c):
        $sc = STATUS_CONFIG[$c['status']] ?? ['label' => $c['status']];
        $pc = PRIORITY_CONFIG[$c['priority']] ?? ['label' => $c['priority']];
      ?>
        <tr>
          <td><code class="small"><?= htmlspecialchars($c['case_code']) ?></code></td>
          <td class="fw-semibold" style="max-width:180px"><?= htmlspecialchars($c['title']) ?></td>
          <td class="text-muted small"><?= htmlspecialchars($c['category']) ?></td>
          <td class="hide-mobile text-muted small" style="max-width:150px"><?= htmlspecialchars($c['address'] ?? '') ?></td>
          <td><span class="badge badge-priority-<?= $c['priority'] ?>"><?= t('pri_' . $c['priority']) ?></span></td>
          <td><span class="badge badge-status-<?= $c['status'] ?>"><?= t('status_' . $c['status']) ?></span></td>
          <td class="hide-mobile small text-success"><?= $c['vendor_name'] ? htmlspecialchars($c['vendor_name']) : '<span class="text-muted">—</span>' ?></td>
          <td class="hide-mobile">
            <?php if (!empty($c['report_photo'])): ?>
              <img src="<?= UPLOAD_REPORTS_URL . htmlspecialchars($c['report_photo']) ?>"
                   style="width:40px;height:40px;object-fit:cover;border-radius:6px;cursor:pointer"
                   onclick="openPhoto('<?= UPLOAD_REPORTS_URL . htmlspecialchars($c['report_photo']) ?>')" title="View photo">
            <?php else: ?><span class="text-muted">—</span><?php endif; ?>
          </td>
          <td>
            <div class="d-flex gap-1">
              <button class="btn btn-sm btn-outline-secondary btn-icon"
                      onclick="openDetail(<?= htmlspecialchars(json_encode([
                        'code'        => $c['case_code'],
                        'title'       => $c['title'],
                        'status'      => $c['status'],
                        'priority'    => $c['priority'],
                        'category'    => $c['category'],
                        'address'     => $c['address'] ?? '',
                        'description' => $c['description'] ?? '',
                        'photo'       => !empty($c['report_photo']) ? UPLOAD_REPORTS_URL . $c['report_photo'] : '',
                        'reporter'    => '',
                        'officer'     => $user['name'],
                        'vendor'      => $c['vendor_name'] ?? '',
                        'date'        => date('d M Y, H:i', strtotime($c['reported_at'])),
                      ]), ENT_QUOTES) ?>)"
                      title="<?= t('btn_view') ?>"><i class="bi bi-eye"></i></button>
              <?php if (in_array($c['status'], ['assigned','in_progress'])): ?>
                <a href="<?= BASE_URL ?>/officer/checkin.php?case_id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-primary btn-icon" title="GPS Check-in"><i class="bi bi-geo-alt"></i></a>
                <a href="<?= BASE_URL ?>/officer/resolve.php?case_id=<?= $c['id'] ?>" class="btn btn-sm btn-success btn-icon" title="Resolve"><i class="bi bi-check2"></i></a>
              <?php endif; ?>
              <?php if ($c['latitude'] && $c['longitude']): ?>
                <a href="https://maps.google.com/?q=<?= $c['latitude'] ?>,<?= $c['longitude'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary btn-icon" title="Map"><i class="bi bi-map"></i></a>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php $layout = 'dash'; include __DIR__ . '/../includes/footer.php'; ?>
