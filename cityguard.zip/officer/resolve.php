<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('officer');

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();
$preselect = (int)($_GET['case_id'] ?? 0);
$stmt = $db->prepare("SELECT c.*, v.name AS vendor_name FROM cases c LEFT JOIN users v ON v.id=c.vendor_id WHERE c.assigned_to = ? AND c.status IN ('assigned','in_progress') ORDER BY FIELD(c.priority,'high','medium','low')");
$stmt->execute([$user['id']]); $active_cases = $stmt->fetchAll();

$page_title = t('off_resolve_title'); $active_nav = 'resolve'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="row g-4">
  <div class="col-lg-7">
    <div class="cg-card">
      <div class="cg-card-header"><i class="bi bi-check2-circle text-success me-2"></i><?= t('btn_resolve') ?></div>
      <div class="cg-card-body">
        <div id="alert-area"></div>

        <form id="resolve-form" enctype="multipart/form-data">
          <div class="mb-3">
            <label class="form-label fw-semibold"><?= t('off_select_case') ?></label>
            <select id="case-select" name="case_id" class="form-select" onchange="loadCase(this.value)" required>
              <option value=""><?= t('off_select_ph') ?></option>
              <?php foreach ($active_cases as $c): ?>
                <option value="<?= $c['id'] ?>" <?= $preselect === (int)$c['id'] ? 'selected' : '' ?>>
                  [<?= htmlspecialchars($c['case_code']) ?>] <?= htmlspecialchars($c['title']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div id="case-info" style="display:none" class="alert alert-info small py-2 mb-3"></div>

          <div class="mb-3">
            <label class="form-label fw-semibold"><?= t('off_status_lbl') ?></label>
            <select name="resolution_status" class="form-select">
              <option value="resolved"><?= t('off_resolved_opt') ?></option>
              <option value="in_progress"><?= t('off_progress_opt') ?></option>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold"><?= t('off_evidence_lbl') ?></label>
            <div class="upload-zone" onclick="document.getElementById('photo-inp').click()">
              <img id="preview-img" src="" style="display:none;max-height:180px;border-radius:8px" class="mb-2">
              <div id="upload-ph"><i class="bi bi-camera text-muted fs-3"></i><p class="text-muted small mt-2 mb-0"><?= t('off_evidence_ph') ?></p></div>
            </div>
            <input type="file" id="photo-inp" name="evidence_photo" accept="image/*" capture="environment"
                   style="display:none" onchange="previewPhoto(this)">
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold"><?= t('off_notes_lbl') ?></label>
            <textarea name="notes" class="form-control" rows="3" placeholder="<?= t('off_notes_ph') ?>"></textarea>
          </div>

          <button type="submit" class="btn btn-success" id="submit-btn">
            <i class="bi bi-send me-1"></i><?= t('btn_resolve') ?>
          </button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="cg-card" id="case-detail-card" style="display:none">
      <div class="cg-card-header"><i class="bi bi-info-circle me-2"></i><?= t('off_case_details') ?></div>
      <div class="cg-card-body" id="case-detail-body"></div>
    </div>
  </div>
</div>

<?php
$cases_json    = json_encode(array_column($active_cases, null, 'id'));
$t_select_first = t('off_select_first');
$t_submitting   = t('btn_submitting');
$t_resolve      = t('btn_resolve');
$t_resolve_ok   = t('off_resolve_ok');
$t_conn_error   = t('msg_conn_error');
$lbl_code       = t('lbl_case_code');
$lbl_cat        = t('lbl_category');
$lbl_pri        = t('lbl_priority');
$lbl_addr       = t('lbl_address');
$lbl_vendor     = t('lbl_vendor');
$extra_js = <<<JS
<script>
const casesData = $cases_json;
function loadCase(id) {
  const c = casesData[id];
  const info = document.getElementById('case-info');
  const card = document.getElementById('case-detail-card');
  if (!c) { info.style.display='none'; card.style.display='none'; return; }
  info.style.display='';
  info.innerHTML = '<i class="bi bi-tag me-2"></i>' + c.category
    + (c.address ? ' &nbsp;·&nbsp; <i class="bi bi-geo-alt me-1"></i>' + c.address : '')
    + (c.vendor_name ? ' &nbsp;·&nbsp; <span class="text-success"><i class="bi bi-building me-1"></i>' + c.vendor_name + '</span>' : '');
  document.getElementById('case-detail-body').innerHTML =
    '<dl class="row small mb-0">' +
    '<dt class="col-5 text-muted">{$lbl_code}</dt><dd class="col-7"><code>' + c.case_code + '</code></dd>' +
    '<dt class="col-5 text-muted">{$lbl_cat}</dt><dd class="col-7">' + c.category + '</dd>' +
    '<dt class="col-5 text-muted">{$lbl_pri}</dt><dd class="col-7">' + c.priority + '</dd>' +
    '<dt class="col-5 text-muted">{$lbl_addr}</dt><dd class="col-7">' + (c.address||'—') + '</dd>' +
    (c.vendor_name ? '<dt class="col-5 text-muted">{$lbl_vendor}</dt><dd class="col-7 text-success">' + c.vendor_name + '</dd>' : '') +
    '</dl>';
  card.style.display='';
}
function previewPhoto(input) {
  if (!input.files[0]) return;
  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById('preview-img').src = e.target.result;
    document.getElementById('preview-img').style.display = '';
    document.getElementById('upload-ph').style.display = 'none';
  };
  reader.readAsDataURL(input.files[0]);
}
document.getElementById('resolve-form').addEventListener('submit', async function(e) {
  e.preventDefault();
  if (!document.getElementById('case-select').value) {
    alert('{$t_select_first}'); return;
  }
  const btn = document.getElementById('submit-btn');
  btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>{$t_submitting}';
  try {
    const res  = await fetch(BASE_URL + '/api/case_resolve.php', { method:'POST', body: new FormData(this) });
    const data = await res.json();
    if (data.success) {
      document.getElementById('alert-area').innerHTML = '<div class="alert alert-success"><i class="bi bi-check-circle me-2"></i>{$t_resolve_ok}</div>';
      setTimeout(() => window.location = BASE_URL + '/officer/', 1800);
    } else {
      document.getElementById('alert-area').innerHTML = '<div class="alert alert-danger">' + (data.error||'Error.') + '</div>';
      btn.disabled = false; btn.innerHTML = '<i class="bi bi-send me-1"></i>{$t_resolve}';
    }
  } catch {
    document.getElementById('alert-area').innerHTML = '<div class="alert alert-danger">{$t_conn_error}</div>';
    btn.disabled = false; btn.innerHTML = '<i class="bi bi-send me-1"></i>{$t_resolve}';
  }
});
const sel = document.getElementById('case-select');
if (sel.value) loadCase(sel.value);
</script>
JS;
include __DIR__ . '/../includes/footer.php';
