<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('officer');

$user      = getCurrentUser();
$db        = Database::getInstance()->getConnection();
$preselect = (int)($_GET['case_id'] ?? 0);
$stmt      = $db->prepare("SELECT id, case_code, title FROM cases WHERE assigned_to = ? AND status IN ('assigned','in_progress') ORDER BY reported_at");
$stmt->execute([$user['id']]); $active_cases = $stmt->fetchAll();

$today = $db->prepare("SELECT oc.*, c.case_code, c.title FROM officer_checkins oc LEFT JOIN cases c ON c.id = oc.case_id WHERE oc.officer_id = ? AND DATE(oc.checkin_at) = CURDATE() ORDER BY oc.checkin_at DESC");
$today->execute([$user['id']]); $today_checkins = $today->fetchAll();

$page_title = t('off_checkin_title'); $active_nav = 'checkin'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="row g-4">
  <div class="col-lg-6">
    <div class="cg-card">
      <div class="cg-card-header"><i class="bi bi-geo-alt text-primary me-2"></i><?= t('btn_checkin') ?></div>
      <div class="cg-card-body">
        <div id="gps-status-box" class="alert alert-info small py-2 mb-3">
          <i class="bi bi-info-circle me-2"></i><?= t('off_ci_hint') ?>
        </div>
        <div class="row g-3 mb-3">
          <div class="col-6"><label class="form-label"><?= t('off_lat') ?></label><input type="text" id="lat" class="form-control" readonly placeholder="<?= t('off_autodetect') ?>"></div>
          <div class="col-6"><label class="form-label"><?= t('off_lon') ?></label><input type="text" id="lon" class="form-control" readonly placeholder="<?= t('off_autodetect') ?>"></div>
        </div>
        <div class="mb-3">
          <label class="form-label"><?= t('off_case_optional') ?></label>
          <select id="case-select" class="form-select">
            <option value=""><?= t('off_ci_general') ?></option>
            <?php foreach ($active_cases as $c): ?>
              <option value="<?= $c['id'] ?>" <?= $preselect === (int)$c['id'] ? 'selected' : '' ?>>
                [<?= htmlspecialchars($c['case_code']) ?>] <?= htmlspecialchars($c['title']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="d-flex gap-2">
          <button class="btn btn-outline-primary" onclick="detectGPS()"><i class="bi bi-crosshair me-1"></i><?= t('btn_detect_gps') ?></button>
          <button class="btn btn-success" id="checkin-btn" onclick="submitCheckin()" disabled>
            <i class="bi bi-geo-alt-fill me-1"></i><?= t('btn_checkin') ?>
          </button>
        </div>
        <div id="result-area" class="mt-3"></div>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="cg-card">
      <div class="cg-card-header"><i class="bi bi-list-check me-2"></i><?= t('off_ci_today') ?> (<?= count($today_checkins) ?>)</div>
      <?php if (empty($today_checkins)): ?>
        <div class="cg-card-body text-center py-4 text-muted small"><i class="bi bi-geo fs-2 d-block mb-2"></i><?= t('off_ci_none') ?></div>
      <?php else: ?>
        <ul class="list-group list-group-flush">
          <?php foreach ($today_checkins as $ci): ?>
            <li class="list-group-item px-4 py-3">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <div class="fw-semibold small"><?= $ci['case_code'] ? htmlspecialchars('[' . $ci['case_code'] . '] ' . $ci['title']) : t('off_ci_general2') ?></div>
                  <div class="text-muted" style="font-size:.75rem"><i class="bi bi-geo-alt me-1"></i><?= $ci['latitude'] ?>, <?= $ci['longitude'] ?><?= $ci['accuracy'] ? ' ±' . round($ci['accuracy']) . 'm' : '' ?></div>
                </div>
                <span class="text-muted small"><?= date('H:i', strtotime($ci['checkin_at'])) ?></span>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php
$t_detecting  = t('res_gps_detecting');
$t_detected   = 'Location detected: ';
$t_gps_failed = t('res_gps_failed');
$t_recording  = t('btn_recording');
$t_checkin    = t('btn_checkin');
$t_ci_success = t('off_ci_success');
$extra_js = <<<JS
<script>
let gpsLat = null, gpsLon = null, gpsAcc = null;
function detectGPS() {
  const box = document.getElementById('gps-status-box');
  box.className = 'alert alert-warning small py-2 mb-3';
  box.innerHTML = '<div class="spinner-border spinner-border-sm me-2"></div>{$t_detecting}';
  if (!navigator.geolocation) { box.innerHTML = 'GPS not supported.'; return; }
  navigator.geolocation.getCurrentPosition(pos => {
    gpsLat = pos.coords.latitude; gpsLon = pos.coords.longitude; gpsAcc = pos.coords.accuracy;
    document.getElementById('lat').value = gpsLat.toFixed(7);
    document.getElementById('lon').value = gpsLon.toFixed(7);
    box.className = 'alert alert-success small py-2 mb-3';
    box.innerHTML = '<i class="bi bi-check-circle me-2"></i>{$t_detected}' + gpsLat.toFixed(5) + ', ' + gpsLon.toFixed(5) + ' (±' + Math.round(gpsAcc) + 'm)';
    document.getElementById('checkin-btn').disabled = false;
  }, () => {
    box.className = 'alert alert-danger small py-2 mb-3';
    box.innerHTML = '<i class="bi bi-exclamation-circle me-2"></i>{$t_gps_failed}';
  }, { enableHighAccuracy: true, timeout: 10000 });
}
async function submitCheckin() {
  const btn = document.getElementById('checkin-btn');
  btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>{$t_recording}';
  const res  = await fetch(BASE_URL + '/api/case_checkin.php', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ lat: gpsLat, lon: gpsLon, accuracy: gpsAcc, case_id: document.getElementById('case-select').value || null })
  });
  const data = await res.json();
  const area = document.getElementById('result-area');
  if (data.success) {
    area.innerHTML = '<div class="alert alert-success small py-2"><i class="bi bi-check-circle me-2"></i>{$t_ci_success}</div>';
    setTimeout(() => location.reload(), 1500);
  } else {
    area.innerHTML = '<div class="alert alert-danger small py-2">' + (data.error||'Error.') + '</div>';
    btn.disabled = false; btn.innerHTML = '<i class="bi bi-geo-alt-fill me-1"></i>{$t_checkin}';
  }
}
</script>
JS;
include __DIR__ . '/../includes/footer.php';
