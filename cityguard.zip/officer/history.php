<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('officer');

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();
$stmt = $db->prepare("
    SELECT c.*, r.resolved_at, r.officer_notes, r.ai_completion, r.evidence_photo, r.approved_at, a.name AS approver_name
    FROM cases c
    JOIN case_resolutions r ON r.case_id = c.id
    LEFT JOIN users a ON a.id = r.approved_by
    WHERE r.officer_id = ?
    ORDER BY r.resolved_at DESC
");
$stmt->execute([$user['id']]); $history = $stmt->fetchAll();

$page_title = t('off_hist_title'); $active_nav = 'history'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="cg-card">
  <div class="cg-card-header"><i class="bi bi-clock-history me-2 text-primary"></i><?= t('off_hist_resolved') ?> (<?= count($history) ?>)</div>
  <?php if (empty($history)): ?>
    <div class="cg-card-body text-center py-5 text-muted"><i class="bi bi-inbox fs-1 d-block mb-2"></i><?= t('off_hist_none') ?></div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="cg-table">
      <thead><tr><th><?= t('th_code') ?></th><th><?= t('th_title') ?></th><th><?= t('th_category') ?></th><th><?= t('th_resolved_at') ?></th><th><?= t('th_status') ?></th><th><?= t('th_photos') ?></th></tr></thead>
      <tbody>
      <?php foreach ($history as $c): ?>
        <tr>
          <td><code class="small"><?= htmlspecialchars($c['case_code']) ?></code></td>
          <td class="fw-semibold"><?= htmlspecialchars($c['title']) ?></td>
          <td class="text-muted small"><?= htmlspecialchars($c['category']) ?></td>
          <td class="text-muted small"><?= date('d M Y H:i', strtotime($c['resolved_at'])) ?></td>
          <td>
            <?php if (!empty($c['approved_at'])): ?>
              <span class="badge badge-status-approved"><?= t('status_approved') ?></span>
            <?php else: ?>
              <span class="badge badge-status-resolved"><?= t('off_pending_appr') ?></span>
            <?php endif; ?>
          </td>
          <td>
            <div class="d-flex gap-1 align-items-center">
              <?php if (!empty($c['report_photo'])): ?>
                <img src="<?= UPLOAD_REPORTS_URL . htmlspecialchars($c['report_photo']) ?>"
                     style="width:36px;height:36px;object-fit:cover;border-radius:5px;cursor:pointer"
                     onclick="openPhoto('<?= UPLOAD_REPORTS_URL . htmlspecialchars($c['report_photo']) ?>')" title="Report photo">
              <?php endif; ?>
              <?php if (!empty($c['evidence_photo'])): ?>
                <img src="<?= UPLOAD_EVIDENCE_URL . htmlspecialchars($c['evidence_photo']) ?>"
                     style="width:36px;height:36px;object-fit:cover;border-radius:5px;cursor:pointer;border:2px solid #10b981"
                     onclick="openPhoto('<?= UPLOAD_EVIDENCE_URL . htmlspecialchars($c['evidence_photo']) ?>')" title="Evidence photo">
              <?php endif; ?>
              <?php if (empty($c['report_photo']) && empty($c['evidence_photo'])): ?>
                <span class="text-muted small">—</span>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
