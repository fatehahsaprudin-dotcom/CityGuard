<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('officer');

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();

$q1 = $db->prepare("SELECT COUNT(*) FROM cases WHERE assigned_to = ?"); $q1->execute([$user['id']]); $total = (int)$q1->fetchColumn();
$q2 = $db->prepare("SELECT COUNT(*) FROM cases WHERE assigned_to = ? AND status IN ('resolved','approved')"); $q2->execute([$user['id']]); $resolved = (int)$q2->fetchColumn();
$q3 = $db->prepare("SELECT COUNT(*) FROM cases WHERE assigned_to = ? AND status IN ('assigned','in_progress')"); $q3->execute([$user['id']]); $pending = (int)$q3->fetchColumn();
$q4 = $db->prepare("SELECT COUNT(*) FROM officer_checkins WHERE officer_id = ? AND DATE(checkin_at) = CURDATE()"); $q4->execute([$user['id']]); $checkins_today = (int)$q4->fetchColumn();
$q5 = $db->prepare("SELECT AVG(TIMESTAMPDIFF(MINUTE, c.assigned_at, r.resolved_at)) FROM cases c JOIN case_resolutions r ON r.case_id=c.id WHERE c.assigned_to=? AND c.assigned_at IS NOT NULL"); $q5->execute([$user['id']]); $avg_min = round((float)$q5->fetchColumn());
$q6 = $db->prepare("SELECT category, COUNT(*) AS cnt FROM cases WHERE assigned_to = ? GROUP BY category ORDER BY cnt DESC LIMIT 5"); $q6->execute([$user['id']]); $by_cat = $q6->fetchAll();
$pct = $total > 0 ? round($resolved / $total * 100) : 0;

$page_title = t('off_stats_title'); $active_nav = 'stats'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon blue"><i class="bi bi-clipboard2"></i></div><div><p class="stat-label"><?= t('lbl_total') ?></p><p class="stat-value"><?= $total ?></p></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon green"><i class="bi bi-check-circle"></i></div><div><p class="stat-label"><?= t('off_resolved') ?></p><p class="stat-value"><?= $resolved ?></p></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon yellow"><i class="bi bi-hourglass"></i></div><div><p class="stat-label"><?= t('off_action_req') ?></p><p class="stat-value"><?= $pending ?></p></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon sky"><i class="bi bi-geo-alt"></i></div><div><p class="stat-label"><?= t('off_checkins_today') ?></p><p class="stat-value"><?= $checkins_today ?></p></div></div></div>
</div>

<div class="row g-4">
  <div class="col-md-6">
    <div class="cg-card h-100">
      <div class="cg-card-header"><i class="bi bi-bar-chart me-2 text-primary"></i><?= t('off_res_rate') ?></div>
      <div class="cg-card-body">
        <div class="d-flex justify-content-between mb-1"><span class="small fw-semibold"><?= t('off_overall') ?></span><span class="small text-muted"><?= $resolved ?>/<?= $total ?></span></div>
        <div class="progress mb-4" style="height:10px;border-radius:99px">
          <div class="progress-bar bg-success" style="width:<?= $pct ?>%"></div>
        </div>
        <div class="row g-3 text-center">
          <div class="col-4"><div class="fw-bold fs-4 text-success"><?= $pct ?>%</div><div class="text-muted small"><?= t('off_res_rate') ?></div></div>
          <div class="col-4"><div class="fw-bold fs-4"><?= $avg_min ?: '—' ?><?= $avg_min ? '<small class="fs-6 text-muted"> min</small>' : '' ?></div><div class="text-muted small"><?= t('off_avg_response') ?></div></div>
          <div class="col-4"><div class="fw-bold fs-4"><?= $checkins_today ?></div><div class="text-muted small"><?= t('off_today') ?></div></div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="cg-card h-100">
      <div class="cg-card-header"><i class="bi bi-tag me-2 text-primary"></i><?= t('off_by_cat') ?></div>
      <div class="cg-card-body">
        <?php if (empty($by_cat)): ?>
          <p class="text-muted text-center py-4"><?= t('off_no_data') ?></p>
        <?php else: $max = $by_cat[0]['cnt']; ?>
          <?php foreach ($by_cat as $row): $w = round($row['cnt'] / $max * 100); ?>
          <div class="mb-3">
            <div class="d-flex justify-content-between small mb-1"><span><?= htmlspecialchars($row['category']) ?></span><span class="text-muted"><?= $row['cnt'] ?> <?= t('lbl_cases') ?></span></div>
            <div class="progress" style="height:7px;border-radius:99px"><div class="progress-bar bg-primary" style="width:<?= $w ?>%"></div></div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php $layout = 'dash'; include __DIR__ . '/../includes/footer.php'; ?>
