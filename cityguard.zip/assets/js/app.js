// CityGuard — Global JS

document.addEventListener('DOMContentLoaded', () => {
  initAlerts();
  initTooltips();
  initSidebar();
  if (document.getElementById('pending-count')) updatePendingCount();
});

function initAlerts() {
  document.querySelectorAll('.alert-dismissible').forEach(el => {
    setTimeout(() => bootstrap.Alert.getOrCreateInstance(el)?.close(), 4000);
  });
}

function initTooltips() {
  document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
    bootstrap.Tooltip.getOrCreateInstance(el);
  });
}

function initSidebar() {
  const hamburger = document.getElementById('hamburger');
  const sidebar   = document.getElementById('cg-sidebar');
  const overlay   = document.getElementById('cg-overlay');
  if (!hamburger || !sidebar) return;

  hamburger.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    overlay?.classList.toggle('show');
  });
  overlay?.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  });
}

function updatePendingCount() {
  fetch(BASE_URL + '/api/get_counts.php')
    .then(r => r.json())
    .then(d => {
      const el = document.getElementById('pending-count');
      if (!el) return;
      el.textContent = d.pending || 0;
      el.style.display = d.pending > 0 ? '' : 'none';
    })
    .catch(() => {});
}

function confirmAction(msg, callback) {
  if (confirm(msg)) callback();
}

function formatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

function openPhoto(url) {
  document.getElementById('lightbox-img').src = url;
  bootstrap.Modal.getOrCreateInstance(document.getElementById('photoLightbox')).show();
}

// Make BASE_URL available globally — set by PHP in each page
// openDetail() is defined inline in footer.php to guarantee availability
