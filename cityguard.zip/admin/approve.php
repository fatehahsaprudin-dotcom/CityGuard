<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('admin');

$db = Database::getInstance()->getConnection();
$stmt = $db->query("
    SELECT r.*, c.case_code, c.title, c.category, c.address, c.priority,
           o.name AS officer_name, o.dept AS officer_dept
    FROM case_resolutions r
    JOIN cases c ON c.id = r.case_id
    JOIN users o ON o.id = r.officer_id
    WHERE r.approved_by IS NULL
    ORDER BY r.resolved_at ASC
");
$pending = $stmt->fetchAll();

$done_stmt = $db->query("
    SELECT r.*, c.case_code, c.title, c.category,
           o.name AS officer_name, a.name AS approver_name
    FROM case_resolutions r
    JOIN cases c ON c.id = r.case_id
    JOIN users o ON o.id = r.officer_id
    LEFT JOIN users a ON a.id = r.approved_by
    WHERE r.approved_by IS NOT NULL
    ORDER BY r.approved_at DESC LIMIT 20
");
$approved_list = $done_stmt->fetchAll();

$page_title = t('adm_approve_title'); $active_nav = 'approve'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<?php if (!empty($pending)): ?>
<div class="cg-card mb-4">
  <div class="cg-card-header">
    <i class="bi bi-patch-exclamation me-2 text-warning"></i><?= t('adm_pending_appr') ?>
    <span class="badge bg-warning text-dark ms-1"><?= count($pending) ?></span>
  </div>
  <div class="table-responsive">
    <table class="cg-table">
      <thead><tr><th><?= t('th_code') ?></th><th><?= t('th_title') ?></th><th><?= t('th_officer') ?></th><th><?= t('th_priority') ?></th><th><?= t('th_resolved_at') ?></th><th><?= t('th_evidence') ?></th><th><?= t('th_actions') ?></th></tr></thead>
      <tbody>
      <?php foreach ($pending as $r):
        $pc = PRIORITY_CONFIG[$r['priority']] ?? ['label'=>$r['priority']];
      ?>
        <tr>
          <td><code class="small"><?= htmlspecialchars($r['case_code']) ?></code></td>
          <td class="fw-semibold" style="max-width:160px"><?= htmlspecialchars($r['title']) ?></td>
          <td class="small"><?= htmlspecialchars($r['officer_name']) ?><div class="text-muted" style="font-size:.72rem"><?= htmlspecialchars($r['officer_dept'] ?? '') ?></div></td>
          <td><span class="badge badge-priority-<?= $r['priority'] ?>"><?= t('pri_' . $r['priority']) ?></span></td>
          <td class="text-muted small"><?= date('d M Y H:i', strtotime($r['resolved_at'])) ?></td>
          <td>
            <?php if ($r['evidence_photo']): ?>
              <img src="<?= UPLOAD_EVIDENCE_URL . htmlspecialchars($r['evidence_photo']) ?>"
                   style="width:40px;height:40px;object-fit:cover;border-radius:6px;cursor:pointer;border:2px solid #0ea5e9"
                   onclick="openPhoto('<?= UPLOAD_EVIDENCE_URL . htmlspecialchars($r['evidence_photo']) ?>')"
                   title="Evidence photo">
            <?php else: ?><span class="text-muted small">—</span><?php endif; ?>
          </td>
          <td>
            <button class="btn btn-sm btn-success me-1" onclick="approveCase(<?= $r['case_id'] ?>)"><i class="bi bi-check2 me-1"></i><?= t('btn_approve') ?></button>
            <button class="btn btn-sm btn-outline-danger" onclick="rejectCase(<?= $r['case_id'] ?>)"><i class="bi bi-x me-1"></i><?= t('btn_reject') ?></button>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php else: ?>
  <div class="alert alert-success mb-4"><i class="bi bi-check-circle me-2"></i><?= t('adm_no_pending') ?></div>
<?php endif; ?>

<div class="cg-card">
  <div class="cg-card-header"><i class="bi bi-check2-all me-2 text-success"></i><?= t('adm_recent_appr') ?></div>
  <?php if (empty($approved_list)): ?>
    <div class="cg-card-body text-center py-4 text-muted small"><?= t('adm_no_records') ?></div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="cg-table">
      <thead><tr><th><?= t('th_code') ?></th><th><?= t('th_title') ?></th><th><?= t('th_officer') ?></th><th><?= t('th_approved_by') ?></th><th><?= t('th_date') ?></th></tr></thead>
      <tbody>
      <?php foreach ($approved_list as $r): ?>
        <tr>
          <td><code class="small"><?= htmlspecialchars($r['case_code']) ?></code></td>
          <td class="fw-semibold"><?= htmlspecialchars($r['title']) ?></td>
          <td class="small"><?= htmlspecialchars($r['officer_name']) ?></td>
          <td class="small"><?= htmlspecialchars($r['approver_name'] ?? '—') ?></td>
          <td class="text-muted small"><?= date('d M Y H:i', strtotime($r['approved_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php
$t_confirm_appr = t('adm_confirm_appr');
$t_confirm_rej  = t('adm_confirm_rej');
$t_error        = t('msg_error');
$extra_js = <<<JS
<script>
async function approveCase(id) {
  if (!confirm('{$t_confirm_appr}')) return;
  const res = await fetch(BASE_URL + '/api/case_approve.php', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ case_id: id, action: 'approve' })
  });
  const data = await res.json();
  if (data.success) location.reload();
  else alert(data.error || '{$t_error}');
}
async function rejectCase(id) {
  if (!confirm('{$t_confirm_rej}')) return;
  const res = await fetch(BASE_URL + '/api/case_approve.php', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ case_id: id, action: 'reject' })
  });
  const data = await res.json();
  if (data.success) location.reload();
  else alert(data.error || '{$t_error}');
}
</script>
JS;
include __DIR__ . '/../includes/footer.php';
