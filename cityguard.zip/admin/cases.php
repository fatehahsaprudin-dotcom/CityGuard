<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('admin');

$db = Database::getInstance()->getConnection();
$status_filter = $_GET['status'] ?? '';
$sql = "SELECT c.*, r.name AS reporter, o.name AS officer_name, v.name AS vendor_name FROM cases c LEFT JOIN users r ON r.id=c.reported_by LEFT JOIN users o ON o.id=c.assigned_to LEFT JOIN users v ON v.id=c.vendor_id";
$params = [];
if ($status_filter && array_key_exists($status_filter, STATUS_CONFIG)) {
    $sql .= " WHERE c.status=?"; $params[] = $status_filter;
}
$sql .= " ORDER BY c.reported_at DESC";
$stmt = $db->prepare($sql); $stmt->execute($params);
$cases = $stmt->fetchAll();

$page_title = t('adm_cases_title'); $active_nav = 'cases'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="d-flex gap-2 mb-3 flex-wrap">
  <a href="?" class="btn btn-sm <?= !$status_filter ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('lbl_all') ?></a>
  <?php foreach (STATUS_CONFIG as $s => $cfg): ?>
    <a href="?status=<?= $s ?>" class="btn btn-sm <?= $status_filter===$s ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('status_' . $s) ?></a>
  <?php endforeach; ?>
</div>

<div class="cg-card">
  <div class="cg-card-header"><i class="bi bi-folder2-open me-2 text-primary"></i><?= t('adm_cases_title') ?> (<?= count($cases) ?>)</div>
  <div class="table-responsive">
    <table class="cg-table">
      <thead><tr><th><?= t('th_code') ?></th><th><?= t('th_title') ?></th><th><?= t('th_category') ?></th><th><?= t('th_priority') ?></th><th><?= t('th_status') ?></th><th><?= t('th_officer') ?></th><th class="hide-mobile"><?= t('th_photo') ?></th><th class="hide-mobile"><?= t('th_reporter') ?></th><th class="hide-mobile"><?= t('th_date') ?></th><th></th></tr></thead>
      <tbody>
      <?php foreach ($cases as $c):
        $sc = STATUS_CONFIG[$c['status']] ?? ['label'=>$c['status']];
        $pc = PRIORITY_CONFIG[$c['priority']] ?? ['label'=>$c['priority']];
      ?>
        <tr>
          <td><code class="small"><?= htmlspecialchars($c['case_code']) ?></code></td>
          <td class="fw-semibold" style="max-width:160px"><?= htmlspecialchars($c['title']) ?></td>
          <td class="text-muted small"><?= htmlspecialchars($c['category']) ?></td>
          <td><span class="badge badge-priority-<?= $c['priority'] ?>"><?= t('pri_' . $c['priority']) ?></span></td>
          <td><span class="badge badge-status-<?= $c['status'] ?>"><?= t('status_' . $c['status']) ?></span></td>
          <td class="small"><?= htmlspecialchars($c['officer_name'] ?? '—') ?></td>
          <td class="hide-mobile">
            <?php if (!empty($c['report_photo'])): ?>
              <img src="<?= UPLOAD_REPORTS_URL . htmlspecialchars($c['report_photo']) ?>"
                   style="width:40px;height:40px;object-fit:cover;border-radius:6px;cursor:pointer"
                   onclick="openPhoto('<?= UPLOAD_REPORTS_URL . htmlspecialchars($c['report_photo']) ?>')" title="View photo">
            <?php else: ?><span class="text-muted">—</span><?php endif; ?>
          </td>
          <td class="hide-mobile small text-muted"><?= htmlspecialchars($c['reporter'] ?? '—') ?></td>
          <td class="hide-mobile text-muted small"><?= date('d M Y', strtotime($c['reported_at'])) ?></td>
          <td>
            <button class="btn btn-sm btn-outline-secondary btn-icon"
                    onclick="openDetail(<?= htmlspecialchars(json_encode([
                      'code'        => $c['case_code'],
                      'title'       => $c['title'],
                      'status'      => $c['status'],
                      'priority'    => $c['priority'],
                      'category'    => $c['category'],
                      'address'     => $c['address'] ?? '',
                      'description' => $c['description'] ?? '',
                      'photo'       => !empty($c['report_photo']) ? UPLOAD_REPORTS_URL . $c['report_photo'] : '',
                      'reporter'    => $c['reporter'] ?? '',
                      'officer'     => $c['officer_name'] ?? '',
                      'vendor'      => $c['vendor_name'] ?? '',
                      'date'        => date('d M Y, H:i', strtotime($c['reported_at'])),
                    ]), ENT_QUOTES) ?>)"
                    title="<?= t('btn_view') ?>"><i class="bi bi-eye"></i></button>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php $layout = 'dash'; include __DIR__ . '/../includes/footer.php'; ?>
