<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('admin');

$db = Database::getInstance()->getConnection();

$categories = $db->query("
    SELECT c.id, c.name, c.name_bm, c.dept, c.is_active, cv.vendor_id, u.name AS vendor_name
    FROM categories c
    LEFT JOIN category_vendors cv ON cv.category_id = c.id
    LEFT JOIN users u ON u.id = cv.vendor_id
    ORDER BY c.name
")->fetchAll();

$vendors = $db->query("SELECT id, name, unit FROM users WHERE role='vendor' AND is_active=1 ORDER BY name")->fetchAll();

$page_title = t('adm_cat_title'); $active_nav = 'categories'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="row g-4">

  <div class="col-lg-4">
    <div class="cg-card">
      <div class="cg-card-header"><i class="bi bi-plus-circle text-primary me-2"></i><?= t('adm_add_cat') ?></div>
      <div class="cg-card-body">
        <div id="add-alert"></div>
        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('lbl_category') ?> (EN) <span class="text-danger">*</span></label>
          <input type="text" id="new-name" class="form-control" placeholder="e.g. Broken Pavement">
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('lbl_category') ?> (BM)</label>
          <input type="text" id="new-name-bm" class="form-control" placeholder="cth. Jalan Rosak">
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('lbl_dept') ?></label>
          <input type="text" id="new-dept" class="form-control" placeholder="e.g. JKR">
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('lbl_vendor') ?></label>
          <select id="new-vendor" class="form-select">
            <option value="">— None —</option>
            <?php foreach ($vendors as $v): ?>
              <option value="<?= $v['id'] ?>"><?= htmlspecialchars($v['name']) ?><?= $v['unit'] ? ' (' . htmlspecialchars($v['unit']) . ')' : '' ?></option>
            <?php endforeach; ?>
          </select>
          <div class="form-text">Vendor auto-assigned when a case of this category is submitted.</div>
        </div>
        <button class="btn btn-primary w-100" onclick="addCategory()">
          <i class="bi bi-plus me-1"></i><?= t('btn_add') ?>
        </button>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="cg-card">
      <div class="cg-card-header"><i class="bi bi-tags me-2 text-primary"></i><?= t('adm_cat_title') ?> (<?= count($categories) ?>)</div>
      <div id="list-alert"></div>
      <?php if (empty($categories)): ?>
        <div class="cg-card-body text-center py-4 text-muted"><?= t('adm_no_data') ?></div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="cg-table">
          <thead><tr><th><?= t('lbl_title') ?> (EN)</th><th><?= t('lbl_title') ?> (BM)</th><th><?= t('lbl_dept') ?></th><th><?= t('lbl_vendor') ?></th><th><?= t('lbl_active') ?></th><th><?= t('th_actions') ?></th></tr></thead>
          <tbody id="cat-tbody">
          <?php foreach ($categories as $cat): ?>
            <tr id="row-<?= $cat['id'] ?>">
              <td class="fw-semibold"><?= htmlspecialchars($cat['name']) ?></td>
              <td class="text-muted small"><?= htmlspecialchars($cat['name_bm'] ?? '—') ?></td>
              <td class="text-muted small"><?= htmlspecialchars($cat['dept'] ?? '—') ?></td>
              <td>
                <select class="form-select form-select-sm" style="min-width:160px"
                        onchange="assignVendor(<?= $cat['id'] ?>, this.value)">
                  <option value="">— None —</option>
                  <?php foreach ($vendors as $v): ?>
                    <option value="<?= $v['id'] ?>" <?= (int)$cat['vendor_id'] === (int)$v['id'] ? 'selected' : '' ?>>
                      <?= htmlspecialchars($v['name']) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td>
                <div class="form-check form-switch mb-0">
                  <input class="form-check-input" type="checkbox" role="switch"
                         <?= $cat['is_active'] ? 'checked' : '' ?>
                         onchange="toggleActive(<?= $cat['id'] ?>, this.checked)">
                </div>
              </td>
              <td>
                <button class="btn btn-sm btn-outline-primary btn-icon me-1"
                        onclick="openEdit(<?= $cat['id'] ?>,'<?= htmlspecialchars(addslashes($cat['name'])) ?>','<?= htmlspecialchars(addslashes($cat['name_bm'] ?? '')) ?>','<?= htmlspecialchars(addslashes($cat['dept'] ?? '')) ?>')"
                        title="<?= t('btn_edit') ?>"><i class="bi bi-pencil"></i></button>
                <button class="btn btn-sm btn-outline-danger btn-icon"
                        onclick="deleteCategory(<?= $cat['id'] ?>,'<?= htmlspecialchars(addslashes($cat['name'])) ?>')"
                        title="<?= t('btn_delete') ?>"><i class="bi bi-trash"></i></button>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1">
  <div class="modal-dialog modal-sm">
    <div class="modal-content border-0" style="border-radius:16px">
      <div class="modal-header border-0">
        <h6 class="modal-title fw-semibold"><?= t('btn_edit') ?> <?= t('lbl_category') ?></h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body pt-0">
        <input type="hidden" id="edit-id">
        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('lbl_title') ?> (EN)</label>
          <input type="text" id="edit-name" class="form-control">
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('lbl_title') ?> (BM)</label>
          <input type="text" id="edit-name-bm" class="form-control">
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('lbl_dept') ?></label>
          <input type="text" id="edit-dept" class="form-control">
        </div>
        <div id="edit-alert"></div>
      </div>
      <div class="modal-footer border-0 pt-0">
        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal"><?= t('btn_cancel') ?></button>
        <button type="button" class="btn btn-primary btn-sm" onclick="saveEdit()"><?= t('btn_save') ?></button>
      </div>
    </div>
  </div>
</div>

<?php
$extra_js = <<<JS
<script>
async function apiCall(payload) {
  const res = await fetch(BASE_URL + '/api/admin_category.php', {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload)
  });
  return res.json();
}
function showAlert(elId, msg, type='success') {
  document.getElementById(elId).innerHTML = '<div class="alert alert-'+type+' small py-2 m-3">'+msg+'</div>';
  setTimeout(() => { const el = document.getElementById(elId); if (el) el.innerHTML = ''; }, 3000);
}
async function addCategory() {
  const name   = document.getElementById('new-name').value.trim();
  const nameBm = document.getElementById('new-name-bm').value.trim();
  const dept   = document.getElementById('new-dept').value.trim();
  const vid    = document.getElementById('new-vendor').value;
  if (!name) { showAlert('add-alert','Category name is required.','danger'); return; }
  const data = await apiCall({ action:'add', name, name_bm: nameBm||null, dept, vendor_id: vid||null });
  if (data.success) { showAlert('add-alert','Category added!'); setTimeout(() => location.reload(), 1000); }
  else showAlert('add-alert', data.error||'Error.','danger');
}
function openEdit(id, name, nameBm, dept) {
  document.getElementById('edit-id').value      = id;
  document.getElementById('edit-name').value    = name;
  document.getElementById('edit-name-bm').value = nameBm;
  document.getElementById('edit-dept').value    = dept;
  document.getElementById('edit-alert').innerHTML = '';
  new bootstrap.Modal(document.getElementById('editModal')).show();
}
async function saveEdit() {
  const id     = document.getElementById('edit-id').value;
  const name   = document.getElementById('edit-name').value.trim();
  const nameBm = document.getElementById('edit-name-bm').value.trim();
  const dept   = document.getElementById('edit-dept').value.trim();
  if (!name) { showAlert('edit-alert','Name is required.','danger'); return; }
  const data = await apiCall({ action:'update', id, name, name_bm: nameBm||null, dept });
  if (data.success) { bootstrap.Modal.getInstance(document.getElementById('editModal')).hide(); location.reload(); }
  else showAlert('edit-alert', data.error||'Error.','danger');
}
async function deleteCategory(id, name) {
  if (!confirm('Delete category "'+name+'"? This cannot be undone.')) return;
  const data = await apiCall({ action:'delete', id });
  if (data.success) { document.getElementById('row-'+id)?.remove(); showAlert('list-alert','Deleted.'); }
  else showAlert('list-alert', data.error||'Error.','danger');
}
async function assignVendor(catId, vendorId) {
  await apiCall({ action:'assign_vendor', category_id: catId, vendor_id: vendorId||null });
}
async function toggleActive(catId, active) {
  await apiCall({ action:'toggle', id: catId, is_active: active ? 1 : 0 });
}
</script>
JS;
include __DIR__ . '/../includes/footer.php';
