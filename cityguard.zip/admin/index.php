<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('admin');

$db = Database::getInstance()->getConnection();

$q = function($sql, $p=[]) use ($db) { $s=$db->prepare($sql); $s->execute($p); return (int)$s->fetchColumn(); };
$total            = $q("SELECT COUNT(*) FROM cases");
$new              = $q("SELECT COUNT(*) FROM cases WHERE status='new'");
$pending_approval = $q("SELECT COUNT(*) FROM case_resolutions WHERE approved_by IS NULL");
$approved         = $q("SELECT COUNT(*) FROM cases WHERE status='approved'");
$officers         = $q("SELECT COUNT(*) FROM users WHERE role='officer' AND is_active=1");
$residents        = $q("SELECT COUNT(*) FROM users WHERE role='resident' AND is_active=1");

$by_cat    = $db->query("SELECT category, COUNT(*) AS cnt FROM cases GROUP BY category ORDER BY cnt DESC LIMIT 6")->fetchAll();
$by_status = $db->query("SELECT status, COUNT(*) AS cnt FROM cases GROUP BY status")->fetchAll();
$recent    = $db->query("SELECT c.*, u.name AS reporter, o.name AS officer_name, v.name AS vendor_name FROM cases c LEFT JOIN users u ON u.id=c.reported_by LEFT JOIN users o ON o.id=c.assigned_to LEFT JOIN users v ON v.id=c.vendor_id ORDER BY c.created_at DESC LIMIT 8")->fetchAll();

$page_title = t('adm_overview'); $active_nav = 'overview'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-2"><div class="stat-card"><div class="stat-icon blue"><i class="bi bi-folder2"></i></div><div><p class="stat-label"><?= t('adm_total_cases') ?></p><p class="stat-value"><?= $total ?></p></div></div></div>
  <div class="col-6 col-md-2"><div class="stat-card"><div class="stat-icon red"><i class="bi bi-inbox"></i></div><div><p class="stat-label"><?= t('sv_new') ?></p><p class="stat-value"><?= $new ?></p></div></div></div>
  <div class="col-6 col-md-2"><div class="stat-card"><div class="stat-icon yellow"><i class="bi bi-patch-check"></i></div><div><p class="stat-label"><?= t('adm_pending') ?></p><p class="stat-value"><?= $pending_approval ?></p></div></div></div>
  <div class="col-6 col-md-2"><div class="stat-card"><div class="stat-icon green"><i class="bi bi-check-circle"></i></div><div><p class="stat-label"><?= t('adm_approved') ?></p><p class="stat-value"><?= $approved ?></p></div></div></div>
  <div class="col-6 col-md-2"><div class="stat-card"><div class="stat-icon sky"><i class="bi bi-person-badge"></i></div><div><p class="stat-label"><?= t('adm_officers') ?></p><p class="stat-value"><?= $officers ?></p></div></div></div>
  <div class="col-6 col-md-2"><div class="stat-card"><div class="stat-icon purple"><i class="bi bi-people"></i></div><div><p class="stat-label"><?= t('adm_residents') ?></p><p class="stat-value"><?= $residents ?></p></div></div></div>
</div>

<div class="row g-4 mb-4">
  <div class="col-md-6">
    <div class="cg-card h-100">
      <div class="cg-card-header"><i class="bi bi-bar-chart me-2 text-primary"></i><?= t('adm_by_cat') ?></div>
      <div class="cg-card-body">
        <?php if (empty($by_cat)): ?>
          <p class="text-muted text-center py-3"><?= t('adm_no_data') ?></p>
        <?php else: $max = $by_cat[0]['cnt']; ?>
          <?php foreach ($by_cat as $row): $w = $max > 0 ? round($row['cnt']/$max*100) : 0; ?>
          <div class="mb-3">
            <div class="d-flex justify-content-between small mb-1">
              <span class="fw-semibold"><?= htmlspecialchars($row['category']) ?></span>
              <span class="text-muted"><?= $row['cnt'] ?> <?= t('lbl_cases') ?></span>
            </div>
            <div class="progress" style="height:8px;border-radius:99px">
              <div class="progress-bar bg-primary" style="width:<?= $w ?>%"></div>
            </div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="cg-card h-100">
      <div class="cg-card-header"><i class="bi bi-pie-chart me-2 text-primary"></i><?= t('adm_by_status') ?></div>
      <div class="cg-card-body">
        <?php foreach ($by_status as $row):
          $sc = STATUS_CONFIG[$row['status']] ?? ['label'=>$row['status'],'color'=>'secondary'];
          $pct = $total > 0 ? round($row['cnt']/$total*100) : 0;
        ?>
        <div class="d-flex align-items-center gap-3 mb-3">
          <span class="badge badge-status-<?= $row['status'] ?>" style="min-width:110px;text-align:left"><?= t('status_' . $row['status']) ?></span>
          <div class="flex-1" style="flex:1">
            <div class="progress" style="height:7px;border-radius:99px">
              <div class="progress-bar" style="width:<?= $pct ?>%;background:var(--bs-<?= $sc['color'] ?>)"></div>
            </div>
          </div>
          <span class="text-muted small" style="min-width:35px;text-align:right"><?= $row['cnt'] ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<div class="cg-card">
  <div class="cg-card-header"><i class="bi bi-clock-history me-2 text-primary"></i><?= t('adm_recent') ?></div>
  <div class="table-responsive">
    <table class="cg-table">
      <thead><tr><th><?= t('th_code') ?></th><th><?= t('th_title') ?></th><th><?= t('th_category') ?></th><th><?= t('th_priority') ?></th><th><?= t('th_status') ?></th><th class="hide-mobile"><?= t('th_reporter') ?></th><th class="hide-mobile"><?= t('th_date') ?></th><th></th></tr></thead>
      <tbody>
      <?php foreach ($recent as $c):
        $sc = STATUS_CONFIG[$c['status']] ?? ['label'=>$c['status']];
        $pc = PRIORITY_CONFIG[$c['priority']] ?? ['label'=>$c['priority']];
      ?>
        <tr>
          <td><code class="small"><?= htmlspecialchars($c['case_code']) ?></code></td>
          <td class="fw-semibold" style="max-width:160px"><?= htmlspecialchars($c['title']) ?></td>
          <td class="text-muted small"><?= htmlspecialchars($c['category']) ?></td>
          <td><span class="badge badge-priority-<?= $c['priority'] ?>"><?= t('pri_' . $c['priority']) ?></span></td>
          <td><span class="badge badge-status-<?= $c['status'] ?>"><?= t('status_' . $c['status']) ?></span></td>
          <td class="hide-mobile text-muted small"><?= htmlspecialchars($c['reporter'] ?? '—') ?></td>
          <td class="hide-mobile text-muted small"><?= date('d M Y', strtotime($c['reported_at'])) ?></td>
          <td>
            <button class="btn btn-sm btn-outline-secondary btn-icon"
                    onclick="openDetail(<?= htmlspecialchars(json_encode([
                      'code'        => $c['case_code'],
                      'title'       => $c['title'],
                      'status'      => $c['status'],
                      'priority'    => $c['priority'],
                      'category'    => $c['category'],
                      'address'     => $c['address'] ?? '',
                      'description' => $c['description'] ?? '',
                      'photo'       => !empty($c['report_photo']) ? UPLOAD_REPORTS_URL . $c['report_photo'] : '',
                      'reporter'    => $c['reporter'] ?? '',
                      'officer'     => $c['officer_name'] ?? '',
                      'vendor'      => $c['vendor_name'] ?? '',
                      'date'        => date('d M Y, H:i', strtotime($c['reported_at'])),
                    ]), ENT_QUOTES) ?>)"
                    title="<?= t('btn_view') ?>"><i class="bi bi-eye"></i></button>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php $layout = 'dash'; include __DIR__ . '/../includes/footer.php'; ?>
