<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('admin');

$db = Database::getInstance()->getConnection();
$rows = $db->query("SELECT `key`, value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);
$currentModel = $rows['ai_model']     ?? 'openai/gpt-oss-120b:free';
$currentTemp  = $rows['ai_temperature'] ?? '0.3';
$currentTok   = $rows['ai_max_tokens']  ?? '400';

$models = [
    ['id' => 'openai/gpt-oss-120b:free',            'label' => 'GPT OSS 120B (Free)',           'note' => 'OpenAI open-source 120B — fast & reliable'],
    ['id' => 'deepseek/deepseek-v3-0324:free',       'label' => 'DeepSeek V3 (Free)',             'note' => 'DeepSeek V3 — very capable, free tier'],
    ['id' => 'deepseek/deepseek-v4-flash:free',       'label' => 'DeepSeek V4 Flash (Free)',        'note' => 'DeepSeek V4 Flash — fast responses, free tier'],
    ['id' => 'deepseek/deepseek-r1-0528:free',       'label' => 'DeepSeek R1 (Free)',             'note' => 'DeepSeek R1 reasoning model'],
    ['id' => 'deepseek/deepseek-chat:free',          'label' => 'DeepSeek Chat (Free)',           'note' => 'DeepSeek Chat — general purpose'],
    ['id' => 'google/gemini-2.0-flash-exp:free',     'label' => 'Gemini 2.0 Flash (Free)',        'note' => 'Google Gemini 2.0 Flash — multimodal'],
    ['id' => 'google/gemini-2.5-flash-preview:free', 'label' => 'Gemini 2.5 Flash Preview (Free)','note' => 'Google Gemini 2.5 Flash — latest preview'],
    ['id' => 'meta-llama/llama-4-maverick:free',     'label' => 'Llama 4 Maverick (Free)',        'note' => 'Meta Llama 4 — open source'],
    ['id' => 'mistralai/mistral-7b-instruct:free',   'label' => 'Mistral 7B (Free)',              'note' => 'Mistral 7B instruct — lightweight'],
];

$isCustom = !in_array($currentModel, array_column($models, 'id'));

$page_title = t('adm_settings_title'); $active_nav = 'settings'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="row g-4">

  <!-- AI Model Config -->
  <div class="col-lg-7">
    <div class="cg-card">
      <div class="cg-card-header"><i class="bi bi-robot text-primary me-2"></i><?= t('adm_ai_model_title') ?></div>
      <div class="cg-card-body">
        <div id="settings-alert"></div>

        <div class="mb-4">
          <label class="form-label fw-semibold"><?= t('adm_ai_model_lbl') ?></label>
          <div class="row g-2">
            <?php foreach ($models as $m): ?>
            <div class="col-12">
              <label class="model-card <?= $currentModel === $m['id'] ? 'selected' : '' ?>" onclick="selectModel('<?= $m['id'] ?>')">
                <input type="radio" name="model" value="<?= $m['id'] ?>" <?= $currentModel === $m['id'] ? 'checked' : '' ?> style="display:none">
                <div class="d-flex align-items-start gap-2">
                  <i class="bi bi-cpu text-primary mt-1" style="flex-shrink:0"></i>
                  <div style="flex:1;min-width:0">
                    <div class="fw-semibold small"><?= $m['label'] ?></div>
                    <div class="text-muted" style="font-size:.72rem"><?= $m['note'] ?></div>
                    <code style="font-size:.68rem;color:#64748b"><?= $m['id'] ?></code>
                  </div>
                  <i class="bi bi-check-circle-fill text-primary check-icon" style="font-size:1rem;flex-shrink:0;display:<?= $currentModel === $m['id'] ? '' : 'none' ?>"></i>
                </div>
              </label>
            </div>
            <?php endforeach; ?>

            <!-- Custom model -->
            <div class="col-12">
              <label class="model-card <?= $isCustom ? 'selected' : '' ?>" onclick="selectModel('__custom__')">
                <input type="radio" name="model" value="__custom__" <?= $isCustom ? 'checked' : '' ?> style="display:none">
                <div class="d-flex align-items-start gap-2">
                  <i class="bi bi-pencil-square text-warning mt-1" style="flex-shrink:0"></i>
                  <div style="flex:1;min-width:0">
                    <div class="fw-semibold small"><?= t('adm_custom_model') ?></div>
                    <div class="text-muted" style="font-size:.72rem"><?= t('adm_custom_model_hint') ?></div>
                  </div>
                  <i class="bi bi-check-circle-fill text-primary check-icon" style="font-size:1rem;flex-shrink:0;display:<?= $isCustom ? '' : 'none' ?>"></i>
                </div>
              </label>
              <div id="custom-model-wrap" style="display:<?= $isCustom ? '' : 'none' ?>;margin-top:.5rem">
                <input type="text" id="custom-model-input" class="form-control form-control-sm"
                       placeholder="e.g. deepseek/deepseek-v4-flash"
                       value="<?= $isCustom ? htmlspecialchars($currentModel) : '' ?>">
              </div>
            </div>
          </div>
        </div>

        <div class="row g-3 mb-4">
          <div class="col-6">
            <label class="form-label fw-semibold small"><?= t('adm_ai_temp') ?> <span class="text-muted">(0.0–1.0)</span></label>
            <input type="number" id="ai-temp" class="form-control form-control-sm" min="0" max="1" step="0.1"
                   value="<?= htmlspecialchars($currentTemp) ?>">
            <div class="form-text"><?= t('adm_ai_temp_hint') ?></div>
          </div>
          <div class="col-6">
            <label class="form-label fw-semibold small"><?= t('adm_ai_tokens') ?></label>
            <input type="number" id="ai-tokens" class="form-control form-control-sm" min="100" max="2000" step="50"
                   value="<?= htmlspecialchars($currentTok) ?>">
            <div class="form-text"><?= t('adm_ai_tokens_hint') ?></div>
          </div>
        </div>

        <div class="d-flex gap-2">
          <button class="btn btn-outline-secondary btn-sm" onclick="testModel()" id="test-btn">
            <i class="bi bi-lightning me-1"></i><?= t('adm_ai_test') ?>
          </button>
          <button class="btn btn-primary btn-sm" onclick="saveSettings()" id="save-btn">
            <i class="bi bi-check2 me-1"></i><?= t('btn_save') ?>
          </button>
        </div>
        <div id="test-result" class="mt-2 small"></div>
      </div>
    </div>
  </div>

  <!-- Current Config Summary -->
  <div class="col-lg-5">
    <div class="cg-card">
      <div class="cg-card-header"><i class="bi bi-info-circle text-primary me-2"></i><?= t('adm_ai_current') ?></div>
      <div class="cg-card-body">
        <dl class="mb-0" style="font-size:.82rem">
          <dt class="text-muted small"><?= t('adm_ai_model_lbl') ?></dt>
          <dd class="mb-3"><code id="summary-model"><?= htmlspecialchars($currentModel) ?></code></dd>
          <dt class="text-muted small"><?= t('adm_ai_temp') ?></dt>
          <dd class="mb-3" id="summary-temp"><?= htmlspecialchars($currentTemp) ?></dd>
          <dt class="text-muted small"><?= t('adm_ai_tokens') ?></dt>
          <dd class="mb-0" id="summary-tokens"><?= htmlspecialchars($currentTok) ?></dd>
        </dl>
      </div>
    </div>

    <div class="cg-card mt-3">
      <div class="cg-card-header"><i class="bi bi-link-45deg text-primary me-2"></i><?= t('adm_openrouter_link') ?></div>
      <div class="cg-card-body small text-muted">
        <p class="mb-2"><?= t('adm_openrouter_hint') ?></p>
        <a href="https://openrouter.ai/models?q=free" target="_blank" class="btn btn-sm btn-outline-primary w-100">
          <i class="bi bi-box-arrow-up-right me-1"></i>openrouter.ai/models
        </a>
      </div>
    </div>
  </div>

</div>

<style>
.model-card {
  display: block;
  border: 1.5px solid var(--cg-border);
  border-radius: 10px;
  padding: .65rem .9rem;
  cursor: pointer;
  transition: border-color .15s, background .15s;
  background: #fff;
}
.model-card:hover { border-color: var(--cg-primary); background: #f0f9ff; }
.model-card.selected { border-color: var(--cg-primary); background: #e0f2fe; box-shadow: 0 0 0 3px rgba(14,165,233,.15); }
</style>

<?php
$t_saving          = t('btn_saving');
$t_save            = t('btn_save');
$t_testing         = t('adm_ai_testing');
$t_test            = t('adm_ai_test');
$currentModelJson  = json_encode($currentModel);
$extra_js = <<<JS
<script>
let selectedModel = {$currentModelJson};

function selectModel(id) {
  selectedModel = id;
  document.querySelectorAll('.model-card').forEach(card => {
    const isThis = card.querySelector('input').value === id;
    card.classList.toggle('selected', isThis);
    const icon = card.querySelector('.check-icon');
    if (icon) icon.style.display = isThis ? '' : 'none';
    if (isThis) card.querySelector('input').checked = true;
  });
  document.getElementById('custom-model-wrap').style.display = id === '__custom__' ? '' : 'none';
  updateSummary();
}

function getModel() {
  if (selectedModel === '__custom__') {
    return document.getElementById('custom-model-input').value.trim();
  }
  return selectedModel;
}

function updateSummary() {
  document.getElementById('summary-model').textContent  = getModel() || '—';
  document.getElementById('summary-temp').textContent   = document.getElementById('ai-temp').value;
  document.getElementById('summary-tokens').textContent = document.getElementById('ai-tokens').value;
}

document.getElementById('ai-temp').addEventListener('input', updateSummary);
document.getElementById('ai-tokens').addEventListener('input', updateSummary);
document.getElementById('custom-model-input').addEventListener('input', updateSummary);

async function saveSettings() {
  const model  = getModel();
  const temp   = document.getElementById('ai-temp').value;
  const tokens = document.getElementById('ai-tokens').value;
  if (!model) { showAlert('Model ID cannot be empty.', 'danger'); return; }

  const btn = document.getElementById('save-btn');
  btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>{$t_saving}';

  const calls = [
    fetch(BASE_URL+'/api/admin_settings.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'set',key:'ai_model',value:model})}),
    fetch(BASE_URL+'/api/admin_settings.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'set',key:'ai_temperature',value:temp})}),
    fetch(BASE_URL+'/api/admin_settings.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'set',key:'ai_max_tokens',value:tokens})}),
  ];
  const results = await Promise.all(calls);
  const jsons   = await Promise.all(results.map(r => r.json()));
  const allOk   = jsons.every(d => d.success);

  if (allOk) { showAlert('Settings saved!', 'success'); updateSummary(); }
  else showAlert('Error saving settings.', 'danger');

  btn.disabled = false; btn.innerHTML = '<i class="bi bi-check2 me-1"></i>{$t_save}';
}

async function testModel() {
  const model = getModel();
  if (!model) { showAlert('Enter a model ID first.', 'danger'); return; }
  const btn = document.getElementById('test-btn');
  const res  = document.getElementById('test-result');
  btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>{$t_testing}';
  res.innerHTML = '';

  const data = await fetch(BASE_URL+'/api/admin_settings.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'test',model})}).then(r=>r.json());

  if (data.success) res.innerHTML = '<span class="text-success"><i class="bi bi-check-circle me-1"></i>' + data.msg + '</span>';
  else res.innerHTML = '<span class="text-danger"><i class="bi bi-x-circle me-1"></i>' + (data.error||'Failed') + '</span>';

  btn.disabled = false; btn.innerHTML = '<i class="bi bi-lightning me-1"></i>{$t_test}';
}

function showAlert(msg, type) {
  const el = document.getElementById('settings-alert');
  el.innerHTML = '<div class="alert alert-'+type+' small py-2">'+msg+'</div>';
  setTimeout(() => { el.innerHTML = ''; }, 3000);
}
</script>
JS;
include __DIR__ . '/../includes/footer.php';
