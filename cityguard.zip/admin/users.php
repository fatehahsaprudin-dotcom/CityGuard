<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('admin');

$db = Database::getInstance()->getConnection();
$role_filter = $_GET['role'] ?? '';
$valid_roles = ['resident','officer','supervisor','admin','vendor'];
$sql = "SELECT * FROM users";
$params = [];
if ($role_filter && in_array($role_filter, $valid_roles)) {
    $sql .= " WHERE role=?"; $params[] = $role_filter;
}
$sql .= " ORDER BY role, name";
$stmt = $db->prepare($sql); $stmt->execute($params);
$users = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_id'])) {
    $tid = (int)$_POST['toggle_id'];
    $db->prepare("UPDATE users SET is_active = 1-is_active WHERE id=?")->execute([$tid]);
    header('Location: ' . $_SERVER['REQUEST_URI']); exit;
}

$page_title = t('adm_users_title'); $active_nav = 'users'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="d-flex gap-2 mb-3 flex-wrap">
  <a href="?" class="btn btn-sm <?= !$role_filter ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('lbl_all') ?></a>
  <?php foreach (['resident'=>'Resident','officer'=>'Officer','supervisor'=>'Supervisor','admin'=>'Admin','vendor'=>'Vendor'] as $r => $l): ?>
    <a href="?role=<?= $r ?>" class="btn btn-sm <?= $role_filter===$r ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= $l ?></a>
  <?php endforeach; ?>
</div>

<div class="cg-card">
  <div class="cg-card-header"><i class="bi bi-person-gear me-2 text-primary"></i><?= t('adm_users_title') ?> (<?= count($users) ?>)</div>
  <div class="table-responsive">
    <table class="cg-table">
      <thead><tr><th><?= t('th_name') ?></th><th><?= t('th_email') ?></th><th><?= t('th_role') ?></th><th class="hide-mobile"><?= t('th_dept') ?></th><th><?= t('th_status') ?></th><th><?= t('th_actions') ?></th></tr></thead>
      <tbody>
      <?php foreach ($users as $u):
        $role_badges = [
            'resident'   => ['Resident',   'bg-light text-dark border'],
            'officer'    => ['Officer',     'badge-status-assigned'],
            'supervisor' => ['Supervisor',  'badge-status-in_progress'],
            'admin'      => ['Admin',       'badge-status-resolved'],
            'vendor'     => ['Vendor',      'badge-status-approved'],
        ];
        $rb = $role_badges[$u['role']] ?? [$u['role'], 'bg-secondary'];
        $confirmMsg = $u['is_active'] ? t('adm_deactivate') : t('adm_activate');
      ?>
        <tr>
          <td class="fw-semibold small"><?= htmlspecialchars($u['name']) ?></td>
          <td class="text-muted small"><?= htmlspecialchars($u['email']) ?></td>
          <td><span class="badge <?= $rb[1] ?>"><?= $rb[0] ?></span></td>
          <td class="hide-mobile small text-muted"><?= htmlspecialchars($u['dept'] ?? '—') ?></td>
          <td>
            <?php if ($u['is_active']): ?>
              <span class="badge badge-status-approved"><?= t('lbl_active') ?></span>
            <?php else: ?>
              <span class="badge badge-status-rejected"><?= t('lbl_inactive') ?></span>
            <?php endif; ?>
          </td>
          <td>
            <form method="POST" style="display:inline">
              <input type="hidden" name="toggle_id" value="<?= $u['id'] ?>">
              <button type="submit" class="btn btn-sm <?= $u['is_active'] ? 'btn-outline-danger' : 'btn-outline-success' ?> btn-icon"
                      onclick="return confirm('<?= htmlspecialchars($confirmMsg) ?>')"
                      title="<?= htmlspecialchars($confirmMsg) ?>">
                <i class="bi <?= $u['is_active'] ? 'bi-person-x' : 'bi-person-check' ?>"></i>
              </button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php $layout = 'dash'; include __DIR__ . '/../includes/footer.php'; ?>
