<?php
require_once __DIR__ . '/config/constants.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/session.php';

if (isLoggedIn()) { header('Location: ' . getDashboardUrl()); exit; }

$error = $success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if (!$name || !$email || !$password) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $db   = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'This email is already registered.';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $ins  = $db->prepare("INSERT INTO users (name, email, password, role, phone) VALUES (?,?,?,'resident',?)");
            $ins->execute([$name, $email, $hash, $phone]);
            $success = 'Account created successfully! <a href="' . BASE_URL . '/login.php">Login now</a>.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= t('reg_title') ?> — <?= APP_NAME ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <style>
    body { background: linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 1rem; }
    .reg-card { background: #fff; border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,.15); width: 100%; max-width: 460px; overflow: hidden; }
    .reg-header { background: linear-gradient(135deg, #1e293b, #334155); padding: 1.5rem 2rem; display: flex; align-items: center; gap: 1rem; }
    .reg-body { padding: 2rem; }
    .reg-icon { width: 44px; height: 44px; background: #10b981; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; color: #fff; flex-shrink: 0; }
  </style>
</head>
<body>
<div style="position:fixed;top:1rem;right:1rem;z-index:100;display:flex;gap:4px">
  <a href="?setlang=en" class="btn btn-sm <?= langIs('en') ? 'btn-light' : 'btn-outline-light' ?>">EN</a>
  <a href="?setlang=bm" class="btn btn-sm <?= langIs('bm') ? 'btn-light' : 'btn-outline-light' ?>">BM</a>
</div>
<div class="reg-card">
  <div class="reg-header">
    <div class="reg-icon"><i class="bi bi-person-plus"></i></div>
    <div>
      <h6 class="text-white fw-bold mb-0"><?= APP_NAME ?></h6>
      <p class="text-white-50 small mb-0"><?= t('reg_title') ?></p>
    </div>
  </div>
  <div class="reg-body">
    <?php if ($error): ?>
      <div class="alert alert-danger small py-2"><i class="bi bi-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
      <div class="alert alert-success small py-2"><i class="bi bi-check-circle me-2"></i><?= $success ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="mb-3">
        <label class="form-label"><?= t('reg_name') ?></label>
        <input type="text" name="name" class="form-control" placeholder="Your full name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label"><?= t('reg_email') ?></label>
        <input type="email" name="email" class="form-control" placeholder="your@email.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label"><?= t('reg_phone') ?></label>
        <input type="tel" name="phone" class="form-control" placeholder="01x-xxxxxxx" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
      </div>
      <div class="row g-3 mb-4">
        <div class="col-6">
          <label class="form-label"><?= t('reg_password') ?></label>
          <input type="password" name="password" class="form-control" placeholder="Min 6 chars" required>
        </div>
        <div class="col-6">
          <label class="form-label"><?= t('reg_confirm') ?></label>
          <input type="password" name="confirm" class="form-control" placeholder="Repeat password" required>
        </div>
      </div>
      <button type="submit" class="btn btn-success w-100 py-2 fw-semibold">
        <i class="bi bi-person-check me-2"></i><?= t('reg_btn') ?>
      </button>
    </form>
    <p class="text-center small text-muted mt-3 mb-0">
      <?= t('reg_have_account') ?> <a href="<?= BASE_URL ?>/login.php" class="text-decoration-none fw-semibold"><?= t('reg_login') ?></a>
    </p>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
