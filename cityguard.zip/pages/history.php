<?php
// pages/history.php — Resolved history
require_once __DIR__ . '/../includes/header.php';
$officer = getCurrentOfficer();
$db      = Database::getInstance()->getConnection();

$stmt = $db->prepare("
    SELECT c.*, r.evidence_photo, r.ai_completion, r.officer_notes, r.resolved_at, r.approved_at,
           o2.name AS approved_by_name
    FROM case_resolutions r
    JOIN cases c ON c.id = r.case_id
    LEFT JOIN officers o2 ON o2.id = r.approved_by
    WHERE r.officer_id = ?
    ORDER BY r.resolved_at DESC
");
$stmt->execute([$officer['id']]);
$history = $stmt->fetchAll();
?>
<h4 class="mb-0 fw-semibold">History</h4>
<small class="text-muted">Rekod kes yang telah diselesaikan</small>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<div class="card border-0 shadow-sm">
  <div class="card-header bg-body d-flex justify-content-between align-items-center">
    <span class="small fw-semibold">Resolved cases</span>
    <span class="badge bg-success-subtle text-success"><?= count($history) ?> total</span>
  </div>
  <div class="card-body p-0">
    <?php if (empty($history)): ?>
      <div class="text-center text-muted py-5 small">Tiada rekod lagi.</div>
    <?php else: ?>
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
          <tr>
            <th class="small text-muted fw-semibold ps-3">Case ID</th>
            <th class="small text-muted fw-semibold">Title</th>
            <th class="small text-muted fw-semibold">Category</th>
            <th class="small text-muted fw-semibold">Resolved at</th>
            <th class="small text-muted fw-semibold">Approved by</th>
            <th class="small text-muted fw-semibold">Status</th>
            <th class="small text-muted fw-semibold">Report</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($history as $h): ?>
          <tr>
            <td class="ps-3"><code class="small"><?= htmlspecialchars($h['case_code']) ?></code></td>
            <td class="small fw-semibold"><?= htmlspecialchars($h['title']) ?></td>
            <td class="small text-muted"><?= htmlspecialchars($h['category']) ?></td>
            <td class="small text-muted"><?= date('d M Y, H:i', strtotime($h['resolved_at'])) ?></td>
            <td class="small text-muted"><?= htmlspecialchars(isset($h['approved_by_name']) ? $h['approved_by_name'] : '—') ?></td>
            <td>
              <?php if ($h['approved_at']): ?>
                <span class="badge bg-success-subtle text-success border border-success-subtle">Approved</span>
              <?php else: ?>
                <span class="badge bg-warning-subtle text-warning border border-warning-subtle">Pending review</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($h['ai_completion']): ?>
              <button class="btn btn-sm btn-outline-secondary py-0 px-2"
                      data-bs-toggle="modal" data-bs-target="#reportModal"
                      data-report="<?= htmlspecialchars($h['ai_completion']) ?>"
                      data-case="<?= htmlspecialchars($h['case_code']) ?>">
                <i class="bi bi-file-text me-1"></i>View
              </button>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- AI Report Modal -->
<div class="modal fade" id="reportModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <div class="modal-header border-0">
        <h6 class="modal-title fw-semibold"><i class="bi bi-robot text-success me-2"></i>AI Completion Report — <span id="modal-case"></span></h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="border-start border-success border-3 ps-3 small text-muted" id="modal-report" style="line-height:1.7;white-space:pre-wrap"></div>
      </div>
    </div>
  </div>
</div>
<script>
document.getElementById('reportModal').addEventListener('show.bs.modal', e => {
  document.getElementById('modal-report').textContent = e.relatedTarget.dataset.report;
  document.getElementById('modal-case').textContent   = e.relatedTarget.dataset.case;
});
</script>

<?php require_once __DIR__ . '/../includes/footer_close.php'; ?>
