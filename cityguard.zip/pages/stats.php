<?php
// pages/stats.php — My Stats
require_once __DIR__ . '/../includes/header.php';
$officer = getCurrentOfficer();
$db      = Database::getInstance()->getConnection();

$stmt = $db->prepare("SELECT COUNT(*) FROM cases WHERE assigned_to = ?");
$stmt->execute([$officer['id']]); $total = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM cases WHERE assigned_to = ? AND status = ?");
$stmt->execute([$officer['id'], STATUS_RESOLVED]); $resolved = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM cases WHERE assigned_to = ? AND YEARWEEK(reported_at,1) = YEARWEEK(NOW(),1)");
$stmt->execute([$officer['id']]); $thisWeek = $stmt->fetchColumn();

$stmt = $db->prepare("SELECT AVG(TIMESTAMPDIFF(MINUTE, c.assigned_at, r.resolved_at)) FROM case_resolutions r JOIN cases c ON c.id = r.case_id WHERE r.officer_id = ?");
$stmt->execute([$officer['id']]); $avgMins = round($stmt->fetchColumn() ?: 0);

$rate = $total ? round($resolved / $total * 100) : 0;
$pending = $total - $resolved;
?>
<h4 class="mb-0 fw-semibold">My Stats</h4>
<small class="text-muted">Prestasi peribadi anda</small>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<div class="row g-3 mb-4">
  <?php foreach ([
    ['Total cases', $total,    'bi-clipboard', 'primary'],
    ['Resolved',    $resolved, 'bi-check-circle','success'],
    ['Pending',     $pending,  'bi-hourglass',  'warning'],
    ['Avg response',$avgMins ? $avgMins.'m' : '—', 'bi-stopwatch','info'],
  ] as [$label, $val, $icon, $color]): ?>
  <div class="col-6 col-md-3">
    <div class="card border-0 shadow-sm h-100">
      <div class="card-body">
        <div class="d-flex align-items-center gap-2 mb-2">
          <span class="badge bg-<?= $color ?>-subtle text-<?= $color ?> p-2">
            <i class="bi <?= $icon ?> fs-5"></i>
          </span>
        </div>
        <div class="fs-2 fw-semibold text-<?= $color ?>"><?= $val ?></div>
        <div class="small text-muted"><?= $label ?></div>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-md-6">
    <div class="card border-0 shadow-sm h-100">
      <div class="card-header bg-body small fw-semibold">Overall progress</div>
      <div class="card-body">
        <div class="d-flex justify-content-between small text-muted mb-1">
          <span><?= $resolved ?> of <?= $total ?> resolved</span><span><?= $rate ?>%</span>
        </div>
        <div class="progress mb-3" style="height:8px">
          <div class="progress-bar bg-success" style="width:<?= $rate ?>%"></div>
        </div>
        <dl class="row small mb-0">
          <dt class="col-6 fw-normal text-muted">This week</dt><dd class="col-6"><?= $thisWeek ?> cases</dd>
          <dt class="col-6 fw-normal text-muted">Target response</dt><dd class="col-6">60 minutes</dd>
          <dt class="col-6 fw-normal text-muted">Avg response</dt><dd class="col-6"><?= $avgMins ? $avgMins.' min' : '—' ?></dd>
        </dl>
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card border-0 shadow-sm h-100">
      <div class="card-header bg-body small fw-semibold">Cases by priority</div>
      <div class="card-body p-0">
        <?php
        $priorities = ['high'=>['High','danger'], 'medium'=>['Medium','warning'], 'low'=>['Low','success']];
        foreach ($priorities as $p => [$label, $color]):
          $stmt = $db->prepare("SELECT COUNT(*) FROM cases WHERE assigned_to = ? AND priority = ?");
          $stmt->execute([$officer['id'], $p]); $cnt = $stmt->fetchColumn();
        ?>
        <div class="d-flex align-items-center justify-content-between px-3 py-2 border-bottom">
          <span class="badge bg-<?= $color ?>-subtle text-<?= $color ?> border border-<?= $color ?>-subtle"><?= $label ?></span>
          <span class="fw-semibold small"><?= $cnt ?> cases</span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer_close.php'; ?>
