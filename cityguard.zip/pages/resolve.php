<?php
// pages/resolve.php — Resolve Case with AI report
require_once __DIR__ . '/../includes/header.php';

$officer = getCurrentOfficer();
$db      = Database::getInstance()->getConnection();
$caseId  = intval(isset($_GET['case_id']) ? $_GET['case_id'] : 0);

// Fetch the case
$case = null;
if ($caseId) {
    $stmt = $db->prepare("SELECT * FROM cases WHERE id = ? AND assigned_to = ?");
    $stmt->execute([$caseId, $officer['id']]);
    $case = $stmt->fetch();
}

// Fetch all active cases for dropdown
$stmt = $db->prepare("SELECT id, case_code, title FROM cases WHERE assigned_to = ? AND status != ? ORDER BY FIELD(priority,'high','medium','low')");
$stmt->execute([$officer['id'], STATUS_RESOLVED]);
$activeCases = $stmt->fetchAll();
?>
<h4 class="mb-0 fw-semibold">Resolve Case</h4>
<small class="text-muted">Upload gambar bukti dan jana laporan AI</small>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<div class="row g-3">

  <!-- Left: Case selection + details -->
  <div class="col-lg-5">
    <div class="card border-0 shadow-sm mb-3">
      <div class="card-header bg-body small fw-semibold">Select case</div>
      <div class="card-body">
        <select class="form-select form-select-sm" id="case-select"
                onchange="location.href='<?= BASE_URL ?>/pages/resolve.php?case_id='+this.value">
          <option value="">— Pilih kes —</option>
          <?php foreach ($activeCases as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $caseId == $c['id'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($c['case_code']) ?> — <?= htmlspecialchars($c['title']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <?php if ($case): ?>
    <div class="card border-0 shadow-sm">
      <div class="card-header bg-body small fw-semibold d-flex justify-content-between">
        Case details
        <a href="https://www.google.com/maps?q=<?= $case['latitude'] ?>,<?= $case['longitude'] ?>"
           target="_blank" class="btn btn-sm btn-outline-secondary py-0 px-2">
          <i class="bi bi-map me-1"></i>Navigate
        </a>
      </div>
      <div class="card-body">
        <?php
          $pc = isset($PRIORITY_COLORS[$case['priority']]) ? $PRIORITY_COLORS[$case['priority']] : 'secondary';
          $sc = isset($STATUS_COLORS[$case['status']])     ? $STATUS_COLORS[$case['status']]     : 'secondary';
        ?>
        <div class="d-flex gap-2 mb-3 flex-wrap">
          <span class="badge bg-<?= $pc ?>-subtle text-<?= $pc ?> border border-<?= $pc ?>-subtle"><?= ucfirst($case['priority']) ?> priority</span>
          <span class="badge bg-<?= $sc ?>-subtle text-<?= $sc ?> border border-<?= $sc ?>-subtle"><?= ucfirst(str_replace('_',' ',$case['status'])) ?></span>
          <code class="small text-muted"><?= htmlspecialchars($case['case_code']) ?></code>
        </div>
        <h6 class="fw-semibold"><?= htmlspecialchars($case['title']) ?></h6>
        <dl class="row small mb-0">
          <dt class="col-5 text-muted fw-normal">Category</dt>
          <dd class="col-7"><?= htmlspecialchars($case['category']) ?></dd>
          <dt class="col-5 text-muted fw-normal">Location</dt>
          <dd class="col-7"><?= htmlspecialchars(isset($case['address'])      ? $case['address']      : '—') ?></dd>
          <dt class="col-5 text-muted fw-normal">Department</dt>
          <dd class="col-7"><?= htmlspecialchars(isset($case['assigned_dept']) ? $case['assigned_dept'] : '—') ?></dd>
          <dt class="col-5 text-muted fw-normal">Reported</dt>
          <dd class="col-7"><?= date('d M Y, H:i', strtotime($case['reported_at'])) ?></dd>
        </dl>
        <?php if ($case['description']): ?>
          <div class="mt-3 p-2 bg-body-secondary rounded small text-muted">
            <?= nl2br(htmlspecialchars($case['description'])) ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Right: Photo upload + AI report -->
  <div class="col-lg-7">
    <?php if (!$case): ?>
      <div class="card border-0 shadow-sm">
        <div class="card-body text-center py-5 text-muted">
          <i class="bi bi-arrow-left-circle fs-2 d-block mb-2"></i>
          Sila pilih kes dari senarai kiri.
        </div>
      </div>
    <?php elseif ($case['status'] === STATUS_RESOLVED): ?>
      <div class="alert alert-success d-flex gap-2">
        <i class="bi bi-check-circle-fill fs-5"></i>
        <div>Kes ini telah diselesaikan. Lihat butiran di <a href="<?= BASE_URL ?>/pages/history.php">History</a>.</div>
      </div>
    <?php else: ?>
      <!-- Upload form -->
      <div class="card border-0 shadow-sm mb-3">
        <div class="card-header bg-body small fw-semibold">
          <i class="bi bi-camera me-1"></i>Upload evidence photo
        </div>
        <div class="card-body">
          <div class="border border-2 border-dashed rounded-3 text-center py-4 px-3 mb-3" id="drop-zone"
               style="cursor:pointer;border-color:var(--bs-border-color)!important"
               onclick="document.getElementById('photo-input').click()">
            <i class="bi bi-camera-fill fs-2 text-muted d-block mb-2"></i>
            <div class="small text-muted">Tap untuk ambil gambar atau pilih dari galeri</div>
            <div class="small text-muted">PNG, JPG, WEBP — max 5MB</div>
          </div>
          <input type="file" id="photo-input" accept="image/*" capture="environment"
                 class="d-none" onchange="previewPhoto(this)">
          <div id="photo-preview-wrap" class="d-none mb-3">
            <img id="photo-preview" class="img-fluid rounded-3 w-100" style="max-height:200px;object-fit:cover" alt="Evidence preview">
            <button class="btn btn-sm btn-outline-danger mt-2" onclick="clearPhoto()">
              <i class="bi bi-trash me-1"></i>Remove photo
            </button>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-semibold">Nota tambahan (optional)</label>
            <textarea class="form-control form-control-sm" id="officer-notes" rows="2"
                      placeholder="Catatan pegawai..."></textarea>
          </div>
          <button class="btn btn-success w-100 fw-semibold" id="ai-btn"
                  onclick="generateAIReport()" disabled>
            <i class="bi bi-robot me-2"></i>Generate AI completion report
          </button>
        </div>
      </div>

      <!-- AI report output -->
      <div class="card border-0 shadow-sm d-none" id="ai-report-card">
        <div class="card-header bg-body small fw-semibold d-flex align-items-center gap-2">
          <i class="bi bi-robot text-success"></i>AI completion report
          <span class="badge bg-success-subtle text-success ms-auto">Generated</span>
        </div>
        <div class="card-body">
          <div class="border-start border-success border-3 ps-3 text-muted small" id="ai-report-text"
               style="line-height:1.7;white-space:pre-wrap"></div>
          <div class="d-flex gap-2 mt-3">
            <button class="btn btn-success fw-semibold" onclick="submitResolution()">
              <i class="bi bi-check-lg me-2"></i>Submit & mark resolved
            </button>
            <button class="btn btn-outline-secondary" onclick="clearPhoto()">
              <i class="bi bi-arrow-counterclockwise me-1"></i>Retake
            </button>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
let photoBase64 = null;

function previewPhoto(input) {
  const file = input.files[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) { alert('Gambar terlalu besar. Max 5MB.'); return; }
  const reader = new FileReader();
  reader.onload = e => {
    photoBase64 = e.target.result;
    document.getElementById('photo-preview').src = photoBase64;
    document.getElementById('photo-preview-wrap').classList.remove('d-none');
    document.getElementById('drop-zone').classList.add('d-none');
    document.getElementById('ai-btn').disabled = false;
  };
  reader.readAsDataURL(file);
}

function clearPhoto() {
  photoBase64 = null;
  document.getElementById('photo-input').value = '';
  document.getElementById('photo-preview-wrap').classList.add('d-none');
  document.getElementById('drop-zone').classList.remove('d-none');
  document.getElementById('ai-btn').disabled = true;
  document.getElementById('ai-report-card').classList.add('d-none');
}

function generateAIReport() {
  const btn = document.getElementById('ai-btn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Analysing photo...';

  fetch('<?= BASE_URL ?>/api/generate_report.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      case_id:       <?= isset($case['id']) ? $case['id'] : 0 ?>,
      photo_base64:  photoBase64,
      officer_notes: document.getElementById('officer-notes').value
    })
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      document.getElementById('ai-report-text').textContent = data.report;
      document.getElementById('ai-report-card').classList.remove('d-none');
      btn.innerHTML = '<i class="bi bi-robot me-2"></i>Regenerate report';
      btn.disabled = false;
    } else {
      alert(data.error || 'AI report gagal dijana.');
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-robot me-2"></i>Generate AI completion report';
    }
  })
  .catch(() => { alert('Ralat sambungan.'); btn.disabled = false; });
}

function submitResolution() {
  if (!confirm('Sahkan kes ini sebagai selesai?')) return;
  const reportText = document.getElementById('ai-report-text').textContent;
  const notes      = document.getElementById('officer-notes').value;

  fetch('<?= BASE_URL ?>/api/resolve_case.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      case_id:      <?= isset($case['id']) ? $case['id'] : 0 ?>,
      photo_base64: photoBase64,
      ai_report:    reportText,
      notes:        notes
    })
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      window.location.href = '<?= BASE_URL ?>/pages/cases.php';
    } else {
      alert(data.error || 'Gagal menyimpan penyelesaian.');
    }
  })
  .catch(() => alert('Ralat sambungan.'));
}
</script>

<?php require_once __DIR__ . '/../includes/footer_close.php'; ?>
