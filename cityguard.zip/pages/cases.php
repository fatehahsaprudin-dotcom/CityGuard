<?php
// pages/cases.php — My Cases (Dashboard 3)
require_once __DIR__ . '/../includes/header.php';

$officer = getCurrentOfficer();
$db      = Database::getInstance()->getConnection();

// Fetch cases assigned to this officer
$stmt = $db->prepare("
    SELECT c.*, r.id AS resolution_id
    FROM cases c
    LEFT JOIN case_resolutions r ON r.case_id = c.id
    WHERE c.assigned_to = ?
    ORDER BY FIELD(c.priority,'high','medium','low'), c.reported_at DESC
");
$stmt->execute([$officer['id']]);
$cases = $stmt->fetchAll();

$total    = count($cases);
$resolved = count(array_filter($cases, function($c) { return $c['status'] === STATUS_RESOLVED; }));
$pending  = $total - $resolved;
?>
<h4 class="mb-0 fw-semibold">My Cases</h4>
<small class="text-muted">Semua kes yang di-assign kepada anda</small>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<!-- Summary cards -->
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3">
    <div class="card border-0 bg-body-secondary h-100">
      <div class="card-body">
        <div class="fs-3 fw-semibold"><?= $total ?></div>
        <div class="text-muted small">Total assigned</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card border-0 bg-body-secondary h-100">
      <div class="card-body">
        <div class="fs-3 fw-semibold text-success"><?= $resolved ?></div>
        <div class="text-muted small">Resolved</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card border-0 bg-body-secondary h-100">
      <div class="card-body">
        <div class="fs-3 fw-semibold text-warning"><?= $pending ?></div>
        <div class="text-muted small">Pending</div>
      </div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card border-0 bg-body-secondary h-100">
      <div class="card-body">
        <div class="fs-3 fw-semibold"><?= $total ? round($resolved / $total * 100) : 0 ?>%</div>
        <div class="text-muted small">Completion</div>
      </div>
    </div>
  </div>
</div>

<!-- Cases table -->
<div class="card border-0 shadow-sm">
  <div class="card-header bg-body d-flex align-items-center justify-content-between">
    <span class="fw-semibold small">Cases list</span>
    <div class="d-flex gap-2">
      <select class="form-select form-select-sm" id="filterStatus" onchange="filterTable()">
        <option value="">All status</option>
        <option value="assigned">Assigned</option>
        <option value="in_progress">In progress</option>
        <option value="resolved">Resolved</option>
      </select>
      <select class="form-select form-select-sm" id="filterPriority" onchange="filterTable()">
        <option value="">All priority</option>
        <option value="high">High</option>
        <option value="medium">Medium</option>
        <option value="low">Low</option>
      </select>
    </div>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0" id="casesTable">
        <thead class="table-light">
          <tr>
            <th class="small text-muted fw-semibold ps-3">Case ID</th>
            <th class="small text-muted fw-semibold">Title</th>
            <th class="small text-muted fw-semibold">Category</th>
            <th class="small text-muted fw-semibold">Location</th>
            <th class="small text-muted fw-semibold">Priority</th>
            <th class="small text-muted fw-semibold">Status</th>
            <th class="small text-muted fw-semibold">Reported</th>
            <th class="small text-muted fw-semibold">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($cases)): ?>
            <tr><td colspan="8" class="text-center text-muted py-5">Tiada kes ditemui.</td></tr>
          <?php else: ?>
            <?php foreach ($cases as $case): ?>
            <?php
              $sc = isset($STATUS_COLORS[$case['status']])     ? $STATUS_COLORS[$case['status']]     : 'secondary';
              $pc = isset($PRIORITY_COLORS[$case['priority']]) ? $PRIORITY_COLORS[$case['priority']] : 'secondary';
              $statusLabel = ucfirst(str_replace('_', ' ', $case['status']));
            ?>
            <tr data-status="<?= $case['status'] ?>" data-priority="<?= $case['priority'] ?>">
              <td class="ps-3"><code class="small"><?= htmlspecialchars($case['case_code']) ?></code></td>
              <td class="fw-semibold small"><?= htmlspecialchars($case['title']) ?></td>
              <td class="small text-muted"><?= htmlspecialchars($case['category']) ?></td>
              <td class="small text-muted"><?= htmlspecialchars(isset($case['address']) ? $case['address'] : '-') ?></td>
              <td>
                <span class="badge bg-<?= $pc ?>-subtle text-<?= $pc ?> border border-<?= $pc ?>-subtle">
                  <?= ucfirst($case['priority']) ?>
                </span>
              </td>
              <td>
                <span class="badge bg-<?= $sc ?>-subtle text-<?= $sc ?> border border-<?= $sc ?>-subtle">
                  <?= $statusLabel ?>
                </span>
              </td>
              <td class="small text-muted"><?= date('d M, H:i', strtotime($case['reported_at'])) ?></td>
              <td>
                <div class="d-flex gap-1">
                  <a href="<?= BASE_URL ?>/pages/resolve.php?case_id=<?= $case['id'] ?>"
                     class="btn btn-sm btn-outline-success <?= $case['status'] === STATUS_RESOLVED ? 'disabled' : '' ?>">
                    <i class="bi bi-camera me-1"></i>Resolve
                  </a>
                  <a href="https://www.google.com/maps?q=<?= $case['latitude'] ?>,<?= $case['longitude'] ?>"
                     target="_blank" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-map"></i>
                  </a>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
function filterTable() {
  const status   = document.getElementById('filterStatus').value;
  const priority = document.getElementById('filterPriority').value;
  document.querySelectorAll('#casesTable tbody tr').forEach(row => {
    const matchStatus   = !status   || row.dataset.status   === status;
    const matchPriority = !priority || row.dataset.priority === priority;
    row.style.display = (matchStatus && matchPriority) ? '' : 'none';
  });
}
// Update sidebar badge
document.addEventListener('DOMContentLoaded', () => {
  const el = document.getElementById('pending-count');
  if (el) el.textContent = '<?= $pending ?>';
});
</script>

<?php require_once __DIR__ . '/../includes/footer_close.php'; ?>
