<?php
// pages/checkin.php — GPS Check-in
require_once __DIR__ . '/../includes/header.php';

$officer = getCurrentOfficer();
$db      = Database::getInstance()->getConnection();

// Active (non-resolved) cases for this officer
$stmt = $db->prepare("
    SELECT id, case_code, title, address
    FROM cases
    WHERE assigned_to = ? AND status != ?
    ORDER BY FIELD(priority,'high','medium','low')
");
$stmt->execute([$officer['id'], STATUS_RESOLVED]);
$activeCases = $stmt->fetchAll();

// Today's check-ins
$stmt = $db->prepare("
    SELECT ci.*, c.case_code, c.title
    FROM officer_checkins ci
    LEFT JOIN cases c ON c.id = ci.case_id
    WHERE ci.officer_id = ? AND DATE(ci.checkin_at) = CURDATE()
    ORDER BY ci.checkin_at DESC
");
$stmt->execute([$officer['id']]);
$todayCheckins = $stmt->fetchAll();
?>
<h4 class="mb-0 fw-semibold">GPS Check-in</h4>
<small class="text-muted">Verify lokasi anda sebelum menyelesaikan kes</small>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<div class="row g-3">

  <!-- Map + check-in form -->
  <div class="col-lg-7">
    <div class="card border-0 shadow-sm h-100">
      <div class="card-body">

        <!-- Map placeholder -->
        <div class="bg-body-secondary rounded-3 d-flex align-items-center justify-content-center mb-3"
             style="height:200px" id="map-placeholder">
          <div class="text-center text-muted">
            <i class="bi bi-map fs-1"></i>
            <p class="small mt-2 mb-0">Menunggu lokasi GPS...</p>
          </div>
        </div>

        <!-- GPS info -->
        <div class="row g-2 mb-3">
          <div class="col-6">
            <div class="bg-body-secondary rounded p-2">
              <div class="small text-muted">Latitude</div>
              <div class="fw-semibold small font-monospace" id="gps-lat">—</div>
            </div>
          </div>
          <div class="col-6">
            <div class="bg-body-secondary rounded p-2">
              <div class="small text-muted">Longitude</div>
              <div class="fw-semibold small font-monospace" id="gps-lon">—</div>
            </div>
          </div>
          <div class="col-6">
            <div class="bg-body-secondary rounded p-2">
              <div class="small text-muted">Accuracy</div>
              <div class="fw-semibold small" id="gps-acc">Detecting...</div>
            </div>
          </div>
          <div class="col-6">
            <div class="bg-body-secondary rounded p-2">
              <div class="small text-muted">Time</div>
              <div class="fw-semibold small" id="gps-time">—</div>
            </div>
          </div>
        </div>

        <!-- Select case -->
        <div class="mb-3">
          <label class="form-label small fw-semibold">Select case to check-in</label>
          <select class="form-select form-select-sm" id="checkin-case">
            <option value="">— General check-in (no case) —</option>
            <?php foreach ($activeCases as $c): ?>
              <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['case_code']) ?> — <?= htmlspecialchars($c['title']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <button class="btn btn-success w-100 fw-semibold" id="checkin-btn" onclick="doCheckin()">
          <i class="bi bi-geo-alt-fill me-2"></i>Check in at this location
        </button>

        <div id="checkin-success" class="alert alert-success d-flex align-items-center gap-2 mt-3 d-none">
          <i class="bi bi-check-circle-fill"></i>
          <span>Check-in berjaya direkodkan!</span>
        </div>
      </div>
    </div>
  </div>

  <!-- Today's log -->
  <div class="col-lg-5">
    <div class="card border-0 shadow-sm h-100">
      <div class="card-header bg-body fw-semibold small">
        <i class="bi bi-clock-history me-1"></i>Today's check-ins
        <span class="badge bg-success-subtle text-success ms-1"><?= count($todayCheckins) ?></span>
      </div>
      <div class="card-body p-0">
        <?php if (empty($todayCheckins)): ?>
          <div class="text-center text-muted py-5 small">Belum ada check-in hari ini.</div>
        <?php else: ?>
          <ul class="list-group list-group-flush">
            <?php foreach ($todayCheckins as $ci): ?>
            <li class="list-group-item px-3 py-2">
              <div class="d-flex justify-content-between align-items-start">
                <div>
                  <div class="fw-semibold small"><?= $ci['case_code'] ? htmlspecialchars($ci['case_code']) : 'General' ?></div>
                  <div class="text-muted" style="font-size:11px"><?= htmlspecialchars(isset($ci['title']) ? $ci['title'] : '—') ?></div>
                  <div class="text-muted font-monospace" style="font-size:10px">
                    <?= number_format($ci['latitude'], 6) ?>, <?= number_format($ci['longitude'], 6) ?>
                  </div>
                </div>
                <div class="text-end">
                  <div class="small text-muted"><?= date('H:i', strtotime($ci['checkin_at'])) ?></div>
                  <?php if ($ci['accuracy']): ?>
                    <div style="font-size:10px" class="text-muted">±<?= round($ci['accuracy']) ?>m</div>
                  <?php endif; ?>
                </div>
              </div>
            </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<script>
let gpsLat = null, gpsLon = null, gpsAcc = null;

// Get GPS on load
if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(pos => {
    gpsLat = pos.coords.latitude;
    gpsLon = pos.coords.longitude;
    gpsAcc = pos.coords.accuracy;
    const now = new Date();
    document.getElementById('gps-lat').textContent  = gpsLat.toFixed(6);
    document.getElementById('gps-lon').textContent  = gpsLon.toFixed(6);
    document.getElementById('gps-acc').textContent  = '±' + Math.round(gpsAcc) + ' metres';
    document.getElementById('gps-time').textContent = now.toLocaleTimeString('en-MY', {hour:'2-digit', minute:'2-digit'});
    document.getElementById('map-placeholder').innerHTML =
      `<div class="text-center"><i class="bi bi-geo-alt-fill text-success fs-1"></i><p class="small mt-2 mb-0 text-success fw-semibold">GPS Detected</p><p class="text-muted" style="font-size:11px">${gpsLat.toFixed(4)}, ${gpsLon.toFixed(4)}</p></div>`;
  }, () => {
    document.getElementById('gps-acc').textContent = 'GPS unavailable';
  });
}

function doCheckin() {
  if (!gpsLat) { alert('GPS belum bersedia. Sila tunggu sebentar.'); return; }
  const btn    = document.getElementById('checkin-btn');
  const caseId = document.getElementById('checkin-case').value;
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Recording...';

  fetch('<?= BASE_URL ?>/api/checkin.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ lat: gpsLat, lon: gpsLon, accuracy: gpsAcc, case_id: caseId || null })
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      document.getElementById('checkin-success').classList.remove('d-none');
      btn.innerHTML = '<i class="bi bi-check-lg me-2"></i>Checked in!';
    } else {
      alert(data.error || 'Check-in gagal.');
      btn.disabled = false;
      btn.innerHTML = '<i class="bi bi-geo-alt-fill me-2"></i>Check in at this location';
    }
  })
  .catch(() => { alert('Ralat sambungan.'); btn.disabled = false; });
}
</script>

<?php require_once __DIR__ . '/../includes/footer_close.php'; ?>
