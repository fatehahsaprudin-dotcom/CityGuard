<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$data   = json_decode(file_get_contents('php://input'), true);
$caseId = (int)($data['case_id'] ?? 0);
$action = $data['action'] ?? 'approve';

if (!$caseId) { echo json_encode(['success'=>false,'error'=>'ID kes diperlukan.']); exit; }

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();

$chk = $db->prepare("SELECT r.id FROM case_resolutions r WHERE r.case_id=? AND r.approved_by IS NULL");
$chk->execute([$caseId]);
if (!$chk->fetch()) { echo json_encode(['success'=>false,'error'=>'Resolusi tidak dijumpai atau sudah diproses.']); exit; }

if ($action === 'approve') {
    $db->prepare("UPDATE case_resolutions SET approved_by=?, approved_at=NOW() WHERE case_id=?")->execute([$user['id'], $caseId]);
    $db->prepare("UPDATE cases SET status='approved', updated_at=NOW() WHERE id=?")->execute([$caseId]);
    $db->prepare("INSERT INTO case_activity_log (case_id, user_id, action, old_value, new_value) VALUES (?,?,'Resolusi diluluskan','resolved','approved')")->execute([$caseId, $user['id']]);
} else {
    $db->prepare("DELETE FROM case_resolutions WHERE case_id=?")->execute([$caseId]);
    $db->prepare("UPDATE cases SET status='in_progress', updated_at=NOW() WHERE id=?")->execute([$caseId]);
    $db->prepare("INSERT INTO case_activity_log (case_id, user_id, action, old_value, new_value) VALUES (?,?,'Resolusi ditolak','resolved','in_progress')")->execute([$caseId, $user['id']]);
}

echo json_encode(['success' => true]);
