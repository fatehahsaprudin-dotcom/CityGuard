<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('vendor');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$caseId = (int)($_POST['case_id'] ?? 0);
$status = $_POST['status'] ?? 'in_progress';
$notes  = trim($_POST['notes']  ?? '');
$reason = trim($_POST['reason'] ?? '');

if (!$caseId) { echo json_encode(['success'=>false,'error'=>'Invalid case.']); exit; }
if (!in_array($status, ['in_progress','work_done','cannot_complete'])) $status = 'in_progress';

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();

$chk = $db->prepare("SELECT id, status FROM cases WHERE id=? AND vendor_id=?");
$chk->execute([$caseId, $user['id']]);
$case = $chk->fetch();
if (!$case) { echo json_encode(['success'=>false,'error'=>'Case not found or not assigned to you.']); exit; }

// Validate required fields
if ($status === 'work_done' && empty($_FILES['evidence_photo']['tmp_name'])) {
    echo json_encode(['success'=>false,'error'=>'Evidence photo is required when marking work as completed.']); exit;
}
if ($status === 'cannot_complete' && !$reason) {
    echo json_encode(['success'=>false,'error'=>'Please provide a reason for not completing the work.']); exit;
}

// Handle evidence photo upload
$photoFilename = null;
if (!empty($_FILES['evidence_photo']['tmp_name'])) {
    $file = $_FILES['evidence_photo'];
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        echo json_encode(['success'=>false,'error'=>'Photo too large (max 5MB).']); exit;
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','webp'])) {
        echo json_encode(['success'=>false,'error'=>'Unsupported image format.']); exit;
    }
    if (!is_dir(UPLOAD_VENDOR_EVIDENCE)) mkdir(UPLOAD_VENDOR_EVIDENCE, 0755, true);
    $photoFilename = 'vnd_' . $caseId . '_' . time() . '.' . $ext;
    move_uploaded_file($file['tmp_name'], UPLOAD_VENDOR_EVIDENCE . $photoFilename);
}

// Update case status to in_progress if it was just assigned
if ($case['status'] === 'assigned') {
    $db->prepare("UPDATE cases SET status='in_progress', updated_at=NOW() WHERE id=?")->execute([$caseId]);
}

// Save vendor submission record
$db->prepare("INSERT INTO vendor_submissions (case_id, vendor_id, status, evidence_photo, notes) VALUES (?,?,?,?,?)")
   ->execute([$caseId, $user['id'], $status, $photoFilename, $notes ?: $reason]);

// Update case status and log
if ($status === 'work_done') {
    $db->prepare("UPDATE cases SET status='resolved', updated_at=NOW() WHERE id=?")->execute([$caseId]);
    $action = 'Vendor: Work completed — ' . ($notes ?: 'No notes');
    $db->prepare("INSERT INTO case_activity_log (case_id, user_id, action, old_value, new_value) VALUES (?,?,?,?,?)")
       ->execute([$caseId, $user['id'], $action, 'in_progress', 'resolved']);
} elseif ($status === 'cannot_complete') {
    $action = 'Vendor: Cannot complete — ' . $reason;
    $db->prepare("INSERT INTO case_activity_log (case_id, user_id, action) VALUES (?,?,?)")
       ->execute([$caseId, $user['id'], $action]);
} else {
    $action = 'Vendor update: ' . ($notes ?: 'In progress');
    $db->prepare("INSERT INTO case_activity_log (case_id, user_id, action) VALUES (?,?,?)")
       ->execute([$caseId, $user['id'], $action]);
}

echo json_encode(['success' => true]);
