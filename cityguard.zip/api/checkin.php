<?php
// api/checkin.php — Record GPS check-in
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); exit(json_encode(['success'=>false,'error'=>'Method not allowed']));
}

$data = json_decode(file_get_contents('php://input'), true);
$lat  = floatval(isset($data['lat'])      ? $data['lat']      : 0);
$lon  = floatval(isset($data['lon'])      ? $data['lon']      : 0);
$acc  = floatval(isset($data['accuracy']) ? $data['accuracy'] : 0);
$caseId = $data['case_id'] ? intval($data['case_id']) : null;

if (!$lat || !$lon) {
    echo json_encode(['success'=>false,'error'=>'Koordinat GPS tidak sah.']); exit;
}

$officer = getCurrentOfficer();
$db      = Database::getInstance()->getConnection();

$stmt = $db->prepare("INSERT INTO officer_checkins (officer_id, case_id, latitude, longitude, accuracy) VALUES (?,?,?,?,?)");
$stmt->execute([$officer['id'], $caseId, $lat, $lon, $acc]);

// Update case to in_progress if case selected
if ($caseId) {
    $db->prepare("UPDATE cases SET status = 'in_progress' WHERE id = ? AND status = 'assigned'")->execute([$caseId]);
    $db->prepare("INSERT INTO case_activity_log (case_id, officer_id, action, old_value, new_value) VALUES (?,?,'Status changed','assigned','in_progress')")->execute([$caseId, $officer['id']]);
}

echo json_encode(['success'=>true]);
