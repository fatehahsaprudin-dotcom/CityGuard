<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('supervisor');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$data     = json_decode(file_get_contents('php://input'), true);
$caseId   = (int)($data['case_id']   ?? 0);
$action   = $data['action']          ?? 'assign';

if (!$caseId) { echo json_encode(['success'=>false,'error'=>'Case ID required.']); exit; }

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();

$chk = $db->prepare("SELECT id, status FROM cases WHERE id = ?");
$chk->execute([$caseId]);
$case = $chk->fetch();
if (!$case) { echo json_encode(['success'=>false,'error'=>'Case not found.']); exit; }

if ($action === 'reject') {
    $db->prepare("UPDATE cases SET status='rejected', updated_at=NOW() WHERE id=?")->execute([$caseId]);
    $db->prepare("INSERT INTO case_activity_log (case_id, user_id, action, old_value, new_value) VALUES (?,?,'Case rejected',?,?)")->execute([$caseId, $user['id'], $case['status'], 'rejected']);
    echo json_encode(['success' => true]); exit;
}

$officerId = !empty($data['officer_id']) ? (int)$data['officer_id'] : null;
$vendorId  = !empty($data['vendor_id'])  ? (int)$data['vendor_id']  : null;

if (!$officerId && !$vendorId) { echo json_encode(['success'=>false,'error'=>'Select at least an officer or vendor.']); exit; }

if ($officerId) {
    $chkO = $db->prepare("SELECT id FROM users WHERE id=? AND role='officer' AND is_active=1");
    $chkO->execute([$officerId]);
    if (!$chkO->fetch()) { echo json_encode(['success'=>false,'error'=>'Officer not found.']); exit; }
}
if ($vendorId) {
    $chkV = $db->prepare("SELECT id FROM users WHERE id=? AND role='vendor' AND is_active=1");
    $chkV->execute([$vendorId]);
    if (!$chkV->fetch()) { echo json_encode(['success'=>false,'error'=>'Vendor not found.']); exit; }
}

$db->prepare("UPDATE cases SET assigned_to=?, vendor_id=?, status='assigned', assigned_at=NOW(), updated_at=NOW() WHERE id=?")->execute([$officerId, $vendorId, $caseId]);
$db->prepare("INSERT INTO case_activity_log (case_id, user_id, action, old_value, new_value) VALUES (?,?,'Case assigned',?,?)")->execute([$caseId, $user['id'], $case['status'], 'assigned']);

echo json_encode(['success' => true]);
