<?php
// api/resolve_case.php — Save resolution to DB
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); exit(json_encode(['success'=>false]));
}

$data        = json_decode(file_get_contents('php://input'), true);
$caseId      = intval(isset($data['case_id'])      ? $data['case_id']      : 0);
$photoBase64 = isset($data['photo_base64'])        ? $data['photo_base64']  : '';
$aiReport    = trim(isset($data['ai_report'])      ? $data['ai_report']     : '');
$notes       = trim(isset($data['notes'])          ? $data['notes']         : '');

if (!$caseId || !$photoBase64 || !$aiReport) {
    echo json_encode(['success'=>false,'error'=>'Data tidak lengkap.']); exit;
}

$officer = getCurrentOfficer();
$db      = Database::getInstance()->getConnection();

// Verify case belongs to officer
$stmt = $db->prepare("SELECT id FROM cases WHERE id = ? AND assigned_to = ? AND status != ?");
$stmt->execute([$caseId, $officer['id'], STATUS_RESOLVED]);
if (!$stmt->fetch()) {
    echo json_encode(['success'=>false,'error'=>'Kes tidak sah atau sudah diselesaikan.']); exit;
}

// Save photo to disk
$ext      = 'jpg';
$filename = 'evidence_' . $caseId . '_' . time() . '.' . $ext;
$filepath = UPLOAD_PATH . $filename;

$imgData = preg_replace('/^data:image\/[a-z]+;base64,/', '', $photoBase64);
if (!file_put_contents($filepath, base64_decode($imgData))) {
    echo json_encode(['success'=>false,'error'=>'Gagal menyimpan gambar.']); exit;
}

// Save resolution record
$stmt = $db->prepare("
    INSERT INTO case_resolutions (case_id, officer_id, evidence_photo, ai_completion, officer_notes, resolved_at)
    VALUES (?,?,?,?,?,NOW())
    ON DUPLICATE KEY UPDATE evidence_photo=VALUES(evidence_photo), ai_completion=VALUES(ai_completion),
    officer_notes=VALUES(officer_notes), resolved_at=NOW()
");
$stmt->execute([$caseId, $officer['id'], $filename, $aiReport, $notes]);

// Update case status
$db->prepare("UPDATE cases SET status = ? WHERE id = ?")->execute([STATUS_RESOLVED, $caseId]);

// Activity log
$db->prepare("INSERT INTO case_activity_log (case_id, officer_id, action, old_value, new_value) VALUES (?,?,'Status changed','in_progress','resolved')")
   ->execute([$caseId, $officer['id']]);

echo json_encode(['success'=>true]);
