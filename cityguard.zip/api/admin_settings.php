<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$data   = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';
$db     = Database::getInstance()->getConnection();

switch ($action) {
    case 'get':
        $rows = $db->query("SELECT `key`, value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);
        echo json_encode(['success' => true, 'settings' => $rows]);
        break;

    case 'set':
        $key   = trim($data['key']   ?? '');
        $value = trim($data['value'] ?? '');
        if (!$key) { echo json_encode(['success'=>false,'error'=>'Key required.']); exit; }
        $db->prepare("INSERT INTO settings (`key`, value) VALUES (?,?) ON DUPLICATE KEY UPDATE value=?")->execute([$key, $value, $value]);
        echo json_encode(['success' => true]);
        break;

    case 'test':
        $model = trim($data['model'] ?? 'openai/gpt-oss-120b:free');
        $apiKey = parse_ini_file(__DIR__ . '/../generationkey.env')['OPENROUTER_API_KEY'];
        $payload = [
            'model'    => $model,
            'messages' => [['role'=>'user','content'=>'Reply with exactly: {"ok":true}']],
            'max_tokens' => 20,
        ];
        $ch = curl_init('https://openrouter.ai/api/v1/chat/completions');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json','Authorization: Bearer '.$apiKey,'HTTP-Referer: http://localhost/cityguard'],
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_TIMEOUT        => 15,
        ]);
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        unset($ch);
        if ($code === 200) {
            echo json_encode(['success'=>true,'msg'=>'Model responded OK (HTTP 200)']);
        } else {
            $err = json_decode($res, true);
            echo json_encode(['success'=>false,'error'=>$err['error']['message'] ?? 'HTTP '.$code]);
        }
        break;

    default:
        echo json_encode(['success'=>false,'error'=>'Unknown action.']);
}
