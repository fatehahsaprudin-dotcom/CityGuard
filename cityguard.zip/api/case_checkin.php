<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('officer');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$data   = json_decode(file_get_contents('php://input'), true);
$lat    = isset($data['lat'])    ? (float)$data['lat']    : null;
$lon    = isset($data['lon'])    ? (float)$data['lon']    : null;
$acc    = isset($data['accuracy']) ? (float)$data['accuracy'] : null;
$caseId = !empty($data['case_id']) ? (int)$data['case_id'] : null;

if (!$lat || !$lon) { echo json_encode(['success'=>false,'error'=>'Koordinat GPS diperlukan.']); exit; }
if ($lat < -90 || $lat > 90 || $lon < -180 || $lon > 180) { echo json_encode(['success'=>false,'error'=>'Koordinat tidak sah.']); exit; }

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();

if ($caseId) {
    $chk = $db->prepare("SELECT id FROM cases WHERE id = ? AND assigned_to = ?");
    $chk->execute([$caseId, $user['id']]);
    if (!$chk->fetch()) { echo json_encode(['success'=>false,'error'=>'Kes tidak dijumpai.']); exit; }
}

$ins = $db->prepare("INSERT INTO officer_checkins (officer_id, case_id, latitude, longitude, accuracy) VALUES (?,?,?,?,?)");
$ins->execute([$user['id'], $caseId, $lat, $lon, $acc]);

if ($caseId) {
    $upd = $db->prepare("UPDATE cases SET status='in_progress', updated_at=NOW() WHERE id = ? AND status = 'assigned'");
    $upd->execute([$caseId]);
    $log = $db->prepare("INSERT INTO case_activity_log (case_id, user_id, action, old_value, new_value) VALUES (?,?,'Check-in GPS','assigned','in_progress')");
    $log->execute([$caseId, $user['id']]);
}

echo json_encode(['success' => true]);
