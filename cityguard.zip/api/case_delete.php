﻿<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('resident');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$data   = json_decode(file_get_contents('php://input'), true);
$caseId = (int)($data['case_id'] ?? 0);

if (!$caseId) { echo json_encode(['success'=>false,'error'=>'Invalid report.']); exit; }

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();

// Only allow delete if status is 'new' and belongs to this resident
$chk = $db->prepare("SELECT id, report_photo FROM cases WHERE id=? AND reported_by=? AND status='new'");
$chk->execute([$caseId, $user['id']]);
$case = $chk->fetch();
if (!$case) {
    echo json_encode(['success'=>false,'error'=>'Report not found or cannot be deleted.']); exit;
}

// Delete uploaded photo if exists
if (!empty($case['report_photo'])) {
    $photoPath = UPLOAD_REPORTS . $case['report_photo'];
    if (file_exists($photoPath)) @unlink($photoPath);
}

// Delete activity log entries first (FK constraint)
$db->prepare("DELETE FROM case_activity_log WHERE case_id=?")->execute([$caseId]);

// Delete the case
$db->prepare("DELETE FROM cases WHERE id=?")->execute([$caseId]);

echo json_encode(['success' => true]);
