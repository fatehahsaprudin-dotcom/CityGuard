<?php
ob_start();
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('resident');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { ob_end_clean(); http_response_code(405); exit; }

try {

$title    = trim($_POST['title']       ?? '');
$category = trim($_POST['category']    ?? '');
$desc     = trim($_POST['description'] ?? '');
$priority = $_POST['priority']         ?? 'medium';
$address  = trim($_POST['address']     ?? '');
$lat      = !empty($_POST['latitude'])  ? (float)$_POST['latitude']  : null;
$lon      = !empty($_POST['longitude']) ? (float)$_POST['longitude'] : null;

if (!$title || !$category) {
    ob_end_clean(); echo json_encode(['success' => false, 'error' => 'Title and issue type are required.']); exit;
}
if (!$address) {
    ob_end_clean(); echo json_encode(['success' => false, 'error' => 'Please enter a location or use GPS detect.']); exit;
}
if (!in_array($priority, ['high','medium','low'])) $priority = 'medium';

// Handle photo upload
$photo_filename = null;
if (!empty($_FILES['photo']['tmp_name'])) {
    $file = $_FILES['photo'];
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        ob_end_clean(); echo json_encode(['success' => false, 'error' => 'Photo too large (max 5MB).']); exit;
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','webp'])) {
        ob_end_clean(); echo json_encode(['success' => false, 'error' => 'Unsupported image format (JPG/PNG/WebP only).']); exit;
    }
    if (!is_dir(UPLOAD_REPORTS)) mkdir(UPLOAD_REPORTS, 0755, true);
    $photo_filename = uniqid('rpt_', true) . '.' . $ext;
    move_uploaded_file($file['tmp_name'], UPLOAD_REPORTS . $photo_filename);
}

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();

// Generate case code — use MAX suffix to avoid gaps/conflicts from deleted cases
$year   = date('Y');
$prefix = 'CG-' . $year . '-';
$maxNum = (int)$db->query("SELECT MAX(CAST(SUBSTRING(case_code, " . (strlen($prefix) + 1) . ") AS UNSIGNED)) FROM cases WHERE case_code LIKE '{$prefix}%'")->fetchColumn();
$code   = $prefix . str_pad($maxNum + 1, 3, '0', STR_PAD_LEFT);

// Lookup dept from categories table, fall back to DEPT_ROUTING constant
$dept = DEPT_ROUTING[$category] ?? 'MPSA';
try {
    $catRow = $db->prepare("SELECT dept FROM categories WHERE name = ? AND is_active = 1");
    $catRow->execute([$category]);
    $catData = $catRow->fetch();
    if ($catData && $catData['dept']) $dept = $catData['dept'];
} catch (PDOException $e) {}

// Insert case
$stmt = $db->prepare("
    INSERT INTO cases (case_code, title, category, description, priority, status, latitude, longitude, address, report_photo, assigned_dept, reported_by, reported_at)
    VALUES (?,?,?,?,?,'new',?,?,?,?,?,?,NOW())
");
$stmt->execute([$code, $title, $category, $desc, $priority, $lat, $lon, $address, $photo_filename, $dept, $user['id']]);
$caseId = (int)$db->lastInsertId();

// Auto-assign vendor from category_vendors mapping
$autoVendor = null;
try {
    $cv = $db->prepare("
        SELECT cv.vendor_id FROM category_vendors cv
        JOIN categories c ON c.id = cv.category_id
        WHERE c.name = ? AND c.is_active = 1
    ");
    $cv->execute([$category]);
    $autoVendor = $cv->fetchColumn();
} catch (PDOException $e) {}

if ($autoVendor) {
    $db->prepare("UPDATE cases SET vendor_id=? WHERE id=?")->execute([$autoVendor, $caseId]);
}

try {
    $db->prepare("INSERT INTO case_activity_log (case_id, user_id, action, new_value) VALUES (?,?,'Report submitted',?)")
       ->execute([$caseId, $user['id'], $code]);
} catch (PDOException $e) {}

ob_end_clean();
echo json_encode(['success' => true, 'case_code' => $code]);

} catch (Throwable $e) {
    ob_end_clean();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
