<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('officer');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$data        = json_decode(file_get_contents('php://input'), true);
$caseId      = (int)($data['case_id']       ?? 0);
$notes       = trim($data['officer_notes']   ?? '');

if (!$caseId) { echo json_encode(['success'=>false,'error'=>'Incomplete data.']); exit; }

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();
$stmt = $db->prepare("SELECT * FROM cases WHERE id = ? AND assigned_to = ?");
$stmt->execute([$caseId, $user['id']]);
$case = $stmt->fetch();
if (!$case) { echo json_encode(['success'=>false,'error'=>'Case not found.']); exit; }

// ── OPENROUTER API KEY ────────────────────────────────────────────────────────
$apiKey = parse_ini_file(__DIR__ . '/../generationkey.env')['OPENROUTER_API_KEY'];
// ─────────────────────────────────────────────────────────────────────────────

$prompt = "You are an AI system for a Smart Communities management platform.
A field officer has resolved the following case and submitted evidence.

Case: {$case['case_code']} — {$case['title']}
Category: {$case['category']} | Dept: {$case['assigned_dept']}
Location: {$case['address']}
Description: {$case['description']}
Officer notes: " . ($notes ?: 'None') . "
Officer: {$user['name']}, {$user['dept']}
Resolved: " . date('d M Y, H:i') . "

Write a structured completion report in English (under 150 words):
1. Work completed
2. Evidence summary
3. Remaining risk (None/Low/Medium)
4. Recommended follow-up";

$payload = [
    'model'    => 'openai/gpt-oss-120b:free',
    'messages' => [['role' => 'user', 'content' => $prompt]],
    'max_tokens'  => 512,
    'temperature' => 0.3,
];

$ch = curl_init('https://openrouter.ai/api/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey,
        'HTTP-Referer: http://localhost/cityguide',
    ],
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_TIMEOUT    => 30,
]);
$response = curl_exec($ch);
$code     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
unset($ch);

if ($code !== 200) { echo json_encode(['success'=>false,'error'=>'AI unavailable. Please try again.']); exit; }

$result = json_decode($response, true);
$report = $result['choices'][0]['message']['content'] ?? 'AI failed to generate report.';
echo json_encode(['success'=>true,'report'=>trim($report)]);
