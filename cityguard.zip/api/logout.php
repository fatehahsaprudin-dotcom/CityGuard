<?php
// api/logout.php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/session.php';
logoutOfficer();
header('Location: ' . BASE_URL . '/login.php');
exit;
