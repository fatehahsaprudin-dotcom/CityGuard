﻿<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('resident');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$data     = json_decode(file_get_contents('php://input'), true);
$caseId   = (int)($data['case_id']     ?? 0);
$title    = trim($data['title']        ?? '');
$category = trim($data['category']     ?? '');
$priority = $data['priority']          ?? 'medium';
$desc     = trim($data['description']  ?? '');
$address  = trim($data['address']      ?? '');

if (!$caseId || !$title || !$category) {
    echo json_encode(['success'=>false,'error'=>'Title and category are required.']); exit;
}
if (!in_array($priority, ['high','medium','low'])) $priority = 'medium';

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();

$chk = $db->prepare("SELECT id FROM cases WHERE id=? AND reported_by=? AND status='new'");
$chk->execute([$caseId, $user['id']]);
if (!$chk->fetch()) {
    echo json_encode(['success'=>false,'error'=>'Report not found or cannot be edited.']); exit;
}

// Update dept from categories table if available
$dept = DEPT_ROUTING[$category] ?? 'MPSA';
try {
    $catRow = $db->prepare("SELECT dept FROM categories WHERE name=? AND is_active=1");
    $catRow->execute([$category]);
    $catData = $catRow->fetch();
    if ($catData && $catData['dept']) $dept = $catData['dept'];
} catch (PDOException $e) {}

$db->prepare("
    UPDATE cases SET title=?, category=?, priority=?, description=?, address=?, assigned_dept=?, updated_at=NOW()
    WHERE id=?
")->execute([$title, $category, $priority, $desc, $address, $dept, $caseId]);

$db->prepare("INSERT INTO case_activity_log (case_id, user_id, action) VALUES (?,?,'Resident updated report')")
   ->execute([$caseId, $user['id']]);

echo json_encode(['success' => true]);
