<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('officer');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$caseId = (int)($_POST['case_id'] ?? 0);
$newStatus = $_POST['resolution_status'] ?? 'resolved';
$notes  = trim($_POST['notes'] ?? '');

if (!$caseId) { echo json_encode(['success'=>false,'error'=>'Please select a case.']); exit; }
if (!in_array($newStatus, ['resolved','in_progress'])) $newStatus = 'resolved';

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();

$chk = $db->prepare("SELECT id, status FROM cases WHERE id = ? AND assigned_to = ? AND status IN ('assigned','in_progress')");
$chk->execute([$caseId, $user['id']]);
if (!$chk->fetch()) { echo json_encode(['success'=>false,'error'=>'Case not found or cannot be updated.']); exit; }

// Handle photo upload
$filename = null;
if (!empty($_FILES['evidence_photo']['tmp_name'])) {
    $file = $_FILES['evidence_photo'];
    if ($file['size'] > MAX_UPLOAD_SIZE) { echo json_encode(['success'=>false,'error'=>'Photo too large (max 5MB).']); exit; }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg','jpeg','png','webp'])) { echo json_encode(['success'=>false,'error'=>'Unsupported image format.']); exit; }
    if (!is_dir(UPLOAD_EVIDENCE)) mkdir(UPLOAD_EVIDENCE, 0755, true);
    $filename = 'ev_' . $caseId . '_' . time() . '.' . $ext;
    move_uploaded_file($file['tmp_name'], UPLOAD_EVIDENCE . $filename);
}

// Save / update resolution record only when resolving
if ($newStatus === 'resolved') {
    $ex = $db->prepare("SELECT id FROM case_resolutions WHERE case_id = ?");
    $ex->execute([$caseId]);
    if ($ex->fetch()) {
        $upd = $db->prepare("UPDATE case_resolutions SET evidence_photo=COALESCE(?,evidence_photo), officer_notes=?, resolved_at=NOW() WHERE case_id=?");
        $upd->execute([$filename, $notes, $caseId]);
    } else {
        $ins = $db->prepare("INSERT INTO case_resolutions (case_id, officer_id, evidence_photo, officer_notes) VALUES (?,?,?,?)");
        $ins->execute([$caseId, $user['id'], $filename, $notes]);
    }
}

$db->prepare("UPDATE cases SET status=?, updated_at=NOW() WHERE id=?")->execute([$newStatus, $caseId]);
$db->prepare("INSERT INTO case_activity_log (case_id, user_id, action, new_value) VALUES (?,?,?,?)")
   ->execute([$caseId, $user['id'], 'Officer update: ' . ($notes ?: $newStatus), $newStatus]);

echo json_encode(['success' => true]);
