<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('resident');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$db   = Database::getInstance()->getConnection();
$data = json_decode(file_get_contents('php://input'), true);
$keywords    = trim($data['keywords']  ?? '');
$category    = trim($data['category']  ?? '');
$address     = trim($data['address']   ?? '');
$language    = trim($data['language']  ?? 'English');
if (!in_array($language, ['English', 'Bahasa Malaysia'])) $language = 'English';

if (!$keywords || !$category) {
    echo json_encode(['success'=>false,'error'=>'Please enter keywords and select a category first.']);
    exit;
}

// ── OPENROUTER API KEY & MODEL ────────────────────────────────────────────────
$apiKey = parse_ini_file(__DIR__ . '/../generationkey.env')['OPENROUTER_API_KEY'];
$settingsRows = $db->query("SELECT `key`, value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR);
$aiModel      = !empty($settingsRows['ai_model'])       ? $settingsRows['ai_model']       : 'openai/gpt-oss-120b:free';
$aiTemp       = isset($settingsRows['ai_temperature'])  ? (float)$settingsRows['ai_temperature'] : 0.3;
$aiMaxTokens  = isset($settingsRows['ai_max_tokens'])   ? (int)$settingsRows['ai_max_tokens']    : 400;
// ─────────────────────────────────────────────────────────────────────────────

$locationLine = $address ? "Location  : {$address}" : "Location  : Not specified";

if ($language === 'Bahasa Malaysia') {
    $prompt = "Anda adalah pembantu penulisan laporan untuk CityGuard, platform Komuniti Pintar di Malaysia.

Seorang penduduk ingin melaporkan isu awam. Berdasarkan maklumat di bawah, tulis laporan profesional dalam Bahasa Malaysia.

Kategori  : {$category}
{$locationLine}
Kata kunci : {$keywords}

Tulis laporan dalam format JSON berikut dan kembalikan HANYA objek JSON (tanpa markdown, tanpa teks tambahan):

{
  \"title\": \"<tajuk ringkas, maksimum 80 aksara>\",
  \"priority\": \"<high|medium|low — high jika risiko keselamatan, medium jika gangguan ketara, low jika minor>\",
  \"report\": \"<tulis tepat 5 poin bullet:\\n• Isu: huraikan dengan jelas apakah masalah berdasarkan kategori dan kata kunci\\n• Lokasi: nyatakan dengan tepat di mana kejadian ini berlaku berdasarkan lokasi yang diberikan\\n• Kesan 1: huraikan kesan langsung kepada penduduk atau orang ramai\\n• Kesan 2: huraikan kesan kedua atau tidak langsung kepada penduduk atau orang ramai\\n• Tindakan Segera: nyatakan tindakan yang mesti diambil oleh pihak berkuasa dengan segera>\"
}";
} else {
    $prompt = "You are a report-writing assistant for CityGuard, a Smart Communities platform in Malaysia.

A resident wants to report a public issue. Based on the details below, write a professional report in English.

Category  : {$category}
{$locationLine}
Keywords  : {$keywords}

Write the report in this exact format and return ONLY a JSON object (no markdown, no extra text):

{
  \"title\": \"<short title, max 80 characters>\",
  \"priority\": \"<high|medium|low — high if safety risk, medium if significant inconvenience, low if minor>\",
  \"report\": \"<write exactly 5 bullet points:\\n• Issue: clearly describe what the problem is based on the category and keywords\\n• Location: state exactly where this occurred based on the location provided\\n• Impact 1: describe the direct impact on residents or the public\\n• Impact 2: describe a secondary or indirect impact on residents or the public\\n• Immediate Action: state what authorities must do urgently to resolve this>\"
}";
}

$payload = [
    'model'       => $aiModel,
    'messages'    => [['role' => 'user', 'content' => $prompt]],
    'max_tokens'  => $aiMaxTokens,
    'temperature' => $aiTemp,
];

$ch = curl_init('https://openrouter.ai/api/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey,
        'HTTP-Referer: http://localhost/cityguard',
    ],
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_TIMEOUT    => 30,
]);
$response = curl_exec($ch);
$code     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
unset($ch);

if ($code !== 200) {
    $errBody = json_decode($response, true);
    $errMsg  = $errBody['error']['message'] ?? ('HTTP ' . $code);
    echo json_encode(['success'=>false,'error'=>$errMsg]);
    exit;
}

$result = json_decode($response, true);
$text   = $result['choices'][0]['message']['content'] ?? '';

// Strip markdown fences
$text = trim(preg_replace('/^```(?:json)?\s*/i', '', $text));
$text = preg_replace('/\s*```$/', '', $text);

$out = json_decode(trim($text), true);
if (!$out || empty($out['report'])) {
    echo json_encode(['success'=>false,'error'=>'AI could not generate a report. Please fill in manually.']);
    exit;
}

if (!in_array($out['priority'] ?? '', ['high','medium','low'])) $out['priority'] = 'medium';
$out['title']  = substr(strip_tags($out['title']  ?? ''), 0, 150);
$out['report'] = strip_tags($out['report'] ?? '');

echo json_encode(['success' => true, 'result' => $out]);
