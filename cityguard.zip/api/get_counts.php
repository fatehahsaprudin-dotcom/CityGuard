<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');

if (!isLoggedIn()) { echo json_encode(['pending' => 0]); exit; }

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();

if (isRole('officer')) {
    $stmt = $db->prepare("SELECT COUNT(*) FROM cases WHERE assigned_to = ? AND status NOT IN ('resolved','approved','rejected')");
    $stmt->execute([$user['id']]);
} elseif (isRole('supervisor')) {
    $stmt = $db->prepare("SELECT COUNT(*) FROM cases WHERE status = 'new'");
    $stmt->execute([]);
} elseif (isRole('admin')) {
    $stmt = $db->prepare("SELECT COUNT(*) FROM case_resolutions WHERE approved_by IS NULL AND approved_at IS NULL");
    $stmt->execute([]);
} else {
    echo json_encode(['pending' => 0]); exit;
}

echo json_encode(['pending' => (int)$stmt->fetchColumn()]);
