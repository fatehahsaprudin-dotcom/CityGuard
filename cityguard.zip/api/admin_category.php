<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
header('Content-Type: application/json');
requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$data   = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';
$db     = Database::getInstance()->getConnection();

switch ($action) {

    case 'add':
        $name    = trim($data['name'] ?? '');
        $name_bm = !empty($data['name_bm']) ? trim($data['name_bm']) : null;
        $dept    = trim($data['dept'] ?? '');
        $vid     = !empty($data['vendor_id']) ? (int)$data['vendor_id'] : null;
        if (!$name) { echo json_encode(['success'=>false,'error'=>'Name is required.']); exit; }
        try {
            $db->prepare("INSERT INTO categories (name, name_bm, dept) VALUES (?,?,?)")->execute([$name, $name_bm, $dept]);
            $catId = (int)$db->lastInsertId();
            if ($vid) {
                $db->prepare("INSERT INTO category_vendors (category_id, vendor_id) VALUES (?,?)")->execute([$catId, $vid]);
            }
            echo json_encode(['success'=>true, 'id'=>$catId]);
        } catch (PDOException $e) {
            echo json_encode(['success'=>false,'error'=>'Category name already exists.']);
        }
        break;

    case 'update':
        $id      = (int)($data['id'] ?? 0);
        $name    = trim($data['name'] ?? '');
        $name_bm = !empty($data['name_bm']) ? trim($data['name_bm']) : null;
        $dept    = trim($data['dept'] ?? '');
        if (!$id || !$name) { echo json_encode(['success'=>false,'error'=>'Invalid data.']); exit; }
        try {
            $db->prepare("UPDATE categories SET name=?, name_bm=?, dept=? WHERE id=?")->execute([$name, $name_bm, $dept, $id]);
            echo json_encode(['success'=>true]);
        } catch (PDOException $e) {
            echo json_encode(['success'=>false,'error'=>'Category name already exists.']);
        }
        break;

    case 'delete':
        $id = (int)($data['id'] ?? 0);
        if (!$id) { echo json_encode(['success'=>false,'error'=>'Invalid ID.']); exit; }
        $db->prepare("DELETE FROM categories WHERE id=?")->execute([$id]);
        echo json_encode(['success'=>true]);
        break;

    case 'assign_vendor':
        $catId = (int)($data['category_id'] ?? 0);
        $vid   = !empty($data['vendor_id']) ? (int)$data['vendor_id'] : null;
        if (!$catId) { echo json_encode(['success'=>false,'error'=>'Invalid category.']); exit; }
        $db->prepare("DELETE FROM category_vendors WHERE category_id=?")->execute([$catId]);
        if ($vid) {
            $db->prepare("INSERT INTO category_vendors (category_id, vendor_id) VALUES (?,?)")->execute([$catId, $vid]);
        }
        echo json_encode(['success'=>true]);
        break;

    case 'toggle':
        $id     = (int)($data['id'] ?? 0);
        $active = (int)($data['is_active'] ?? 0);
        if (!$id) { echo json_encode(['success'=>false,'error'=>'Invalid ID.']); exit; }
        $db->prepare("UPDATE categories SET is_active=? WHERE id=?")->execute([$active, $id]);
        echo json_encode(['success'=>true]);
        break;

    default:
        echo json_encode(['success'=>false,'error'=>'Unknown action.']);
}
