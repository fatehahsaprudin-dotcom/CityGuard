<?php
require_once __DIR__ . '/config/constants.php';
require_once __DIR__ . '/config/session.php';
if (isLoggedIn()) {
    header('Location: ' . getDashboardUrl());
} else {
    header('Location: ' . BASE_URL . '/login.php');
}
exit;
