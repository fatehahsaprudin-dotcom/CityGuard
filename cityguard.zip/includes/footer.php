<?php
// includes/footer.php — closes both public and dashboard layouts
$is_dash = isset($layout) && $layout === 'dash';
?>
<?php if ($is_dash): ?>
  </div><!-- /.cg-content -->
</div><!-- /.cg-main -->
</div><!-- /.cg-wrap -->
<?php else: ?>
</div><!-- /.pub-content -->
<?php endif; ?>

<!-- Global Case Detail Modal -->
<div class="modal fade" id="caseDetailModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-scrollable modal-lg">
    <div class="modal-content border-0" style="border-radius:16px">
      <div class="modal-header border-0 pb-0">
        <div style="flex:1;min-width:0">
          <div class="d-flex align-items-center gap-2 flex-wrap mb-1">
            <code id="d-code" class="small text-muted"></code>
            <span id="d-status-badge"></span>
            <span id="d-priority-badge"></span>
          </div>
          <h6 class="modal-title fw-semibold mb-0" id="d-title"></h6>
        </div>
        <button type="button" class="btn-close ms-3" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="row g-2 mb-3 small">
          <div class="col-6"><span class="text-muted">Category</span><br><strong id="d-category"></strong></div>
          <div class="col-6"><span class="text-muted">Date</span><br><strong id="d-date"></strong></div>
          <div class="col-12"><span class="text-muted"><i class="bi bi-geo-alt me-1"></i>Location</span><br><strong id="d-address"></strong></div>
          <div class="col-6"><span class="text-muted"><i class="bi bi-person me-1"></i>Reported by</span><br><strong id="d-reporter"></strong></div>
          <div class="col-6"><span class="text-muted"><i class="bi bi-person-badge me-1"></i>Officer</span><br><strong id="d-officer"></strong></div>
          <div class="col-12"><span class="text-muted"><i class="bi bi-building me-1"></i>Vendor</span><br><strong id="d-vendor"></strong></div>
        </div>
        <div id="d-photo-wrap" class="mb-3" style="display:none">
          <span class="text-muted small">Photo</span><br>
          <img id="d-photo" src="" onclick="openPhoto(this.src)"
               style="max-height:240px;max-width:100%;border-radius:10px;cursor:pointer;border:2px solid #e2e8f0;margin-top:4px">
        </div>
        <div id="d-desc-wrap" style="display:none">
          <span class="text-muted small">Report Description</span>
          <div id="d-description" class="mt-1 small p-3 rounded" style="background:#f8fafc;white-space:pre-wrap;line-height:1.8"></div>
        </div>
      </div>
      <div class="modal-footer border-0 pt-0">
        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Global Photo Lightbox -->
<div class="modal fade" id="photoLightbox" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered" style="max-width:90vw;width:auto">
    <div class="modal-content border-0 bg-transparent shadow-none">
      <div class="modal-body p-0 text-center position-relative">
        <button type="button" class="btn-close btn-close-white position-absolute top-0 end-0 m-2 z-3" data-bs-dismiss="modal"></button>
        <img id="lightbox-img" src="" alt="Photo"
             style="max-width:90vw;max-height:88vh;border-radius:10px;object-fit:contain;display:block;margin:auto">
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/js/app.js?v=<?= filemtime(__DIR__.'/../assets/js/app.js') ?>"></script>
<script>
function openDetail(c) {
  var el = document.getElementById('caseDetailModal');
  if (!el) return;
  var sl = window._statusLabels   || {new:'New',assigned:'Assigned',in_progress:'In Progress',resolved:'Resolved',approved:'Approved',rejected:'Rejected'};
  var pl = window._priorityLabels || {high:'High',medium:'Medium',low:'Low'};
  document.getElementById('d-code').textContent     = c.code        || '';
  document.getElementById('d-title').textContent    = c.title       || '';
  document.getElementById('d-category').textContent = c.category    || '—';
  document.getElementById('d-date').textContent     = c.date        || '—';
  document.getElementById('d-address').textContent  = c.address     || '—';
  document.getElementById('d-reporter').textContent = c.reporter    || '—';
  document.getElementById('d-officer').textContent  = c.officer     || '—';
  document.getElementById('d-vendor').textContent   = c.vendor      || '—';
  document.getElementById('d-status-badge').innerHTML   = '<span class="badge badge-status-'   + c.status   + '">' + (sl[c.status]   || c.status)   + '</span>';
  document.getElementById('d-priority-badge').innerHTML = '<span class="badge badge-priority-' + c.priority + '">' + (pl[c.priority] || c.priority) + '</span>';
  var pw = document.getElementById('d-photo-wrap');
  if (c.photo) { document.getElementById('d-photo').src = c.photo; pw.style.display = ''; }
  else { pw.style.display = 'none'; }
  var dw = document.getElementById('d-desc-wrap');
  if (c.description) { document.getElementById('d-description').textContent = c.description; dw.style.display = ''; }
  else { dw.style.display = 'none'; }
  bootstrap.Modal.getOrCreateInstance(el).show();
}
</script>
<?php if (isset($extra_js)) echo $extra_js; ?>
</body>
</html>
