<?php
// includes/header.php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireLogin();
$officer = getCurrentOfficer();
?>
<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= APP_NAME ?></title>
  <!-- AdminLTE 4 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@4.0.0-beta2/dist/css/adminlte.min.css">
  <!-- Bootstrap 5 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!-- Custom -->
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">

  <!-- Navbar -->
  <nav class="app-header navbar navbar-expand bg-body">
    <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
            <i class="bi bi-list fs-5"></i>
          </a>
        </li>
      </ul>
      <a href="<?= BASE_URL ?>/pages/cases.php" class="navbar-brand ms-2">
        <i class="bi bi-shield-check text-success me-1"></i>
        <span class="fw-semibold">CityGuard</span>
        <small class="text-muted fw-normal ms-1">Field Officer</small>
      </a>
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <span class="badge bg-success-subtle text-success me-2">
            <i class="bi bi-wifi"></i> Online
          </span>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link d-flex align-items-center gap-2" href="#" data-bs-toggle="dropdown">
            <div class="rounded-circle bg-success-subtle text-success d-flex align-items-center justify-content-center fw-semibold" style="width:32px;height:32px;font-size:12px">
              <?= strtoupper(substr($officer['name'], 0, 2)) ?>
            </div>
            <span class="d-none d-md-inline small"><?= htmlspecialchars($officer['name']) ?></span>
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><span class="dropdown-item-text small text-muted"><?= htmlspecialchars($officer['unit']) ?> · <?= htmlspecialchars($officer['dept']) ?></span></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="<?= BASE_URL ?>/api/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Log out</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </nav>

  <!-- Sidebar -->
  <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="light">
    <div class="sidebar-brand">
      <a href="<?= BASE_URL ?>/pages/cases.php" class="brand-link">
        <i class="bi bi-shield-check text-success me-2 fs-5"></i>
        <span class="brand-text fw-semibold">Field Officer</span>
      </a>
    </div>
    <div class="sidebar-wrapper">
      <nav class="mt-2">
        <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview">
          <li class="nav-header text-uppercase small">Main</li>
          <li class="nav-item">
            <a href="<?= BASE_URL ?>/pages/cases.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'cases.php' ? 'active' : '' ?>">
              <i class="nav-icon bi bi-clipboard-check"></i>
              <p>My Cases <span class="badge bg-danger ms-auto" id="pending-count">-</span></p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?= BASE_URL ?>/pages/checkin.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'checkin.php' ? 'active' : '' ?>">
              <i class="nav-icon bi bi-geo-alt"></i>
              <p>GPS Check-in</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?= BASE_URL ?>/pages/resolve.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'resolve.php' ? 'active' : '' ?>">
              <i class="nav-icon bi bi-camera"></i>
              <p>Resolve Case</p>
            </a>
          </li>
          <li class="nav-header text-uppercase small">Reports</li>
          <li class="nav-item">
            <a href="<?= BASE_URL ?>/pages/stats.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'stats.php' ? 'active' : '' ?>">
              <i class="nav-icon bi bi-bar-chart"></i>
              <p>My Stats</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?= BASE_URL ?>/pages/history.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'history.php' ? 'active' : '' ?>">
              <i class="nav-icon bi bi-clock-history"></i>
              <p>History</p>
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </aside>

  <!-- Content Wrapper -->
  <main class="app-main">
    <div class="app-content-header py-3 px-4 border-bottom">
      <div class="container-fluid">
