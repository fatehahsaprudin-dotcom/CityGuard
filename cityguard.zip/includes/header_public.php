<?php
// includes/header_public.php — Top navbar for resident (public) pages
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($page_title ?? APP_NAME) ?> — <?= APP_NAME ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <script>
    const BASE_URL = '<?= BASE_URL ?>';
    window._statusLabels={new:'<?= t('status_new') ?>',assigned:'<?= t('status_assigned') ?>',in_progress:'<?= t('status_in_progress') ?>',resolved:'<?= t('status_resolved') ?>',approved:'<?= t('status_approved') ?>',rejected:'<?= t('status_rejected') ?>'};
    window._priorityLabels={high:'<?= t('pri_high') ?>',medium:'<?= t('pri_medium') ?>',low:'<?= t('pri_low') ?>'};
  </script>
</head>
<body>

<nav class="pub-nav">
  <a href="<?= BASE_URL ?>/resident/" class="nav-brand">
    <div class="brand-dot"><i class="bi bi-geo-alt-fill"></i></div>
    <?= APP_NAME ?>
  </a>
  <div class="nav-links">
    <div class="d-flex gap-1 me-1">
      <a href="?setlang=en" class="btn btn-xs <?= langIs('en') ? 'btn-primary' : 'btn-outline-secondary' ?>" style="font-size:.7rem;padding:2px 8px">EN</a>
      <a href="?setlang=bm" class="btn btn-xs <?= langIs('bm') ? 'btn-primary' : 'btn-outline-secondary' ?>" style="font-size:.7rem;padding:2px 8px">BM</a>
    </div>
    <?php if (isLoggedIn() && isRole('resident')): $u = getCurrentUser(); ?>
      <a href="<?= BASE_URL ?>/resident/" class="btn btn-sm btn-outline-secondary"><i class="bi bi-house me-1"></i><?= t('nav_home') ?></a>
      <a href="<?= BASE_URL ?>/resident/history.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-clock-history me-1"></i><?= t('nav_my_reports') ?></a>
      <a href="<?= BASE_URL ?>/resident/track.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-search me-1"></i><?= t('nav_track') ?></a>
      <div class="dropdown">
        <button class="btn btn-sm btn-primary dropdown-toggle" data-bs-toggle="dropdown">
          <?= htmlspecialchars(explode(' ', $u['name'])[0]) ?>
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>/logout.php"><i class="bi bi-box-arrow-right me-2"></i><?= t('nav_logout') ?></a></li>
        </ul>
      </div>
    <?php else: ?>
      <a href="<?= BASE_URL ?>/login.php" class="btn btn-sm btn-outline-primary"><?= t('nav_login') ?></a>
      <a href="<?= BASE_URL ?>/register.php" class="btn btn-sm btn-primary"><?= t('nav_register') ?></a>
    <?php endif; ?>
  </div>
</nav>

<div class="pub-content">
