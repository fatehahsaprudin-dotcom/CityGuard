<?php
// includes/header_dash.php — Sidebar layout for officer/supervisor/admin/vendor
$user     = getCurrentUser();
$role     = $user['role'];
$initials = strtoupper(substr($user['name'], 0, 1) . (strpos($user['name'], ' ') !== false ? substr($user['name'], strpos($user['name'], ' ') + 1, 1) : ''));
$roleLabel = ROLE_LABELS[$role] ?? ucfirst($role);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($page_title ?? APP_NAME) ?> — <?= APP_NAME ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <script>
    const BASE_URL = '<?= BASE_URL ?>';
    window._statusLabels={new:'<?= t('status_new') ?>',assigned:'<?= t('status_assigned') ?>',in_progress:'<?= t('status_in_progress') ?>',resolved:'<?= t('status_resolved') ?>',approved:'<?= t('status_approved') ?>',rejected:'<?= t('status_rejected') ?>'};
    window._priorityLabels={high:'<?= t('pri_high') ?>',medium:'<?= t('pri_medium') ?>',low:'<?= t('pri_low') ?>'};
  </script>
</head>
<body>
<div class="cg-wrap">

<aside class="cg-sidebar" id="cg-sidebar">
  <a href="<?= getDashboardUrl() ?>" class="cg-sidebar-brand">
    <div class="brand-icon"><i class="bi bi-geo-alt-fill"></i></div>
    <div class="brand-text"><?= APP_NAME ?><span><?= $roleLabel ?> Panel</span></div>
  </a>

  <?php if ($role === 'officer'): ?>
  <div class="cg-sidebar-section"><?= t('sec_cases') ?></div>
  <ul class="cg-nav">
    <li><a href="<?= BASE_URL ?>/officer/" class="<?= ($active_nav??'')==='cases'?'active':'' ?>">
      <i class="bi bi-clipboard2-check"></i> <?= t('nav_my_cases') ?>
      <span class="badge-pill" id="pending-count" style="display:none">0</span>
    </a></li>
    <li><a href="<?= BASE_URL ?>/officer/checkin.php" class="<?= ($active_nav??'')==='checkin'?'active':'' ?>">
      <i class="bi bi-geo-alt"></i> <?= t('nav_checkin') ?>
    </a></li>
    <li><a href="<?= BASE_URL ?>/officer/resolve.php" class="<?= ($active_nav??'')==='resolve'?'active':'' ?>">
      <i class="bi bi-check2-circle"></i> <?= t('nav_resolve') ?>
    </a></li>
  </ul>
  <div class="cg-sidebar-section"><?= t('sec_reports') ?></div>
  <ul class="cg-nav">
    <li><a href="<?= BASE_URL ?>/officer/stats.php" class="<?= ($active_nav??'')==='stats'?'active':'' ?>">
      <i class="bi bi-bar-chart-line"></i> <?= t('nav_performance') ?>
    </a></li>
    <li><a href="<?= BASE_URL ?>/officer/history.php" class="<?= ($active_nav??'')==='history'?'active':'' ?>">
      <i class="bi bi-clock-history"></i> <?= t('nav_history') ?>
    </a></li>
  </ul>

  <?php elseif ($role === 'supervisor'): ?>
  <div class="cg-sidebar-section"><?= t('sec_management') ?></div>
  <ul class="cg-nav">
    <li><a href="<?= BASE_URL ?>/supervisor/" class="<?= ($active_nav??'')==='cases'?'active':'' ?>">
      <i class="bi bi-kanban"></i> <?= t('nav_all_cases') ?>
      <span class="badge-pill" id="pending-count" style="display:none">0</span>
    </a></li>
    <li><a href="<?= BASE_URL ?>/supervisor/officers.php" class="<?= ($active_nav??'')==='officers'?'active':'' ?>">
      <i class="bi bi-person-badge"></i> <?= t('nav_officers') ?>
    </a></li>
    <li><a href="<?= BASE_URL ?>/supervisor/vendors.php" class="<?= ($active_nav??'')==='vendors'?'active':'' ?>">
      <i class="bi bi-building"></i> <?= t('nav_vendors') ?>
    </a></li>
  </ul>

  <?php elseif ($role === 'vendor'): ?>
  <div class="cg-sidebar-section"><?= t('sec_work_orders') ?></div>
  <ul class="cg-nav">
    <li><a href="<?= BASE_URL ?>/vendor/" class="<?= ($active_nav??'')==='cases'?'active':'' ?>">
      <i class="bi bi-clipboard2-check"></i> <?= t('nav_assigned') ?>
      <span class="badge-pill" id="pending-count" style="display:none">0</span>
    </a></li>
    <li><a href="<?= BASE_URL ?>/vendor/history.php" class="<?= ($active_nav??'')==='history'?'active':'' ?>">
      <i class="bi bi-clock-history"></i> <?= t('nav_completed') ?>
    </a></li>
  </ul>

  <?php elseif ($role === 'admin'): ?>
  <div class="cg-sidebar-section"><?= t('sec_dashboard') ?></div>
  <ul class="cg-nav">
    <li><a href="<?= BASE_URL ?>/admin/" class="<?= ($active_nav??'')==='overview'?'active':'' ?>">
      <i class="bi bi-grid-1x2"></i> <?= t('nav_overview') ?>
    </a></li>
    <li><a href="<?= BASE_URL ?>/admin/approve.php" class="<?= ($active_nav??'')==='approve'?'active':'' ?>">
      <i class="bi bi-patch-check"></i> <?= t('nav_approve') ?>
      <span class="badge-pill" id="pending-count" style="display:none">0</span>
    </a></li>
  </ul>
  <div class="cg-sidebar-section"><?= t('sec_management') ?></div>
  <ul class="cg-nav">
    <li><a href="<?= BASE_URL ?>/admin/cases.php" class="<?= ($active_nav??'')==='cases'?'active':'' ?>">
      <i class="bi bi-folder2-open"></i> <?= t('nav_all_cases') ?>
    </a></li>
    <li><a href="<?= BASE_URL ?>/admin/users.php" class="<?= ($active_nav??'')==='users'?'active':'' ?>">
      <i class="bi bi-person-gear"></i> <?= t('nav_users') ?>
    </a></li>
  </ul>
  <div class="cg-sidebar-section"><?= t('sec_settings') ?></div>
  <ul class="cg-nav">
    <li><a href="<?= BASE_URL ?>/admin/categories.php" class="<?= ($active_nav??'')==='categories'?'active':'' ?>">
      <i class="bi bi-tags"></i> <?= t('nav_categories') ?>
    </a></li>
    <li><a href="<?= BASE_URL ?>/admin/settings.php" class="<?= ($active_nav??'')==='settings'?'active':'' ?>">
      <i class="bi bi-robot"></i> <?= t('nav_settings') ?>
    </a></li>
  </ul>
  <?php endif; ?>

  <div class="cg-sidebar-footer">
    <div class="cg-user-card">
      <div class="cg-user-avatar"><?= htmlspecialchars($initials) ?></div>
      <div class="cg-user-info">
        <div class="u-name"><?= htmlspecialchars($user['name']) ?></div>
        <div class="u-role"><?= htmlspecialchars($user['dept'] ?: $roleLabel) ?></div>
      </div>
      <a href="<?= BASE_URL ?>/logout.php" class="logout-btn" title="<?= t('nav_logout') ?>"><i class="bi bi-box-arrow-right"></i></a>
    </div>
  </div>
</aside>

<div class="cg-overlay" id="cg-overlay"></div>

<div class="cg-main">
  <div class="cg-topbar">
    <button class="hamburger" id="hamburger"><i class="bi bi-list"></i></button>
    <h1 class="page-title"><?= htmlspecialchars($page_title ?? '') ?></h1>
    <div class="topbar-right d-flex align-items-center gap-2">
      <div class="d-flex gap-1">
        <a href="?setlang=en" class="btn btn-xs <?= langIs('en') ? 'btn-primary' : 'btn-outline-secondary' ?>" style="font-size:.7rem;padding:2px 8px">EN</a>
        <a href="?setlang=bm" class="btn btn-xs <?= langIs('bm') ? 'btn-primary' : 'btn-outline-secondary' ?>" style="font-size:.7rem;padding:2px 8px">BM</a>
      </div>
      <span class="badge bg-light text-muted border"><?= $roleLabel ?></span>
    </div>
  </div>
  <div class="cg-content">
