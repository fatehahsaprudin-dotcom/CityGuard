-- =====================================================
-- migrate_v2.sql — Run this in phpMyAdmin > SQL tab
-- Adds: vendor_id on cases, categories, category_vendors,
--       vendor_submissions tables + vendor role
-- Safe to run even if some columns/tables already exist
-- =====================================================

USE cityguide;

-- 1. Add vendor role to users (safe to re-run)
ALTER TABLE users MODIFY COLUMN role
    ENUM('resident','officer','supervisor','admin','vendor')
    NOT NULL DEFAULT 'resident';

-- 2. Add vendor_id to cases (skip if already exists)
ALTER TABLE cases
    ADD COLUMN IF NOT EXISTS vendor_id INT DEFAULT NULL AFTER assigned_to;

-- 3. Add foreign key for vendor_id (ignore error if already exists)
SET @fk_exists = (
    SELECT COUNT(*) FROM information_schema.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = 'cityguide' AND TABLE_NAME = 'cases'
    AND CONSTRAINT_NAME = 'fk_cases_vendor'
);
SET @sql = IF(@fk_exists = 0,
    'ALTER TABLE cases ADD CONSTRAINT fk_cases_vendor FOREIGN KEY (vendor_id) REFERENCES users(id) ON DELETE SET NULL',
    'SELECT 1'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 4. Categories table
CREATE TABLE IF NOT EXISTS categories (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(80)  NOT NULL UNIQUE,
    dept       VARCHAR(100) DEFAULT NULL,
    is_active  TINYINT(1)   DEFAULT 1,
    created_at DATETIME     DEFAULT CURRENT_TIMESTAMP
);

-- 5. Category → Vendor auto-assignment (one vendor per category)
CREATE TABLE IF NOT EXISTS category_vendors (
    category_id INT NOT NULL PRIMARY KEY,
    vendor_id   INT NOT NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    FOREIGN KEY (vendor_id)   REFERENCES users(id) ON DELETE CASCADE
);

-- 6. Vendor work submissions (evidence + status)
CREATE TABLE IF NOT EXISTS vendor_submissions (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    case_id        INT NOT NULL,
    vendor_id      INT NOT NULL,
    status         ENUM('work_done','cannot_complete') NOT NULL,
    evidence_photo VARCHAR(255) DEFAULT NULL,
    notes          TEXT         DEFAULT NULL,
    submitted_at   DATETIME     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id)   REFERENCES cases(id) ON DELETE CASCADE,
    FOREIGN KEY (vendor_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 7. Seed categories (skips duplicates)
INSERT IGNORE INTO categories (name, dept) VALUES
('Pothole',      'JKR'),
('Fallen Tree',  'MPSA'),
('Streetlight',  'TNB'),
('Wild Animal',  'Jabatan Veterinar'),
('Drainage',     'MPSA'),
('Flood',        'Bomba'),
('Vandalism',    'Polis'),
('Garbage',      'MPSA'),
('Water',        'SYABAS'),
('Noise',        'MPSA'),
('Other',        'MPSA');
