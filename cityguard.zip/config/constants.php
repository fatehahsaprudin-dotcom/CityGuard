<?php
define('APP_NAME',    'CityGuard');
define('APP_VERSION', '2.0.0');
define('BASE_URL',    'http://localhost/cityguard');

define('ROLE_RESIDENT',   'resident');
define('ROLE_OFFICER',    'officer');
define('ROLE_SUPERVISOR', 'supervisor');
define('ROLE_ADMIN',      'admin');
define('ROLE_VENDOR',     'vendor');

define('STATUS_NEW',         'new');
define('STATUS_ASSIGNED',    'assigned');
define('STATUS_IN_PROGRESS', 'in_progress');
define('STATUS_RESOLVED',    'resolved');
define('STATUS_APPROVED',    'approved');
define('STATUS_REJECTED',    'rejected');

define('MAX_UPLOAD_SIZE',    5 * 1024 * 1024);
define('UPLOAD_REPORTS',     __DIR__ . '/../assets/uploads/reports/');
define('UPLOAD_EVIDENCE',    __DIR__ . '/../assets/uploads/evidence/');
define('UPLOAD_REPORTS_URL', BASE_URL . '/assets/uploads/reports/');
define('UPLOAD_EVIDENCE_URL',        BASE_URL . '/assets/uploads/evidence/');
define('UPLOAD_VENDOR_EVIDENCE',     __DIR__ . '/../assets/uploads/vendor_evidence/');
define('UPLOAD_VENDOR_EVIDENCE_URL', BASE_URL . '/assets/uploads/vendor_evidence/');

// Use define() for arrays that reference BASE_URL (runtime constant)
define('ROLE_DASHBOARD', [
    'resident'   => BASE_URL . '/resident/',
    'officer'    => BASE_URL . '/officer/',
    'supervisor' => BASE_URL . '/supervisor/',
    'admin'      => BASE_URL . '/admin/',
    'vendor'     => BASE_URL . '/vendor/',
]);

const DEPT_ROUTING = [
    'Pothole'      => 'JKR',
    'Fallen Tree'  => 'MPSA',
    'Streetlight'  => 'TNB',
    'Wild Animal'  => 'Jabatan Veterinar',
    'Drainage'     => 'MPSA',
    'Flood'        => 'Bomba',
    'Vandalism'    => 'Polis',
    'Garbage'      => 'MPSA',
    'Water'        => 'SYABAS',
    'Noise'        => 'MPSA',
    'Other'        => 'MPSA',
];

const CASE_CATEGORIES = [
    'Pothole', 'Fallen Tree', 'Streetlight', 'Wild Animal',
    'Drainage', 'Flood', 'Vandalism', 'Garbage', 'Water', 'Noise', 'Other',
];

const STATUS_CONFIG = [
    'new'         => ['label' => 'New',         'color' => 'secondary'],
    'assigned'    => ['label' => 'Assigned',    'color' => 'primary'],
    'in_progress' => ['label' => 'In Progress', 'color' => 'warning'],
    'resolved'    => ['label' => 'Resolved',    'color' => 'info'],
    'approved'    => ['label' => 'Approved',    'color' => 'success'],
    'rejected'    => ['label' => 'Rejected',    'color' => 'danger'],
];

const PRIORITY_CONFIG = [
    'high'   => ['label' => 'High',   'color' => 'danger'],
    'medium' => ['label' => 'Medium', 'color' => 'warning'],
    'low'    => ['label' => 'Low',    'color' => 'success'],
];

const ROLE_LABELS = [
    'resident'   => 'Resident',
    'officer'    => 'Field Officer',
    'supervisor' => 'Supervisor',
    'admin'      => 'Admin',
    'vendor'     => 'Vendor',
];
