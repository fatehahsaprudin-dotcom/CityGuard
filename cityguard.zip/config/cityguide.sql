-- =====================================================
-- cityguide.sql — Full schema for CityGuide system
-- 5 roles: resident, officer, supervisor, admin, vendor
-- Default password for all accounts: password123
-- =====================================================

CREATE DATABASE IF NOT EXISTS cityguide
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE cityguide;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS case_activity_log;
DROP TABLE IF EXISTS case_resolutions;
DROP TABLE IF EXISTS officer_checkins;
DROP TABLE IF EXISTS cases;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- -----------------------------------------------------
-- Table: users
-- -----------------------------------------------------
CREATE TABLE users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)  NOT NULL,
    email       VARCHAR(150)  NOT NULL UNIQUE,
    password    VARCHAR(255)  NOT NULL,
    role        ENUM('resident','officer','supervisor','admin','vendor') NOT NULL DEFAULT 'resident',
    phone       VARCHAR(20)   DEFAULT NULL,
    unit        VARCHAR(100)  DEFAULT NULL,
    dept        VARCHAR(100)  DEFAULT NULL,
    is_active   TINYINT(1)    DEFAULT 1,
    created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- -----------------------------------------------------
-- Table: cases
-- -----------------------------------------------------
CREATE TABLE cases (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    case_code       VARCHAR(20)   NOT NULL UNIQUE,
    title           VARCHAR(150)  NOT NULL,
    category        VARCHAR(80)   NOT NULL,
    description     TEXT          DEFAULT NULL,
    priority        ENUM('high','medium','low') DEFAULT 'medium',
    status          ENUM('new','assigned','in_progress','resolved','approved','rejected') DEFAULT 'new',
    latitude        DECIMAL(10,7) DEFAULT NULL,
    longitude       DECIMAL(10,7) DEFAULT NULL,
    address         VARCHAR(255)  DEFAULT NULL,
    report_photo    VARCHAR(255)  DEFAULT NULL,
    ai_report       TEXT          DEFAULT NULL,
    assigned_dept   VARCHAR(100)  DEFAULT NULL,
    assigned_to     INT           DEFAULT NULL,
    vendor_id       INT           DEFAULT NULL,
    reported_by     INT           DEFAULT NULL,
    reported_at     DATETIME      DEFAULT CURRENT_TIMESTAMP,
    assigned_at     DATETIME      DEFAULT NULL,
    created_at      DATETIME      DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (vendor_id)   REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (reported_by) REFERENCES users(id) ON DELETE SET NULL
);

-- -----------------------------------------------------
-- Table: officer_checkins
-- -----------------------------------------------------
CREATE TABLE officer_checkins (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    officer_id  INT           NOT NULL,
    case_id     INT           DEFAULT NULL,
    latitude    DECIMAL(10,7) NOT NULL,
    longitude   DECIMAL(10,7) NOT NULL,
    accuracy    FLOAT         DEFAULT NULL,
    checkin_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (officer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (case_id)    REFERENCES cases(id) ON DELETE SET NULL
);

-- -----------------------------------------------------
-- Table: case_resolutions
-- -----------------------------------------------------
CREATE TABLE case_resolutions (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    case_id         INT           NOT NULL UNIQUE,
    officer_id      INT           NOT NULL,
    evidence_photo  VARCHAR(255)  DEFAULT NULL,
    ai_completion   TEXT          DEFAULT NULL,
    officer_notes   TEXT          DEFAULT NULL,
    resolved_at     DATETIME      DEFAULT CURRENT_TIMESTAMP,
    approved_by     INT           DEFAULT NULL,
    approved_at     DATETIME      DEFAULT NULL,
    FOREIGN KEY (case_id)     REFERENCES cases(id)  ON DELETE CASCADE,
    FOREIGN KEY (officer_id)  REFERENCES users(id)  ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES users(id)  ON DELETE SET NULL
);

-- -----------------------------------------------------
-- Table: case_activity_log
-- -----------------------------------------------------
CREATE TABLE case_activity_log (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    case_id     INT           NOT NULL,
    user_id     INT           DEFAULT NULL,
    action      VARCHAR(150)  NOT NULL,
    old_value   VARCHAR(100)  DEFAULT NULL,
    new_value   VARCHAR(100)  DEFAULT NULL,
    created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- =====================================================
-- Seed Data (password: password123)
-- =====================================================
INSERT INTO users (name, email, password, role, unit, dept, phone) VALUES
('System Admin',         'admin@cityguard.my',        '$2y$10$HRO2KjGfz5xqepJdQAc3IOi1KUDhTWnu/RmW4RQQUGnk/4gCcYe2e', 'admin',      NULL,              'CityGuard HQ',      '03-55101234'),
('Hafizuddin Malik',     'supervisor@mpsa.gov.my',    '$2y$10$HRO2KjGfz5xqepJdQAc3IOi1KUDhTWnu/RmW4RQQUGnk/4gCcYe2e', 'supervisor', 'Operations Unit', 'MPSA',              '03-55102345'),
('Azri bin Hamdan',      'azri@mpsa.gov.my',          '$2y$10$HRO2KjGfz5xqepJdQAc3IOi1KUDhTWnu/RmW4RQQUGnk/4gCcYe2e', 'officer',    'Unit 4',          'MPSA',              '011-23456789'),
('Farah binti Kamal',    'farah@mpsa.gov.my',         '$2y$10$HRO2KjGfz5xqepJdQAc3IOi1KUDhTWnu/RmW4RQQUGnk/4gCcYe2e', 'officer',    'Unit 2',          'JKR',               '011-34567890'),
('Ali bin Abu',          'ali@gmail.com',             '$2y$10$HRO2KjGfz5xqepJdQAc3IOi1KUDhTWnu/RmW4RQQUGnk/4gCcYe2e', 'resident',   NULL,              NULL,                '012-3456789'),
('Siti binti Rahman',    'siti@gmail.com',            '$2y$10$HRO2KjGfz5xqepJdQAc3IOi1KUDhTWnu/RmW4RQQUGnk/4gCcYe2e', 'resident',   NULL,              NULL,                '013-4567890'),
('BuildRight Sdn Bhd',   'buildright@vendor.my',      '$2y$10$HRO2KjGfz5xqepJdQAc3IOi1KUDhTWnu/RmW4RQQUGnk/4gCcYe2e', 'vendor',     'Road & Drainage',  'BuildRight Sdn Bhd','03-77778888'),
('GreenTree Services',   'greentree@vendor.my',       '$2y$10$HRO2KjGfz5xqepJdQAc3IOi1KUDhTWnu/RmW4RQQUGnk/4gCcYe2e', 'vendor',     'Tree & Landscaping','GreenTree Sdn Bhd', '03-99990000');

INSERT INTO cases (case_code, title, category, description, priority, status, latitude, longitude, address, assigned_dept, assigned_to, vendor_id, reported_by, reported_at, assigned_at) VALUES
('CG-2024-001', 'Large pothole on main road',     'Pothole',     'Large pothole approx. 60cm diameter, 15cm deep. Dangerous to vehicles.',    'high',   'assigned',    3.0738, 101.5183, 'Jalan Besar Seksyen 7, Shah Alam',  'JKR',  3, 7, 5, NOW() - INTERVAL 32 MINUTE, NOW() - INTERVAL 30 MINUTE),
('CG-2024-002', 'Fallen tree blocking road',      'Fallen Tree', 'Large tree blocking half the road. Access partially closed.',               'high',   'in_progress', 3.0820, 101.5250, 'Persiaran Seksyen 14, Shah Alam',   'MPSA', 3, 8, 5, NOW() - INTERVAL 1 HOUR,   NOW() - INTERVAL 55 MINUTE),
('CG-2024-003', 'Streetlights not functioning',   'Streetlight', '3 lamp posts not working. Area dark at night.',                             'medium', 'assigned',    3.0650, 101.5100, 'Jalan Seksyen 2/3, Shah Alam',      'TNB',  4, NULL, 6, NOW() - INTERVAL 3 HOUR, NOW() - INTERVAL 2 HOUR),
('CG-2024-004', 'Wild animal near public park',   'Wild Animal', 'A crocodile spotted near the pond. Public area nearby.',                    'medium', 'assigned',    3.0780, 101.5310, 'Taman Seksyen 9, Shah Alam',        'Jabatan Veterinar', 4, NULL, 6, NOW() - INTERVAL 5 HOUR, NOW() - INTERVAL 4 HOUR),
('CG-2024-005', 'Clogged drainage causing flood', 'Drainage',    'Water pooling. Drain blocked with debris and sediment.',                    'low',    'new',         3.0700, 101.5200, 'Jalan Seksyen 11/2, Shah Alam',     'MPSA', NULL, NULL, 5, NOW() - INTERVAL 1 DAY, NULL);
