-- =====================================================
-- smart_communities.sql
-- Database schema for Smart Communities System
-- Dashboard 3: Field Officer App
-- =====================================================

CREATE DATABASE IF NOT EXISTS cityguide
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE cityguide;

-- =====================================================
-- Drop existing tables (reverse FK order)
-- =====================================================
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS case_activity_log;
DROP TABLE IF EXISTS case_resolutions;
DROP TABLE IF EXISTS officer_checkins;
DROP TABLE IF EXISTS cases;
DROP TABLE IF EXISTS officers;

SET FOREIGN_KEY_CHECKS = 1;

-- -----------------------------------------------------
-- Table: officers (Dashboard 3 users)
-- -----------------------------------------------------
CREATE TABLE officers (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)  NOT NULL,
    email       VARCHAR(150)  NOT NULL UNIQUE,
    password    VARCHAR(255)  NOT NULL,  -- bcrypt hash
    unit        VARCHAR(50)   NOT NULL,
    dept        VARCHAR(100)  NOT NULL,
    phone       VARCHAR(20)   DEFAULT NULL,
    is_active   TINYINT(1)    DEFAULT 1,
    created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- -----------------------------------------------------
-- Table: cases (reports from Dashboard 1)
-- -----------------------------------------------------
CREATE TABLE cases (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    case_code       VARCHAR(20)   NOT NULL UNIQUE,  -- e.g. KS-2024-001
    title           VARCHAR(150)  NOT NULL,
    category        VARCHAR(80)   NOT NULL,
    description     TEXT          DEFAULT NULL,
    priority        ENUM('high','medium','low') DEFAULT 'medium',
    status          ENUM('assigned','in_progress','resolved','rejected') DEFAULT 'assigned',
    latitude        DECIMAL(10,7) DEFAULT NULL,
    longitude       DECIMAL(10,7) DEFAULT NULL,
    address         VARCHAR(255)  DEFAULT NULL,
    report_photo    VARCHAR(255)  DEFAULT NULL,  -- photo from resident
    ai_report       TEXT          DEFAULT NULL,  -- AI generated report (Dashboard 1)
    assigned_dept   VARCHAR(100)  DEFAULT NULL,
    assigned_to     INT           DEFAULT NULL,  -- officer id
    reported_by     INT           DEFAULT NULL,  -- resident id (Dashboard 1)
    reported_at     DATETIME      DEFAULT CURRENT_TIMESTAMP,
    assigned_at     DATETIME      DEFAULT NULL,
    created_at      DATETIME      DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (assigned_to) REFERENCES officers(id) ON DELETE SET NULL
);

-- -----------------------------------------------------
-- Table: officer_checkins (GPS check-in log)
-- -----------------------------------------------------
CREATE TABLE officer_checkins (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    officer_id  INT           NOT NULL,
    case_id     INT           DEFAULT NULL,
    latitude    DECIMAL(10,7) NOT NULL,
    longitude   DECIMAL(10,7) NOT NULL,
    accuracy    FLOAT         DEFAULT NULL,  -- GPS accuracy in metres
    checkin_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (officer_id) REFERENCES officers(id) ON DELETE CASCADE,
    FOREIGN KEY (case_id)    REFERENCES cases(id)    ON DELETE SET NULL
);

-- -----------------------------------------------------
-- Table: case_resolutions (Dashboard 3 completion)
-- -----------------------------------------------------
CREATE TABLE case_resolutions (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    case_id         INT           NOT NULL UNIQUE,
    officer_id      INT           NOT NULL,
    evidence_photo  VARCHAR(255)  DEFAULT NULL,  -- uploaded proof photo
    ai_completion   TEXT          DEFAULT NULL,  -- AI-generated completion report
    officer_notes   TEXT          DEFAULT NULL,
    resolved_at     DATETIME      DEFAULT CURRENT_TIMESTAMP,
    approved_by     INT           DEFAULT NULL,  -- supervisor id (Dashboard 4)
    approved_at     DATETIME      DEFAULT NULL,
    FOREIGN KEY (case_id)    REFERENCES cases(id)    ON DELETE CASCADE,
    FOREIGN KEY (officer_id) REFERENCES officers(id) ON DELETE CASCADE
);

-- -----------------------------------------------------
-- Table: case_activity_log (audit trail)
-- -----------------------------------------------------
CREATE TABLE case_activity_log (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    case_id     INT           NOT NULL,
    officer_id  INT           DEFAULT NULL,
    action      VARCHAR(100)  NOT NULL,  -- e.g. "Status changed to in_progress"
    old_value   VARCHAR(100)  DEFAULT NULL,
    new_value   VARCHAR(100)  DEFAULT NULL,
    created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id)    REFERENCES cases(id)    ON DELETE CASCADE,
    FOREIGN KEY (officer_id) REFERENCES officers(id) ON DELETE SET NULL
);

-- =====================================================
-- Seed Data (for testing / demo)
-- =====================================================

-- Default password for all test accounts: password123
INSERT INTO officers (name, email, password, unit, dept) VALUES
('Azri bin Hamdan',   'azri@mpsa.gov.my',   '$2y$10$HRO2KjGfz5xqepJdQAc3IOi1KUDhTWnu/RmW4RQQUGnk/4gCcYe2e', 'Unit 4', 'MPSA'),
('Farah binti Kamal', 'farah@mpsa.gov.my',  '$2y$10$HRO2KjGfz5xqepJdQAc3IOi1KUDhTWnu/RmW4RQQUGnk/4gCcYe2e', 'Unit 2', 'JKR'),
('Hafiz bin Rosli',   'hafiz@polis.gov.my', '$2y$10$HRO2KjGfz5xqepJdQAc3IOi1KUDhTWnu/RmW4RQQUGnk/4gCcYe2e', 'Unit 1', 'Polis');

INSERT INTO cases (case_code, title, category, description, priority, status, latitude, longitude, address, assigned_dept, assigned_to, reported_at, assigned_at) VALUES
('KS-2024-001', 'Jalan berlubang', 'Pothole',      'Lubang besar diameter ±60cm, kedalaman 15cm. Berbahaya kepada kenderaan.', 'high',   'assigned',    3.0738, 101.5183, 'Jalan Besar Seksyen 7, Shah Alam',   'JKR',  1, NOW() - INTERVAL 32 MINUTE, NOW() - INTERVAL 30 MINUTE),
('KS-2024-002', 'Pokok tumbang',   'Fallen Tree',  'Pokok besar merentangi jalan. Laluan ditutup separuh.',                  'high',   'in_progress', 3.0820, 101.5250, 'Persiaran Seksyen 14, Shah Alam',    'MPSA', 1, NOW() - INTERVAL 1 HOUR,   NOW() - INTERVAL 55 MINUTE),
('KS-2024-003', 'Lampu jalan rosak','Streetlight', '3 tiang lampu tidak berfungsi. Kawasan gelap pada waktu malam.',         'medium', 'assigned',    3.0650, 101.5100, 'Jalan Seksyen 2/3, Shah Alam',       'TNB',  1, NOW() - INTERVAL 3 HOUR,   NOW() - INTERVAL 2 HOUR),
('KS-2024-004', 'Haiwan liar',     'Wild Animal',  'Dilaporkan seekor buaya dilihat di tepi kolam. Kawasan awam berdekatan.','medium', 'assigned',    3.0780, 101.5310, 'Taman Seksyen 9, Shah Alam',         'Jabatan Veterinar', 1, NOW() - INTERVAL 5 HOUR, NOW() - INTERVAL 4 HOUR),
('KS-2024-005', 'Longkang tersumbat','Drainage',   'Air bertakung. Longkang dipenuhi sampah dan sedimen.',                   'low',    'assigned',    3.0700, 101.5200, 'Jalan Seksyen 11/2, Shah Alam',      'MPSA', 1, NOW() - INTERVAL 1 DAY,   NOW() - INTERVAL 23 HOUR);
