<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('SESSION_TIMEOUT', 3600);

function isLoggedIn(): bool {
    if (!isset($_SESSION['user_id'])) return false;
    if (time() - ($_SESSION['last_activity'] ?? 0) > SESSION_TIMEOUT) {
        logoutUser();
        return false;
    }
    $_SESSION['last_activity'] = time();
    return true;
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function requireRole(string $role): void {
    requireLogin();
    if (($_SESSION['user_role'] ?? '') !== $role) {
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}

function requireAnyRole(array $roles): void {
    requireLogin();
    if (!in_array($_SESSION['user_role'] ?? '', $roles, true)) {
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}

function isRole(string $role): bool {
    return ($_SESSION['user_role'] ?? '') === $role;
}

function getCurrentUser(): array {
    return [
        'id'    => $_SESSION['user_id']    ?? null,
        'name'  => $_SESSION['user_name']  ?? '',
        'email' => $_SESSION['user_email'] ?? '',
        'role'  => $_SESSION['user_role']  ?? '',
        'unit'  => $_SESSION['user_unit']  ?? '',
        'dept'  => $_SESSION['user_dept']  ?? '',
        'phone' => $_SESSION['user_phone'] ?? '',
    ];
}

function loginUser(array $user): void {
    session_regenerate_id(true);
    $_SESSION['user_id']       = $user['id'];
    $_SESSION['user_name']     = $user['name'];
    $_SESSION['user_email']    = $user['email'];
    $_SESSION['user_role']     = $user['role'];
    $_SESSION['user_unit']     = $user['unit'] ?? '';
    $_SESSION['user_dept']     = $user['dept'] ?? '';
    $_SESSION['user_phone']    = $user['phone'] ?? '';
    $_SESSION['last_activity'] = time();
}

function logoutUser(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function getDashboardUrl(): string {
    $role = $_SESSION['user_role'] ?? '';
    $map  = ROLE_DASHBOARD;
    return $map[$role] ?? BASE_URL . '/login.php';
}

// ── Language ──────────────────────────────────────────────────────────────────
if (isset($_GET['setlang']) && in_array($_GET['setlang'], ['en', 'bm'])) {
    $_SESSION['lang'] = $_GET['setlang'];
    $redirect = strtok($_SERVER['REQUEST_URI'], '?');
    $params   = $_GET; unset($params['setlang']);
    header('Location: ' . $redirect . ($params ? '?' . http_build_query($params) : ''));
    exit;
}
$GLOBALS['_lang'] = $_SESSION['lang'] ?? 'en';
$GLOBALS['_LANG'] = require __DIR__ . '/../lang/' . $GLOBALS['_lang'] . '.php';

function t(string $key): string {
    return $GLOBALS['_LANG'][$key] ?? $key;
}
function langIs(string $l): bool {
    return ($GLOBALS['_lang'] ?? 'en') === $l;
}
