<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('supervisor');

$user   = getCurrentUser();
$db     = Database::getInstance()->getConnection();
$filter = $_GET['status'] ?? '';
$sql    = "SELECT c.*, o.name AS officer_name, v.name AS vendor_name, r.name AS reporter_name FROM cases c LEFT JOIN users o ON o.id=c.assigned_to LEFT JOIN users v ON v.id=c.vendor_id LEFT JOIN users r ON r.id=c.reported_by";
$params = [];
if ($filter && array_key_exists($filter, STATUS_CONFIG)) { $sql .= " WHERE c.status=?"; $params[] = $filter; }
$sql .= " ORDER BY FIELD(c.priority,'high','medium','low'), c.reported_at DESC";
$stmt = $db->prepare($sql); $stmt->execute($params); $cases = $stmt->fetchAll();

$officers = $db->query("SELECT id, name, dept FROM users WHERE role='officer' AND is_active=1 ORDER BY name")->fetchAll();
$vendors  = $db->query("SELECT id, name, unit AS specialization FROM users WHERE role='vendor' AND is_active=1 ORDER BY name")->fetchAll();

$cnt = [];
foreach (['new','assigned','in_progress','resolved'] as $s) {
    $q = $db->prepare("SELECT COUNT(*) FROM cases WHERE status=?"); $q->execute([$s]); $cnt[$s] = (int)$q->fetchColumn();
}

$page_title = t('nav_all_cases'); $active_nav = 'cases'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon red"><i class="bi bi-inbox"></i></div><div><p class="stat-label"><?= t('sv_new') ?></p><p class="stat-value"><?= $cnt['new'] ?></p></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon yellow"><i class="bi bi-person-check"></i></div><div><p class="stat-label"><?= t('sv_assigned') ?></p><p class="stat-value"><?= $cnt['assigned'] ?></p></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon blue"><i class="bi bi-tools"></i></div><div><p class="stat-label"><?= t('sv_in_progress') ?></p><p class="stat-value"><?= $cnt['in_progress'] ?></p></div></div></div>
  <div class="col-6 col-md-3"><div class="stat-card"><div class="stat-icon green"><i class="bi bi-check-circle"></i></div><div><p class="stat-label"><?= t('sv_resolved') ?></p><p class="stat-value"><?= $cnt['resolved'] ?></p></div></div></div>
</div>

<div class="d-flex gap-2 mb-3 flex-wrap">
  <a href="?status=" class="btn btn-sm <?= $filter === '' ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('lbl_all') ?></a>
  <a href="?status=new" class="btn btn-sm <?= $filter === 'new' ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('sv_new') ?></a>
  <a href="?status=assigned" class="btn btn-sm <?= $filter === 'assigned' ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('sv_assigned') ?></a>
  <a href="?status=in_progress" class="btn btn-sm <?= $filter === 'in_progress' ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('sv_in_progress') ?></a>
  <a href="?status=resolved" class="btn btn-sm <?= $filter === 'resolved' ? 'btn-primary' : 'btn-outline-secondary' ?>"><?= t('sv_resolved') ?></a>
</div>

<div class="cg-card">
  <div class="cg-card-header"><i class="bi bi-kanban me-2 text-primary"></i><?= t('off_case_list') ?></div>
  <?php if (empty($cases)): ?>
    <div class="cg-card-body text-center py-5 text-muted"><i class="bi bi-inbox fs-1 d-block mb-2"></i><?= t('off_no_cases') ?></div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="cg-table">
      <thead><tr><th><?= t('th_code') ?></th><th><?= t('th_title') ?></th><th><?= t('th_category') ?></th><th><?= t('th_priority') ?></th><th><?= t('th_status') ?></th><th><?= t('th_officer') ?></th><th><?= t('th_vendor') ?></th><th class="hide-mobile"><?= t('th_photo') ?></th><th class="hide-mobile"><?= t('th_date') ?></th><th style="white-space:nowrap"><?= t('th_actions') ?></th></tr></thead>
      <tbody>
      <?php foreach ($cases as $c):
        $sc = STATUS_CONFIG[$c['status']] ?? ['label'=>$c['status']];
        $pc = PRIORITY_CONFIG[$c['priority']] ?? ['label'=>$c['priority']];
      ?>
        <tr>
          <td><code class="small"><?= htmlspecialchars($c['case_code']) ?></code></td>
          <td class="fw-semibold" style="max-width:160px"><?= htmlspecialchars($c['title']) ?></td>
          <td class="text-muted small"><?= htmlspecialchars($c['category']) ?></td>
          <td><span class="badge badge-priority-<?= $c['priority'] ?>"><?= t('pri_' . $c['priority']) ?></span></td>
          <td><span class="badge badge-status-<?= $c['status'] ?>"><?= t('status_' . $c['status']) ?></span></td>
          <td class="small"><?= $c['officer_name'] ? htmlspecialchars($c['officer_name']) : '<span class="text-muted">—</span>' ?></td>
          <td class="small text-success"><?= $c['vendor_name'] ? htmlspecialchars($c['vendor_name']) : '<span class="text-muted">—</span>' ?></td>
          <td class="hide-mobile">
            <?php if (!empty($c['report_photo'])): ?>
              <img src="<?= UPLOAD_REPORTS_URL . htmlspecialchars($c['report_photo']) ?>"
                   style="width:40px;height:40px;object-fit:cover;border-radius:6px;cursor:pointer"
                   onclick="openPhoto('<?= UPLOAD_REPORTS_URL . htmlspecialchars($c['report_photo']) ?>')" title="View photo">
            <?php else: ?><span class="text-muted">—</span><?php endif; ?>
          </td>
          <td class="hide-mobile text-muted small"><?= date('d M Y', strtotime($c['reported_at'])) ?></td>
          <td>
            <div class="d-flex gap-1 align-items-center">
              <button class="btn btn-sm btn-outline-secondary btn-icon"
                      onclick="openDetail(<?= htmlspecialchars(json_encode([
                        'code'        => $c['case_code'],
                        'title'       => $c['title'],
                        'status'      => $c['status'],
                        'priority'    => $c['priority'],
                        'category'    => $c['category'],
                        'address'     => $c['address'] ?? '',
                        'description' => $c['description'] ?? '',
                        'photo'       => !empty($c['report_photo']) ? UPLOAD_REPORTS_URL . $c['report_photo'] : '',
                        'reporter'    => $c['reporter_name'] ?? '',
                        'officer'     => $c['officer_name'] ?? '',
                        'vendor'      => $c['vendor_name'] ?? '',
                        'date'        => date('d M Y, H:i', strtotime($c['reported_at'])),
                      ]), ENT_QUOTES) ?>)"
                      title="<?= t('btn_view') ?>"><i class="bi bi-eye"></i></button>
              <button class="btn btn-sm btn-primary btn-icon"
                      onclick="openAssign(<?= $c['id'] ?>,'<?= htmlspecialchars(addslashes($c['case_code'])) ?>','<?= htmlspecialchars(addslashes($c['title'])) ?>',<?= $c['assigned_to']?:0 ?>,<?= $c['vendor_id']?:0 ?>)"
                      title="<?= t('sv_assign_title') ?>"><i class="bi bi-person-plus"></i></button>
              <?php if ($c['status'] === 'new'): ?>
                <button class="btn btn-sm btn-outline-danger btn-icon" onclick="rejectCase(<?= $c['id'] ?>)" title="<?= t('btn_reject') ?>"><i class="bi bi-x-circle"></i></button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<div class="modal fade" id="assignModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content border-0" style="border-radius:16px">
      <div class="modal-header border-0">
        <h6 class="modal-title fw-semibold"><i class="bi bi-person-plus me-2"></i><?= t('sv_assign_title') ?></h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body pt-0">
        <div class="alert alert-light border small py-2 mb-3" id="modal-case-info"></div>

        <div class="mb-3">
          <label class="form-label fw-semibold"><i class="bi bi-person-badge me-1 text-primary"></i><?= t('lbl_officer') ?></label>
          <select id="officer-select" class="form-select">
            <option value=""><?= t('sv_no_officer') ?></option>
            <?php foreach ($officers as $o): ?>
              <option value="<?= $o['id'] ?>"><?= htmlspecialchars($o['name']) ?> — <?= htmlspecialchars($o['dept']) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="form-text"><?= t('sv_officer_hint') ?></div>
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold"><i class="bi bi-building me-1 text-success"></i><?= t('lbl_vendor') ?></label>
          <select id="vendor-select" class="form-select">
            <option value=""><?= t('sv_no_vendor') ?></option>
            <?php foreach ($vendors as $v): ?>
              <option value="<?= $v['id'] ?>"><?= htmlspecialchars($v['name']) ?><?= $v['specialization'] ? ' — ' . htmlspecialchars($v['specialization']) : '' ?></option>
            <?php endforeach; ?>
          </select>
          <div class="form-text"><?= t('sv_vendor_hint') ?></div>
        </div>

        <div id="assign-result"></div>
      </div>
      <div class="modal-footer border-0 pt-0">
        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal"><?= t('btn_cancel') ?></button>
        <button type="button" class="btn btn-primary btn-sm" onclick="submitAssign()"><i class="bi bi-check2 me-1"></i><?= t('sv_save_assign') ?></button>
      </div>
    </div>
  </div>
</div>

<?php
$t_select_one = t('sv_select_one');
$extra_js = <<<JS
<script>
let currentCaseId = null;
function openAssign(id, code, title, currentOfficer, currentVendor) {
  currentCaseId = id;
  document.getElementById('modal-case-info').textContent = '[' + code + '] ' + title;
  document.getElementById('officer-select').value = currentOfficer || '';
  document.getElementById('vendor-select').value  = currentVendor  || '';
  document.getElementById('assign-result').innerHTML = '';
  new bootstrap.Modal(document.getElementById('assignModal')).show();
}
async function submitAssign() {
  const officerId = document.getElementById('officer-select').value;
  const vendorId  = document.getElementById('vendor-select').value;
  if (!officerId && !vendorId) { alert('{$t_select_one}'); return; }
  const res = await fetch(BASE_URL + '/api/case_assign.php', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ case_id: currentCaseId, officer_id: officerId || null, vendor_id: vendorId || null })
  });
  const data = await res.json();
  if (data.success) { bootstrap.Modal.getInstance(document.getElementById('assignModal')).hide(); location.reload(); }
  else document.getElementById('assign-result').innerHTML = '<div class="alert alert-danger small py-2">' + (data.error||'Error.') + '</div>';
}
async function rejectCase(id) {
  if (!confirm('Reject this case?')) return;
  const res = await fetch(BASE_URL + '/api/case_assign.php', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({case_id:id,action:'reject'}) });
  const data = await res.json();
  if (data.success) location.reload(); else alert(data.error||'Error.');
}
</script>
JS;
include __DIR__ . '/../includes/footer.php';
