<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('supervisor');

$db = Database::getInstance()->getConnection();
$stmt = $db->query("
    SELECT u.*,
           COUNT(c.id) AS total_cases,
           SUM(c.status IN ('resolved','approved')) AS resolved_cases,
           SUM(c.status IN ('assigned','in_progress')) AS active_cases
    FROM users u
    LEFT JOIN cases c ON c.vendor_id = u.id
    WHERE u.role = 'vendor'
    GROUP BY u.id
    ORDER BY u.name
");
$vendors = $stmt->fetchAll();

$page_title = 'Vendors'; $active_nav = 'vendors'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="cg-card">
  <div class="cg-card-header"><i class="bi bi-building me-2 text-primary"></i>Registered Vendors (<?= count($vendors) ?>)</div>
  <?php if (empty($vendors)): ?>
    <div class="cg-card-body text-center py-5 text-muted"><i class="bi bi-building-x fs-1 d-block mb-2"></i>No vendors registered.</div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="cg-table">
      <thead><tr><th>Company</th><th>Specialization</th><th>Contact</th><th>Active Jobs</th><th>Completed</th><th>Total</th><th>Completion Rate</th></tr></thead>
      <tbody>
      <?php foreach ($vendors as $v):
        $pct = $v['total_cases'] > 0 ? round($v['resolved_cases'] / $v['total_cases'] * 100) : 0;
      ?>
        <tr>
          <td>
            <div class="d-flex align-items-center gap-2">
              <div class="stat-icon green" style="width:32px;height:32px;border-radius:8px;font-size:.8rem"><i class="bi bi-building"></i></div>
              <div>
                <div class="fw-semibold small"><?= htmlspecialchars($v['name']) ?></div>
                <div class="text-muted" style="font-size:.72rem"><?= htmlspecialchars($v['email']) ?></div>
              </div>
            </div>
          </td>
          <td class="small text-muted"><?= htmlspecialchars($v['unit'] ?? '—') ?></td>
          <td class="small text-muted"><?= htmlspecialchars($v['phone'] ?? '—') ?></td>
          <td><span class="fw-semibold text-warning"><?= (int)$v['active_cases'] ?></span></td>
          <td><span class="fw-semibold text-success"><?= (int)$v['resolved_cases'] ?></span></td>
          <td class="text-muted small"><?= (int)$v['total_cases'] ?></td>
          <td>
            <div style="min-width:80px">
              <div style="font-size:.7rem;margin-bottom:2px"><?= $pct ?>%</div>
              <div class="progress" style="height:5px;border-radius:99px">
                <div class="progress-bar bg-success" style="width:<?= $pct ?>%"></div>
              </div>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php $layout = 'dash'; include __DIR__ . '/../includes/footer.php'; ?>
