<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('supervisor');

$db = Database::getInstance()->getConnection();
$stmt = $db->query("
    SELECT u.*,
           COUNT(c.id) AS total_cases,
           SUM(c.status IN ('resolved','approved')) AS resolved_cases,
           SUM(c.status IN ('assigned','in_progress')) AS active_cases
    FROM users u
    LEFT JOIN cases c ON c.assigned_to = u.id
    WHERE u.role = 'officer'
    GROUP BY u.id
    ORDER BY u.name
");
$officers = $stmt->fetchAll();

$page_title = t('sv_officers_title'); $active_nav = 'officers'; $layout = 'dash';
include __DIR__ . '/../includes/header_dash.php';
?>

<div class="cg-card">
  <div class="cg-card-header"><i class="bi bi-person-badge me-2 text-primary"></i><?= t('sv_officers_title') ?> (<?= count($officers) ?>)</div>
  <?php if (empty($officers)): ?>
    <div class="cg-card-body text-center py-5 text-muted"><i class="bi bi-person-x fs-1 d-block mb-2"></i><?= t('sv_no_officers') ?></div>
  <?php else: ?>
  <div class="table-responsive">
    <table class="cg-table">
      <thead><tr><th><?= t('th_name') ?></th><th><?= t('th_dept') ?></th><th><?= t('lbl_unit') ?></th><th><?= t('lbl_active') ?></th><th><?= t('off_resolved') ?></th><th><?= t('lbl_total') ?></th><th><?= t('lbl_rate') ?></th></tr></thead>
      <tbody>
      <?php foreach ($officers as $o):
        $pct = $o['total_cases'] > 0 ? round($o['resolved_cases'] / $o['total_cases'] * 100) : 0;
      ?>
        <tr>
          <td>
            <div class="d-flex align-items-center gap-2">
              <div class="cg-user-avatar" style="width:32px;height:32px;font-size:.75rem">
                <?= strtoupper(substr($o['name'],0,1)) ?>
              </div>
              <div>
                <div class="fw-semibold small"><?= htmlspecialchars($o['name']) ?></div>
                <div class="text-muted" style="font-size:.72rem"><?= htmlspecialchars($o['email']) ?></div>
              </div>
            </div>
          </td>
          <td class="small"><?= htmlspecialchars($o['dept'] ?? '—') ?></td>
          <td class="small text-muted"><?= htmlspecialchars($o['unit'] ?? '—') ?></td>
          <td><span class="fw-semibold text-warning"><?= (int)$o['active_cases'] ?></span></td>
          <td><span class="fw-semibold text-success"><?= (int)$o['resolved_cases'] ?></span></td>
          <td class="text-muted small"><?= (int)$o['total_cases'] ?></td>
          <td>
            <div style="min-width:80px">
              <div style="font-size:.7rem;margin-bottom:2px"><?= $pct ?>%</div>
              <div class="progress" style="height:5px;border-radius:99px">
                <div class="progress-bar bg-success" style="width:<?= $pct ?>%"></div>
              </div>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php $layout = 'dash'; include __DIR__ . '/../includes/footer.php'; ?>
