﻿# CityGuard â€” Installation Guide

---

## Requirements

- Windows 10 / 11
- XAMPP (Apache + MySQL)
- Browser (Chrome / Firefox / Edge)

---

## Step 1 â€” Download & Install XAMPP

1. Go to **https://www.apachefriends.org**
2. Click **Download XAMPP for Windows**
3. Run the installer (e.g. `xampp-windows-x64-8.x.x-installer.exe`)
4. During installation:
   - Leave default install path: `C:\xampp`
   - Components to check: **Apache**, **MySQL**, **phpMyAdmin**
5. Click **Next** until installation completes
6. Click **Finish** â€” XAMPP Control Panel will open

---

## Step 2 â€” Start XAMPP Services

1. Open **XAMPP Control Panel** (search Start Menu if not open)
2. Click **Start** next to **Apache**
3. Click **Start** next to **MySQL**
4. Both should turn **green**

> If port conflict error appears on Apache:
> Click Config â†’ httpd.conf â†’ change `Listen 80` to `Listen 8080`
> Then access the system at `http://localhost:8080/CityGuard`

---

## Step 3 â€” Extract CityGuard Files

1. Locate the file **CityGuard.zip**
2. Right-click â†’ **Extract All**
3. Extract to: `C:\xampp\htdocs\`
4. After extracting you should have the folder: `C:\xampp\htdocs\CityGuard\`

Verify the folder structure looks like this:
```
C:\xampp\htdocs\CityGuard\
â”œâ”€â”€ index.php
â”œâ”€â”€ login.php
â”œâ”€â”€ config/
â”œâ”€â”€ resident/
â”œâ”€â”€ officer/
â”œâ”€â”€ supervisor/
â”œâ”€â”€ admin/
â”œâ”€â”€ vendor/
â”œâ”€â”€ api/
â””â”€â”€ assets/
```

---

## Step 4 â€” Create the Database

1. Open browser â†’ go to **http://localhost/phpmyadmin**
2. Click **New** (left sidebar)
3. In the **Database name** field, type: `CityGuard`
4. Set collation to: `utf8mb4_unicode_ci`
5. Click **Create**

---

## Step 5 â€” Import Main SQL (Schema + Seed Data)

1. In phpMyAdmin, click the **CityGuard** database (left sidebar)
2. Click the **Import** tab (top menu)
3. Click **Choose File**
4. Navigate to: `C:\xampp\htdocs\CityGuard\config\`
5. Select: **CityGuard.sql**
6. Scroll down â†’ click **Import**
7. Wait for success message: *"Import has been successfully finished"*

This creates all tables and inserts demo accounts.

---

## Step 6 â€” Run Migration (New Tables)

> This step adds the `categories`, `category_vendors`, and `vendor_submissions` tables.

1. Still in phpMyAdmin â†’ click **CityGuard** database
2. Click the **SQL** tab
3. Click **Choose File** or copy-paste the contents of:
   `C:\xampp\htdocs\CityGuard\config\migrate_v2.sql`

   **To copy-paste:**
   - Open the file in Notepad
   - Select All (Ctrl+A) â†’ Copy (Ctrl+C)
   - Paste into the SQL text box in phpMyAdmin
4. Click **Go**
5. Wait for success message

---

## Step 7 â€” Verify Configuration

Open this file in Notepad:
```
C:\xampp\htdocs\CityGuard\config\constants.php
```

Check line 4:
```php
define('BASE_URL', 'http://localhost/CityGuard');
```

> If your XAMPP uses a different port (e.g. 8080), change to:
> `'http://localhost:8080/CityGuard'`

---

## Step 8 â€” Open the System

Open browser â†’ go to:
```
http://localhost/CityGuard
```

You should see the **CityGuard login page**.

---

## Default Login Accounts

| Role | Email | Password |
|---|---|---|
| Admin | admin@CityGuard.my | password123 |
| Supervisor | supervisor@CityGuard.my | password123 |
| Officer | azri@CityGuard.my | password123 |
| Officer | farah@CityGuard.my | password123 |
| Resident | ali@CityGuard.my | password123 |
| Resident | siti@CityGuard.my | password123 |
| Vendor | buildright@CityGuard.my | password123 |
| Vendor | greentree@CityGuard.my | password123 |

> **Important:** Change all passwords after first login in a real deployment.

---

## Optional â€” AI Report Feature (Gemini API)

The resident report form has an **Auto Generate Report** feature powered by Google Gemini AI.

To enable it:

1. Go to **https://aistudio.google.com**
2. Sign in with a Google account
3. Click **Get API Key** â†’ **Create API key**
4. Copy the key

5. Open this file:
   ```
   C:\xampp\htdocs\CityGuard\api\ai_analyze.php
   ```
6. Find line 14:
   ```php
   $apiKey = 'YOUR_GEMINI_API_KEY_HERE';
   ```
7. Replace `YOUR_GEMINI_API_KEY_HERE` with your key
8. Save the file

> The system works normally without the API key â€” AI button will show an error but all other features remain functional.

---

## Troubleshooting

| Problem | Solution |
|---|---|
| Blank page / 500 error | Check `C:\xampp\php\php.ini` â€” enable `display_errors = On` |
| Database connection error | Ensure MySQL is running in XAMPP Control Panel |
| "Table not found" error | Re-import both SQL files (Steps 5 & 6) |
| Port 80 conflict | Change Apache port to 8080 (see Step 2 note) |
| Photos not uploading | Right-click `assets/uploads/` folder â†’ Properties â†’ uncheck Read-only |
| Login redirects back | Clear browser cookies or try incognito mode |

---

## File Structure Reference

| Folder | Description |
|---|---|
| `config/` | Database, constants, session config |
| `resident/` | Dashboard for public residents |
| `officer/` | Dashboard for field officers |
| `supervisor/` | Dashboard for supervisors |
| `admin/` | Dashboard for admin |
| `vendor/` | Dashboard for vendors/contractors |
| `api/` | All backend API endpoints |
| `assets/css/` | Stylesheet |
| `assets/uploads/` | Uploaded photos (reports, evidence) |

---

*CityGuard v2.0 â€” Smart Communities Management System*
