<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('resident');

$user  = getCurrentUser();
$db    = Database::getInstance()->getConnection();
$q     = $db->prepare("SELECT COUNT(*) FROM cases WHERE reported_by = ?"); $q->execute([$user['id']]); $total = (int)$q->fetchColumn();
$q2    = $db->prepare("SELECT COUNT(*) FROM cases WHERE reported_by = ? AND status IN ('approved','resolved')"); $q2->execute([$user['id']]); $resolved = (int)$q2->fetchColumn();

$categories_list = [];
try {
    $catStmt = $db->query("SELECT name, COALESCE(name_bm, name) AS name_bm FROM categories WHERE is_active=1 ORDER BY name");
    $categories_list = $catStmt->fetchAll();
} catch (PDOException $e) {}
if (empty($categories_list)) {
    foreach (CASE_CATEGORIES as $c) $categories_list[] = ['name' => $c, 'name_bm' => $c];
}

$page_title = t('nav_home'); $layout = 'public';
include __DIR__ . '/../includes/header_public.php';
?>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">

<div class="mb-3">
  <h4 class="fw-bold mb-1">Welcome, <?= htmlspecialchars(explode(' ', $user['name'])[0]) ?>!</h4>
  <p class="text-muted small mb-0"><?= t('res_subtitle') ?></p>
</div>

<div class="row g-3 mb-4">
  <div class="col-6">
    <div class="stat-card"><div class="stat-icon blue"><i class="bi bi-clipboard2"></i></div>
      <div><p class="stat-label"><?= t('res_total') ?></p><p class="stat-value"><?= $total ?></p></div></div>
  </div>
  <div class="col-6">
    <div class="stat-card"><div class="stat-icon green"><i class="bi bi-check-circle"></i></div>
      <div><p class="stat-label"><?= t('res_resolved') ?></p><p class="stat-value"><?= $resolved ?></p></div></div>
  </div>
</div>

<div id="alert-area"></div>

<form id="report-form" enctype="multipart/form-data">

  <!-- ── SECTION 1: Location ──────────────────────────────────── -->
  <div id="location-section" class="cg-card mb-3">
    <div class="cg-card-header"><i class="bi bi-geo-alt text-primary me-2"></i><?= t('res_loc_sec') ?> <span class="text-danger">*</span></div>
    <div class="cg-card-body">
      <div class="input-group mb-2">
        <input type="text" name="address" id="address-input" class="form-control"
               placeholder="<?= t('res_loc_ph') ?>" required>
        <button type="button" class="btn btn-outline-primary" onclick="detectGPS()" id="gps-btn" title="<?= t('btn_detect_gps') ?>">
          <i class="bi bi-geo-alt-fill"></i>
        </button>
      </div>
      <p id="gps-status" class="text-muted small mb-2"></p>
      <div id="map" style="height:220px;border-radius:10px;background:#e9ecef;display:none"></div>
      <input type="hidden" name="latitude"  id="lat-input">
      <input type="hidden" name="longitude" id="lon-input">
    </div>
  </div>

  <!-- ── SECTION 2: Photo ─────────────────────────────────────── -->
  <div class="cg-card mb-3">
    <div class="cg-card-header"><i class="bi bi-camera text-primary me-2"></i><?= t('res_photo_sec') ?> <span class="text-muted fw-normal small">(<?= t('lbl_optional') ?>)</span></div>
    <div class="cg-card-body">
      <div class="upload-zone" id="drop-zone" onclick="document.getElementById('photo-input').click()">
        <img id="preview-img" src="" style="display:none;max-height:220px;border-radius:8px" class="mb-1">
        <div id="upload-placeholder">
          <i class="bi bi-camera text-muted" style="font-size:2.5rem"></i>
          <p class="text-muted small mt-2 mb-0"><?= t('res_photo_hint') ?></p>
        </div>
      </div>
      <input type="file" id="photo-input" name="photo" accept="image/*" capture="environment"
             style="display:none" onchange="onPhotoSelected(this)">
    </div>
  </div>

  <!-- ── SECTION 3: Category + Keywords + AI ──────────────────── -->
  <div class="cg-card mb-3">
    <div class="cg-card-header"><i class="bi bi-stars text-primary me-2"></i><?= t('res_ai_sec') ?></div>
    <div class="cg-card-body">

      <div class="mb-3">
        <label class="form-label fw-semibold"><?= t('res_cat_label') ?> <span class="text-danger">*</span></label>
        <select name="category" id="field-category" class="form-select" required>
          <option value=""><?= t('res_cat_select') ?></option>
          <?php foreach ($categories_list as $cat): ?>
            <option value="<?= htmlspecialchars($cat['name']) ?>"><?= htmlspecialchars(langIs('bm') ? $cat['name_bm'] : $cat['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold"><?= t('res_kw_label') ?> <span class="text-danger">*</span></label>
        <input type="text" id="field-keywords" class="form-control"
               placeholder="e.g. deep pothole, dangerous, main road, vehicles affected"
               maxlength="200">
        <div class="form-text"><?= t('res_kw_hint') ?></div>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold"><?= t('res_lang_label') ?></label>
        <div class="d-flex gap-2">
          <input type="radio" class="btn-check" name="lang" id="lang-en" value="English" checked>
          <label class="btn btn-outline-secondary btn-sm flex-fill" for="lang-en">🇬🇧 English</label>
          <input type="radio" class="btn-check" name="lang" id="lang-bm" value="Bahasa Malaysia">
          <label class="btn btn-outline-secondary btn-sm flex-fill" for="lang-bm">🇲🇾 Bahasa Malaysia</label>
        </div>
      </div>

      <button type="button" id="ai-btn" class="btn btn-primary w-100" onclick="generateReport()" style="height:44px">
        <i class="bi bi-stars me-2"></i><?= t('res_ai_btn') ?>
      </button>
      <div id="ai-status" class="text-center small mt-2"></div>
    </div>
  </div>

  <!-- ── SECTION 4: Report Details ── -->
  <div id="report-section" class="cg-card mb-3">
    <div class="cg-card-header">
      <i class="bi bi-file-text text-primary me-2"></i><?= t('res_report_sec') ?>
      <span class="badge bg-primary ms-1" id="ai-badge" style="font-size:.7rem;display:none">AI</span>
    </div>
    <div class="cg-card-body">

      <div class="alert alert-primary py-2 small mb-3" id="ai-hint" style="display:none">
        <i class="bi bi-info-circle me-1"></i><?= t('res_ai_hint') ?>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold"><?= t('res_title_lbl') ?> <span class="text-danger">*</span></label>
        <input type="text" name="title" id="field-title" class="form-control" maxlength="150" required>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold"><?= t('res_pri_lbl') ?></label>
        <select name="priority" id="field-priority" class="form-select">
          <option value="medium"><?= t('pri_medium') ?></option>
          <option value="high"><?= t('pri_high') ?></option>
          <option value="low"><?= t('pri_low') ?></option>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold"><?= t('res_desc_lbl') ?> <span class="text-danger">*</span></label>
        <textarea name="description" id="field-description" class="form-control" rows="8"></textarea>
      </div>
    </div>
  </div>

  <!-- ── SUBMIT ────────────────────────────────────────────────── -->
  <button type="submit" id="submit-btn" class="btn btn-success w-100 mb-4" style="height:50px;font-size:1rem">
    <i class="bi bi-send me-2"></i><?= t('res_submit_btn') ?>
  </button>

</form>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<?php
$t_detecting   = t('res_gps_detecting');
$t_detected    = t('res_gps_detected');
$t_gps_failed  = t('res_gps_failed');
$t_generating  = t('btn_generating');
$t_regen       = t('res_regen_btn');
$t_ai_btn      = t('res_ai_btn');
$t_submitting  = t('btn_submitting');
$t_submit_btn  = t('res_submit_btn');
$t_conn_error  = t('msg_conn_error');
$extra_js = <<<JS
<script>
let map = null, marker = null, photoBase64 = null;

function onPhotoSelected(input) {
  if (!input.files[0]) return;
  const reader = new FileReader();
  reader.onload = e => {
    photoBase64 = e.target.result;
    document.getElementById('preview-img').src = photoBase64;
    document.getElementById('preview-img').style.display = '';
    document.getElementById('upload-placeholder').style.display = 'none';
  };
  reader.readAsDataURL(input.files[0]);
}

async function generateReport() {
  const category = document.getElementById('field-category').value;
  const keywords = document.getElementById('field-keywords').value.trim();

  if (!category) { showStatus('danger', 'Please select a category first.'); return; }
  if (!keywords)  { showStatus('danger', 'Please enter some keywords first.'); return; }

  const btn = document.getElementById('ai-btn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>{$t_generating}';
  showStatus('', '');

  try {
    const address  = document.getElementById('address-input').value.trim();
    const language = document.querySelector('input[name="lang"]:checked')?.value || 'English';
    const payload  = { category, keywords, address, language };
    if (photoBase64) payload.photo_base64 = photoBase64;

    const res  = await fetch(BASE_URL + '/api/ai_analyze.php', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    const data = await res.json();

    if (data.success && data.result) {
      const r = data.result;
      document.getElementById('field-title').value       = r.title || '';
      document.getElementById('field-priority').value    = r.priority || 'medium';
      document.getElementById('field-description').value = r.report || '';
      document.getElementById('ai-badge').style.display = '';
      document.getElementById('ai-hint').style.display  = '';
      showStatus('success', '<i class="bi bi-check-circle me-1"></i>Report generated! Review and edit if needed.');
    } else {
      showStatus('danger', (data.error || 'AI service unavailable.') + ' Please fill in manually.');
    }
  } catch (e) {
    showStatus('danger', '{$t_conn_error}');
  }

  btn.disabled = false;
  btn.innerHTML = '<i class="bi bi-stars me-2"></i>{$t_regen}';
}

function showStatus(type, msg) {
  const el = document.getElementById('ai-status');
  if (!type) { el.innerHTML = ''; return; }
  el.innerHTML = '<span class="text-' + type + '">' + msg + '</span>';
}

/* ── Map / GPS ── */
function initMap(lat, lon) {
  const mapEl = document.getElementById('map');
  mapEl.style.display = '';
  if (!map) {
    map = L.map('map').setView([lat, lon], 16);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap' }).addTo(map);
    map.on('click', e => setPin(e.latlng.lat, e.latlng.lng));
  } else {
    map.setView([lat, lon], 16);
  }
  setPin(lat, lon);
  setTimeout(() => map.invalidateSize(), 200);
}

function setPin(lat, lon) {
  document.getElementById('lat-input').value = lat.toFixed(7);
  document.getElementById('lon-input').value = lon.toFixed(7);
  if (marker) marker.setLatLng([lat, lon]);
  else marker = L.marker([lat, lon], { draggable: true }).addTo(map).on('dragend', e => {
    const p = e.target.getLatLng();
    document.getElementById('lat-input').value = p.lat.toFixed(7);
    document.getElementById('lon-input').value = p.lng.toFixed(7);
  });
}

function detectGPS() {
  const status = document.getElementById('gps-status');
  const btn    = document.getElementById('gps-btn');
  if (!navigator.geolocation) { status.textContent = 'GPS not supported.'; return; }
  status.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>{$t_detecting}';
  btn.disabled = true;
  navigator.geolocation.getCurrentPosition(pos => {
    const lat = pos.coords.latitude, lon = pos.coords.longitude;
    document.getElementById('lat-input').value = lat.toFixed(7);
    document.getElementById('lon-input').value = lon.toFixed(7);
    status.innerHTML = '<i class="bi bi-check-circle text-success me-1"></i>{$t_detected}';
    btn.disabled = false;
    initMap(lat, lon);
    fetch('https://nominatim.openstreetmap.org/reverse?lat='+lat+'&lon='+lon+'&format=json')
      .then(r => r.json()).then(d => {
        const inp = document.getElementById('address-input');
        if (!inp.value && d.display_name) inp.value = d.display_name.split(',').slice(0,3).join(', ');
      }).catch(() => {});
  }, () => {
    status.textContent = '{$t_gps_failed}';
    btn.disabled = false;
  }, { enableHighAccuracy: true, timeout: 10000 });
}

/* ── Submit ── */
document.getElementById('report-form').addEventListener('submit', async function(e) {
  e.preventDefault();
  const btn  = document.getElementById('submit-btn');
  const area = document.getElementById('alert-area');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>{$t_submitting}';
  area.innerHTML = '';
  try {
    const res  = await fetch(BASE_URL + '/api/case_submit.php', { method: 'POST', body: new FormData(this) });
    const data = await res.json();
    if (data.success) {
      area.innerHTML = '<div class="alert alert-success mb-3"><i class="bi bi-check-circle me-2"></i>Report submitted! Case code: <strong>' + data.case_code + '</strong></div>';
      this.reset();
      photoBase64 = null;
      document.getElementById('preview-img').style.display  = 'none';
      document.getElementById('upload-placeholder').style.display = '';
      document.getElementById('ai-badge').style.display = 'none';
      document.getElementById('ai-hint').style.display  = 'none';
      document.getElementById('map').style.display = 'none';
      document.getElementById('gps-status').textContent = '';
      document.getElementById('ai-status').innerHTML = '';
      document.getElementById('ai-btn').innerHTML = '<i class="bi bi-stars me-2"></i>{$t_ai_btn}';
      if (marker) { map.removeLayer(marker); marker = null; }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      area.innerHTML = '<div class="alert alert-danger mb-3"><i class="bi bi-exclamation-circle me-2"></i>' + (data.error||'An error occurred.') + '</div>';
    }
  } catch {
    area.innerHTML = '<div class="alert alert-danger mb-3">{$t_conn_error}</div>';
  }
  btn.disabled = false;
  btn.innerHTML = '<i class="bi bi-send me-2"></i>{$t_submit_btn}';
});

// Auto GPS on load
window.addEventListener('load', () => { if (navigator.geolocation) detectGPS(); });
</script>
JS;
include __DIR__ . '/../includes/footer.php';
