<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('resident');

$db   = Database::getInstance()->getConnection();
$case = null;
$code = strtoupper(trim($_GET['code'] ?? ''));
if ($code) {
    $stmt = $db->prepare("SELECT c.*, u.name AS officer_name, u.dept AS officer_dept, v.name AS vendor_name FROM cases c LEFT JOIN users u ON u.id = c.assigned_to LEFT JOIN users v ON v.id = c.vendor_id WHERE c.case_code = ?");
    $stmt->execute([$code]);
    $case = $stmt->fetch();
}

$page_title = t('track_title'); $layout = 'public';
include __DIR__ . '/../includes/header_public.php';
?>

<h4 class="fw-bold mb-1"><?= t('track_title') ?></h4>
<p class="text-muted small mb-4"><?= t('track_subtitle') ?></p>

<div class="cg-card mb-4">
  <div class="cg-card-body">
    <form method="GET" class="d-flex gap-2">
      <input type="text" name="code" class="form-control" placeholder="<?= t('track_ph') ?>"
             value="<?= htmlspecialchars($code) ?>" style="max-width:280px" required>
      <button type="submit" class="btn btn-primary"><i class="bi bi-search me-1"></i><?= t('btn_search') ?></button>
    </form>
  </div>
</div>

<?php if ($code && !$case): ?>
  <div class="alert alert-warning"><i class="bi bi-exclamation-triangle me-2"></i>Case code <strong><?= htmlspecialchars($code) ?></strong> not found.</div>

<?php elseif ($case):
  $sc = STATUS_CONFIG[$case['status']] ?? ['label' => $case['status']];
  $pc = PRIORITY_CONFIG[$case['priority']] ?? ['label' => $case['priority']];
  $steps  = [
    'new'         => ['icon' => 'bi-plus-circle',      'label' => t('track_received')],
    'assigned'    => ['icon' => 'bi-person-check',     'label' => t('track_assigned')],
    'in_progress' => ['icon' => 'bi-tools',            'label' => t('track_progress')],
    'resolved'    => ['icon' => 'bi-check2-circle',    'label' => t('track_resolved')],
    'approved'    => ['icon' => 'bi-patch-check-fill', 'label' => t('track_approved')],
  ];
  $order   = ['new','assigned','in_progress','resolved','approved'];
  $current = array_search($case['status'], $order);
?>
  <div class="cg-card">
    <div class="cg-card-header">
      <i class="bi bi-clipboard2-check me-2"></i><?= htmlspecialchars($case['case_code']) ?>
      <span class="ms-auto badge badge-status-<?= $case['status'] ?>"><?= t('status_' . $case['status']) ?></span>
    </div>
    <div class="cg-card-body">
      <h5 class="fw-semibold mb-1"><?= htmlspecialchars($case['title']) ?></h5>
      <p class="text-muted small mb-4">
        <span class="badge badge-priority-<?= $case['priority'] ?>"><?= t('pri_' . $case['priority']) ?></span>
        &nbsp;<?= htmlspecialchars($case['category']) ?>
        <?php if ($case['address']): ?>&nbsp;·&nbsp;<i class="bi bi-geo-alt"></i> <?= htmlspecialchars($case['address']) ?><?php endif; ?>
      </p>

      <div class="d-flex align-items-center gap-2 mb-4 flex-wrap">
        <?php foreach ($order as $i => $s):
          $done   = $current !== false && $i <= $current;
          $active = $case['status'] === $s;
          $info   = $steps[$s] ?? ['icon'=>'bi-circle','label'=>$s];
        ?>
          <div class="text-center" style="flex:1;min-width:55px">
            <div class="mx-auto mb-1 d-flex align-items-center justify-content-center"
                 style="width:34px;height:34px;border-radius:50%;font-size:.95rem;
                        background:<?= $done ? '#10b981' : '#e2e8f0' ?>;
                        color:<?= $done ? '#fff' : '#94a3b8' ?>;
                        box-shadow:<?= $active ? '0 0 0 4px rgba(16,185,129,.2)' : 'none' ?>">
              <i class="bi <?= $done ? 'bi-check' : $info['icon'] ?>"></i>
            </div>
            <div style="font-size:.63rem;color:<?= $done ? '#065f46' : '#94a3b8' ?>;font-weight:<?= $active ? '600' : '400' ?>">
              <?= $info['label'] ?>
            </div>
          </div>
          <?php if ($i < count($order)-1): ?>
            <div style="flex:1;height:2px;background:<?= $done && $i < $current ? '#10b981' : '#e2e8f0' ?>;min-width:15px"></div>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>

      <div class="row g-3">
        <div class="col-sm-4">
          <div class="text-muted small mb-1"><?= t('track_reported') ?></div>
          <div class="fw-semibold small"><?= date('d M Y H:i', strtotime($case['reported_at'])) ?></div>
        </div>
        <?php if ($case['officer_name']): ?>
        <div class="col-sm-4">
          <div class="text-muted small mb-1"><?= t('track_officer') ?></div>
          <div class="fw-semibold small"><?= htmlspecialchars($case['officer_name']) ?> <span class="text-muted fw-normal">· <?= htmlspecialchars($case['officer_dept']) ?></span></div>
        </div>
        <?php endif; ?>
        <?php if ($case['vendor_name']): ?>
        <div class="col-sm-4">
          <div class="text-muted small mb-1"><?= t('track_vendor') ?></div>
          <div class="fw-semibold small text-success"><i class="bi bi-building me-1"></i><?= htmlspecialchars($case['vendor_name']) ?></div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
