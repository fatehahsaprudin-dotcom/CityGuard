<?php
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session.php';
requireRole('resident');

$user = getCurrentUser();
$db   = Database::getInstance()->getConnection();

$hasVendor = false;
try { $db->query("SELECT vendor_id FROM cases LIMIT 1"); $hasVendor = true; } catch (PDOException $e) {}

if ($hasVendor) {
    $stmt = $db->prepare("
        SELECT c.*, u.name AS officer_name, v.name AS vendor_name
        FROM cases c
        LEFT JOIN users u ON u.id = c.assigned_to
        LEFT JOIN users v ON v.id = c.vendor_id
        WHERE c.reported_by = ?
        ORDER BY c.reported_at DESC
    ");
} else {
    $stmt = $db->prepare("
        SELECT c.*, u.name AS officer_name
        FROM cases c
        LEFT JOIN users u ON u.id = c.assigned_to
        WHERE c.reported_by = ?
        ORDER BY c.reported_at DESC
    ");
}
$stmt->execute([$user['id']]);
$cases = $stmt->fetchAll();

$categories_list = [];
try {
    $catRows = $db->query("SELECT name, COALESCE(name_bm, name) AS name_bm FROM categories WHERE is_active=1 ORDER BY name")->fetchAll();
    if ($catRows) $categories_list = $catRows;
} catch (PDOException $e) {}
if (empty($categories_list)) {
    foreach (CASE_CATEGORIES as $c) $categories_list[] = ['name' => $c, 'name_bm' => $c];
}

$page_title = t('hist_title'); $layout = 'public';
include __DIR__ . '/../includes/header_public.php';
?>

<div class="d-flex align-items-center justify-content-between mb-4">
  <div><h4 class="fw-bold mb-1"><?= t('hist_title') ?></h4><p class="text-muted small mb-0"><?= count($cases) ?> <?= t('hist_subtitle') ?></p></div>
  <a href="<?= BASE_URL ?>/resident/" class="btn btn-primary btn-sm"><i class="bi bi-plus me-1"></i><?= t('btn_new_report') ?></a>
</div>

<?php if (empty($cases)): ?>
  <div class="cg-card"><div class="cg-card-body text-center py-5 text-muted">
    <i class="bi bi-inbox fs-1 d-block mb-3"></i><?= t('hist_no_reports') ?> <a href="<?= BASE_URL ?>/resident/"><?= t('hist_submit_now') ?></a>.
  </div></div>
<?php else: ?>
  <div class="timeline" id="case-list">
    <?php foreach ($cases as $c):
      $sc = STATUS_CONFIG[$c['status']] ?? ['label' => $c['status']];
      $pc = PRIORITY_CONFIG[$c['priority']] ?? ['label' => $c['priority']];
      $canEdit = $c['status'] === 'new';
    ?>
    <div class="tl-item" id="case-row-<?= $c['id'] ?>">
      <div class="tl-dot"></div>
      <div class="cg-card mb-0">
        <div class="cg-card-body">
          <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
            <div style="flex:1;min-width:0">
              <div class="d-flex align-items-center gap-2 mb-1 flex-wrap">
                <span class="badge badge-status-<?= $c['status'] ?>"><?= t('status_' . $c['status']) ?></span>
                <span class="badge badge-priority-<?= $c['priority'] ?>"><?= t('pri_' . $c['priority']) ?></span>
                <code class="small text-muted"><?= htmlspecialchars($c['case_code']) ?></code>
              </div>
              <h6 class="fw-semibold mb-1"><?= htmlspecialchars($c['title']) ?></h6>
              <p class="text-muted small mb-0">
                <i class="bi bi-tag me-1"></i><?= htmlspecialchars($c['category']) ?>
                <?php if ($c['address']): ?>&nbsp;·&nbsp;<i class="bi bi-geo-alt me-1"></i><?= htmlspecialchars($c['address']) ?><?php endif; ?>
              </p>
              <?php if (!empty($c['officer_name']) || !empty($c['vendor_name'])): ?>
                <p class="small mt-1 mb-0">
                  <?php if (!empty($c['officer_name'])): ?><span class="text-primary"><i class="bi bi-person-badge me-1"></i><?= htmlspecialchars($c['officer_name']) ?></span><?php endif; ?>
                  <?php if (!empty($c['vendor_name'])): ?>&nbsp;·&nbsp;<span class="text-success"><i class="bi bi-building me-1"></i><?= htmlspecialchars($c['vendor_name']) ?></span><?php endif; ?>
                </p>
              <?php endif; ?>
            </div>
            <div class="text-end" style="font-size:.75rem;flex-shrink:0">
              <div class="text-muted"><?= date('d M Y', strtotime($c['reported_at'])) ?></div>
              <div class="text-muted"><?= date('H:i', strtotime($c['reported_at'])) ?></div>
              <?php if ($canEdit): ?>
              <div class="d-flex gap-1 justify-content-end mt-2">
                <button class="btn btn-sm btn-outline-primary btn-icon"
                        onclick="openEdit(<?= htmlspecialchars(json_encode([
                          'id'          => $c['id'],
                          'title'       => $c['title'],
                          'category'    => $c['category'],
                          'priority'    => $c['priority'],
                          'description' => $c['description'] ?? '',
                          'address'     => $c['address'] ?? '',
                        ]), ENT_QUOTES) ?>)"
                        title="<?= t('btn_edit') ?>"><i class="bi bi-pencil"></i></button>
                <button class="btn btn-sm btn-outline-danger btn-icon"
                        onclick="deleteCase(<?= $c['id'] ?>,'<?= htmlspecialchars(addslashes($c['case_code'])) ?>')"
                        title="<?= t('btn_delete') ?>"><i class="bi bi-trash"></i></button>
              </div>
              <?php endif; ?>
            </div>
          </div>
          <?php if ($c['description'] || !empty($c['report_photo'])): ?>
            <div class="d-flex gap-3 mt-2 align-items-start">
              <?php if (!empty($c['report_photo'])): ?>
                <img src="<?= UPLOAD_REPORTS_URL . htmlspecialchars($c['report_photo']) ?>"
                     style="width:100px;height:100px;object-fit:cover;border-radius:10px;cursor:pointer;border:2px solid #e2e8f0;flex-shrink:0"
                     onclick="openPhoto('<?= UPLOAD_REPORTS_URL . htmlspecialchars($c['report_photo']) ?>')"
                     title="View photo" alt="Report photo">
              <?php endif; ?>
              <?php if ($c['description']): ?>
                <p class="small text-muted mb-0" style="flex:1;min-width:0"><?= nl2br(htmlspecialchars($c['description'])) ?></p>
              <?php endif; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content border-0" style="border-radius:16px">
      <div class="modal-header border-0">
        <h6 class="modal-title fw-semibold"><i class="bi bi-pencil me-2"></i><?= t('hist_edit_title') ?></h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body pt-0">
        <input type="hidden" id="edit-id">

        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('hist_cat_lbl') ?> <span class="text-danger">*</span></label>
          <select id="edit-category" class="form-select">
            <option value="">— <?= t('btn_search') ?> —</option>
            <?php foreach ($categories_list as $cat): ?>
              <option value="<?= htmlspecialchars($cat['name']) ?>"><?= htmlspecialchars(langIs('bm') ? $cat['name_bm'] : $cat['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('hist_pri_lbl') ?></label>
          <select id="edit-priority" class="form-select">
            <option value="medium"><?= t('pri_medium') ?></option>
            <option value="high"><?= t('pri_high') ?></option>
            <option value="low"><?= t('pri_low') ?></option>
          </select>
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('hist_title_lbl') ?> <span class="text-danger">*</span></label>
          <input type="text" id="edit-title" class="form-control" maxlength="150">
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('hist_desc_lbl') ?></label>
          <textarea id="edit-description" class="form-control" rows="4"></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold"><?= t('hist_addr_lbl') ?></label>
          <input type="text" id="edit-address" class="form-control" placeholder="<?= t('res_loc_ph') ?>">
        </div>

        <div id="edit-result"></div>
      </div>
      <div class="modal-footer border-0 pt-0">
        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal"><?= t('btn_cancel') ?></button>
        <button type="button" class="btn btn-primary btn-sm" id="edit-save-btn" onclick="saveEdit()">
          <i class="bi bi-check2 me-1"></i><?= t('btn_save') ?>
        </button>
      </div>
    </div>
  </div>
</div>

<?php
$t_saving     = t('btn_saving');
$t_save       = t('btn_save');
$t_confirm_del = t('msg_confirm_del');
$extra_js = <<<JS
<script>
function openEdit(data) {
  document.getElementById('edit-id').value           = data.id;
  document.getElementById('edit-category').value     = data.category;
  document.getElementById('edit-priority').value     = data.priority;
  document.getElementById('edit-title').value        = data.title;
  document.getElementById('edit-description').value  = data.description;
  document.getElementById('edit-address').value      = data.address;
  document.getElementById('edit-result').innerHTML   = '';
  new bootstrap.Modal(document.getElementById('editModal')).show();
}

async function saveEdit() {
  const id       = document.getElementById('edit-id').value;
  const title    = document.getElementById('edit-title').value.trim();
  const category = document.getElementById('edit-category').value;
  if (!title || !category) {
    document.getElementById('edit-result').innerHTML = '<div class="alert alert-danger small py-2">Title and category are required.</div>';
    return;
  }
  const btn = document.getElementById('edit-save-btn');
  btn.disabled = true; btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>{$t_saving}';

  const res  = await fetch(BASE_URL + '/api/case_update.php', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({
      case_id:     id,
      title:       title,
      category:    category,
      priority:    document.getElementById('edit-priority').value,
      description: document.getElementById('edit-description').value.trim(),
      address:     document.getElementById('edit-address').value.trim(),
    })
  });
  const data = await res.json();
  if (data.success) {
    bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
    location.reload();
  } else {
    document.getElementById('edit-result').innerHTML = '<div class="alert alert-danger small py-2">' + (data.error||'Error saving.') + '</div>';
    btn.disabled = false; btn.innerHTML = '<i class="bi bi-check2 me-1"></i>{$t_save}';
  }
}

async function deleteCase(id, code) {
  if (!confirm('{$t_confirm_del}')) return;
  const res  = await fetch(BASE_URL + '/api/case_delete.php', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ case_id: id })
  });
  const data = await res.json();
  if (data.success) {
    const row = document.getElementById('case-row-' + id);
    if (row) { row.style.transition = 'opacity .3s'; row.style.opacity = '0'; setTimeout(() => row.remove(), 300); }
  } else {
    alert(data.error || 'Could not delete report.');
  }
}
</script>
JS;
include __DIR__ . '/../includes/footer.php';
